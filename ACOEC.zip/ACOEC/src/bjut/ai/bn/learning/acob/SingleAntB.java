package bjut.ai.bn.learning.acob;

import java.util.ArrayList;
import java.util.Random;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;
/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class SingleAntB
{
    private double[][] m_heuristicInfo; //������Ϣ
    private double m_tao0;     //������Ϣ
    private double m_alpha = 0.4F; //Ϊʲôû�����ϣ���
    private double m_beta = 0.6F;//������Ϣ
    private double m_rou;//������Ϣ
    private double m_q0;//������Ϣ
    private BNGraph m_bnGraph; //ͼ
    private int m_i, m_j;   //�ӽڵ㣬���ڵ��
    private final Random RANDOM; //�����
    private K2.TYPE type;  //k2
    private double m_mi = 1.0;
    private double base; //ci���Ե���ֵ��
    private int vexnum;
    private Score score = null;
    private int num=5000;
    
    private int []shunxu; //���˳��
    private double dist;//��֮��ľ���  
    private double visual;//�����Ұ��Χ 
    private double yongjidu;//ӵ��������
    
 /*   private  int fish_number;         // �˹���Ⱥ�Ĺ�ģ
    private int try_number;          // ���Դ��� 
    private int dim;                 // �˹���״̬�ռ�ά�� 
    private double step;              // �˹����ƶ��Ĳ���
    private double delta;             // ӵ��������
    private double visual;            // ��Ұ 	
    private int index;               // ��ǰ����ֵ���˹�������ֵ
    private double [][]distance;        // �˹���ľ��� 
    private double [][]InitHArray;               // �˹���Ⱥ  */
    
    /**
     *
     * @param apheromone double[][]
     * @param analpha double
     * @param abeta double
     * @param arou double
     * @param aq0 double
     * @param atao0 double
     * @param aVexNum int
     */
    
    public SingleAntB(double analpha, double abeta,
                      double arou,
                      double aq0, double atao0, 
                      int aVexNum, K2.TYPE type1, 
                      double[][] InitHArray,
                      Score score)
    {
    	this.score = score;//����
    	this.vexnum = aVexNum;//�������
        m_beta = abeta;
        m_rou = arou;
        m_q0 = aq0;
        m_tao0 = atao0;
        m_i = -1;
        m_j = -1;
        //visual=avisual;��Ұ
        
        this.m_alpha = analpha;
        m_bnGraph = new BNGraph(aVexNum);
        RANDOM = new Random();
//        this.RANDOM.setSeed(0);
        m_heuristicInfo = new double[aVexNum][aVexNum];
        this.type = type1;
        this.setInitH(InitHArray);
    }
    /*
    public SingleAntB(int fish_number1, int try_number1,
    		double step1,
    		double delta1,  double visual1, 
             K2.TYPE type1, int index1,
            double[][] InitHArray,
            Score score)
{
            this.score = score;
            fish_number = fish_number1;
            try_number = try_number1;
            step = step1;
            delta= delta1;
            visual=visual1;
            index=index1;
            m_i = -1;
            m_j = -1;
            m_bnGraph = new BNGraph(fish_number);
            RANDOM = new Random();
            //this.RANDOM.setSeed(0);
            m_heuristicInfo = new double[fish_number][fish_number];
            this.type = type1;
            this.setInitH(InitHArray);
}*/

    
    public void setScore(Score s)
    {
    	this.score = s;
    }
    /**
     * �ֲ���Ϣ�صĸ���
     */
    private void updatePheromone()
    {
        //������Ϣ��
        SingleACOB.GlobalPheromoneMatrix[m_i][m_j] = (1 - m_rou) * SingleACOB.GlobalPheromoneMatrix[m_i][m_j] +m_rou * m_tao0;
    }


    
    
    public void setInitH(double[][] array)
    {
    	for (int m = 0; m < array.length; m++)
        {
            System.arraycopy(array[m], 0, this.m_heuristicInfo[m], 0,
                             vexnum);
            this.m_bnGraph.GetNode(m).K2Score = SingleACOB.noParVexK2Value[m];
        }
    }

    /**
     * ������
     */
    private void eliminateCircle()
    {
        ArrayList<Integer> ancestorslist = null;
        ArrayList<Integer> descendantslist = null;

        ancestorslist = m_bnGraph.GetNode(m_j).GetAncestorNodesIndex();
        descendantslist = m_bnGraph.GetNode(m_i).GetDescendantNodesIndex();

        for (int i = 0, size1 = ancestorslist.size(); i < size1; i++)
        {
            for (int j = 0, size2 = descendantslist.size(); j < size2; j++)
            {
                m_heuristicInfo[ancestorslist.get(i).intValue()][descendantslist.get(j).intValue()] = Double.NEGATIVE_INFINITY;
            }
        }
    }

    /**
     * ����������Ϣ
     * @param ParentK2score double
     * @param parentlist ArrayList
     */
    private void updateHeuristicInfo(double ParentK2score, final ArrayList<Integer> parentlist)
    {
//        System.out.println("����������Ϣ");

        for (int k = 0; k < vexnum; k++)
        {
            if (m_heuristicInfo[m_i][k] > (Double.NEGATIVE_INFINITY))
            {
                double afterAddParentK2score = 0;
                parentlist.add(m_bnGraph.GetNode(k).GetNodeId());
                int index = parentlist.size();
                afterAddParentK2score = this.score.calcScore(m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
                m_heuristicInfo[m_i][k] = afterAddParentK2score -ParentK2score;
//                System.out.println("������Ϣ����"+m_i+":"+m_heuristicInfo[m_i][k]);
                parentlist.remove(index - 1);
            }
        }
    }

    /**
     * ����������Ϣ��Ӧ���˻���Ϣ
     * @param ParentK2score double
     * @param parentlist ArrayList
     */
    private void updateHInfoWithMI(double ParentK2score, final ArrayList<Integer> parentlist)
    {
//        System.out.println("����������Ϣ�����˻���Ϣ");
        for (int k = 0; k < vexnum; k++)
        {
            if (m_heuristicInfo[m_i][k] > (Double.NEGATIVE_INFINITY))
            {
                double afterAddParentK2score = 0;
                parentlist.add(m_bnGraph.GetNode(k).GetNodeId());
                int index = parentlist.size();
                afterAddParentK2score = this.score.calcScore(
                        m_bnGraph.GetNode(
                                m_i).GetNodeId(), parentlist);
                m_heuristicInfo[m_i][k] = afterAddParentK2score -
                                          ParentK2score;
                m_heuristicInfo[m_i][k] *= (1 + K2.getRefect(K2.Inf[m_i][k])); //���뻥��Ϣ
                parentlist.remove(index - 1);
            }
        }
    }

    /**
     *
     * @param base double
     */
    public void CIConstrainByValue(double base)
    {
        K2.CITestByValue(base);
        for (int i = 0; i < vexnum; i++)
        {
            for (int j = 0; j < vexnum; j++)
            {
                if (K2.ChiSquare[i][j] == 0)
                {
                    this.m_heuristicInfo[i][j] = Double.NEGATIVE_INFINITY;
                }
            }
        }

    }

    /**
     * AntB�߳�run()�ӿ�
     */
    public void run2(int k)
    {	
        ArrayList<Integer> parentlist = null;
        //��ʼ��������Ϣ
//        this.getInitH();
        if (this.type.toString() == "CInew")
            this.CIConstrainByValue(this.base);
        do
        {
            //����ACSת�ƹ���Ѱ����һ���ߣ�j-->i��
            this.choose_ijNew();
        	// this.choose_ijNewMI();
            if (m_heuristicInfo[m_i][m_j] > 0)
            {
                //Pa(xi) = Pa(Xi)U{Xj}����ߣ�ͬʱ�Զ����븸�׽ڵ�
                m_bnGraph.AddArc(m_j, m_i);
                m_heuristicInfo[m_i][m_j] = Double.NEGATIVE_INFINITY;
                //ȡ�ø�ĸ�ڵ���б�
                parentlist = m_bnGraph.GetNode(m_i).GetParentNodesIndex();
                //
                double ParentK2score = this.score.calcScore(m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
//                System.out.println("��ǰ�ڵ�"+m_i+" ��ĸ�ڵ�"+parentlist+" ����"+ParentK2score);
                this.m_bnGraph.GetNode(m_i).K2Score = ParentK2score;
                //������
                this.eliminateCircle();
                //����������Ϣ
                if (this.type == K2.TYPE.AIO || this.type == K2.TYPE.HF)
                    this.updateHInfoWithMI(ParentK2score, parentlist); //
                else
                    this.updateHeuristicInfo(ParentK2score, parentlist);
                //���¾ֲ���Ϣ��
                this.updatePheromone();//��ʼ�� ��ʱ����Ҫ���� ��Ϣ�� 
            }
        }
        while (!stopchoose());
        this.m_bnGraph.K2Score = this.m_bnGraph.calcTotalK2Score(this.score);
//        this.m_bnGraph.setScore(this.score.calcGraphScore(this.m_bnGraph));
//        System.out.println("������Ϣ����");
//        SingleAntB.outArray(this.m_heuristicInfo);
//        System.out.println("��Ϣ�ؾ���");
//        SingleAntB.outArray(this.SingleACOB.PheromoneMatrix);
        SingleACOB.addToSolutionSet(this.m_bnGraph,k);

    }
    public void run()
    {
        ArrayList<Integer> parentlist = null;
        //��ʼ��������Ϣ
//        this.getInitH();
        if (this.type.toString() == "CInew")
            this.CIConstrainByValue(this.base);
        do
        {
            //����ACSת�ƹ���Ѱ����һ���ߣ�j-->i��
            this.choose_ijNew();

//            this.choose_ijNewMI();
            if (m_heuristicInfo[m_i][m_j] > 0)
            {
                //Pa(xi) = Pa(Xi)U{Xj}����ߣ�ͬʱ�Զ����븸�׽ڵ�
                m_bnGraph.AddArc(m_j, m_i);
                m_heuristicInfo[m_i][m_j] = Double.NEGATIVE_INFINITY;
                //ȡ�ø�ĸ�ڵ���б�
                parentlist = m_bnGraph.GetNode(m_i).GetParentNodesIndex();
                //
                double ParentK2score = this.score.calcScore(m_bnGraph.
                        GetNode(m_i).
                        GetNodeId(), parentlist);
//                System.out.println("��ǰ�ڵ�"+m_i+" ��ĸ�ڵ�"+parentlist+" ����"+ParentK2score);
                this.m_bnGraph.GetNode(m_i).K2Score = ParentK2score;
                //������
                this.eliminateCircle();
                //����������Ϣ
                if (this.type == K2.TYPE.AIO || this.type == K2.TYPE.HF)
                    this.updateHInfoWithMI(ParentK2score, parentlist); //
                else
                    this.updateHeuristicInfo(ParentK2score, parentlist);
                //���¾ֲ���Ϣ��
                this.updatePheromone();
            }
        }
        while (!stopchoose());
        this.m_bnGraph.K2Score = this.m_bnGraph.calcTotalK2Score(this.score);
//        this.m_bnGraph.setScore(this.score.calcGraphScore(this.m_bnGraph));
//        System.out.println("������Ϣ����");
//        SingleAntB.outArray(this.m_heuristicInfo);
//        System.out.println("��Ϣ�ؾ���");
//        SingleAntB.outArray(this.SingleACOB.PheromoneMatrix);
        SingleACOB.addToSolutionSet(this.m_bnGraph);

    }
    
    public void runRandomSolution2()
    {
        ArrayList<Integer> parentlist = null;
        //��ʼ��������Ϣ
//        this.getInitH();
        
        
        if (this.type.toString() == "CInew")
            this.CIConstrainByValue(this.base);
        do
        {
            //���Ѱ����һ���ߣ�j-->i�� 
        	do
        	{
        	m_i=RANDOM.nextInt(vexnum);
        	m_j=RANDOM.nextInt(vexnum);
        	}while(m_i==m_j);
        	//this.choose_ijRandom();//��� ���� ��ʼ ��  ԭ��Ϊchoose_ij();
            if (m_heuristicInfo[m_i][m_j] > 0)
            {
                //Pa(xi) = Pa(Xi)U{Xj}����ߣ�ͬʱ�Զ����븸�׽ڵ�
                m_bnGraph.AddArc(m_j, m_i);
                System.out.format("���ѡ��i��j[%d %d]\n", m_i, m_j);
                m_heuristicInfo[m_i][m_j] = Double.NEGATIVE_INFINITY;
                //ȡ�ø�ĸ�ڵ���б�
                parentlist = m_bnGraph.GetNode(m_i).GetParentNodesIndex();
                //
                double ParentK2score = this.score.calcScore(m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
//                System.out.println("��ǰ�ڵ�"+m_i+" ��ĸ�ڵ�"+parentlist+" ����"+ParentK2score);
                this.m_bnGraph.GetNode(m_i).K2Score = ParentK2score;
                //������
                this.eliminateCircle();
                //����������Ϣ
                if (this.type == K2.TYPE.AIO || this.type == K2.TYPE.HF)
                    this.updateHInfoWithMI(ParentK2score, parentlist); //
                else
                    this.updateHeuristicInfo(ParentK2score, parentlist);
                //���¾ֲ���Ϣ��
                //this.updatePheromone();//��ʼ�� ��ʱ����Ҫ���� ��Ϣ�� 
            }
        }
        while (!stopchoose());
        this.m_bnGraph.K2Score = this.m_bnGraph.calcTotalK2Score(this.score);
//        this.m_bnGraph.setScore(this.score.calcGraphScore(this.m_bnGraph));
//        System.out.println("������Ϣ����");
//        SingleAntB.outArray(this.m_heuristicInfo);
//        System.out.println("��Ϣ�ؾ���");
//        SingleAntB.outArray(this.SingleACOB.PheromoneMatrix);
        SingleACOB.addToSolutionSet(this.m_bnGraph);
    }

    
    public void runRandomSolution2(int k)//kΪ��Ⱥ��ţ���0��ʼ
    {
    	//System.out.println(k);
        ArrayList<Integer> parentlist = null;
        //��ʼ��������Ϣ
        //this.getInitH();
       shunxu = new int[num];//���������˳��
        int i=0;//������
        if (this.type.toString() == "CInew")
            this.CIConstrainByValue(this.base);
        do
        {
            //���Ѱ����һ���ߣ�j-->i�� 
        	/*
        	do
        	{
        	m_i=RANDOM.nextInt(vexnum);
        	m_j=RANDOM.nextInt(vexnum);
        	}
        	while(m_i==m_j);
        	*/
        	this.choose_ij();
            if (m_heuristicInfo[m_i][m_j] > 0)
            {
            	/*
            	for(int j=0;j<num;j++)
            	{
            		if(shunxu[j]!=m_i)
           		    shunxu[i]=m_i;
            	}
            	
            	shunxu[i]=m_j;
            	 
            	
            	i++;
            	//System.out.println(shunxu[i]); 
            	System.out.println(m_j); 
            	*/
                //Pa(xi) = Pa(Xi)U{Xj}����ߣ�ͬʱ�Զ����븸�׽ڵ�
                m_bnGraph.AddArc(m_j, m_i);//�ӱ�
                m_heuristicInfo[m_i][m_j] = Double.NEGATIVE_INFINITY;
                //ȡ�ø�ĸ�ڵ���б�
                parentlist = m_bnGraph.GetNode(m_i).GetParentNodesIndex();
                //
                double ParentK2score = this.score.calcScore(m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
//                System.out.println("��ǰ�ڵ�"+m_i+" ��ĸ�ڵ�"+parentlist+" ����"+ParentK2score);
                this.m_bnGraph.GetNode(m_i).K2Score = ParentK2score;
                //������
                this.eliminateCircle();
                //����������Ϣ
                if (this.type == K2.TYPE.AIO || this.type == K2.TYPE.HF)
                    this.updateHInfoWithMI(ParentK2score, parentlist); //
                else
                    this.updateHeuristicInfo(ParentK2score, parentlist);
                //���¾ֲ���Ϣ��
                //this.updatePheromone();//��ʼ�� ��ʱ����Ҫ���� ��Ϣ�� 
            }
            
        }
        while (!stopchoose());
        /*
        for (int m = 0; m < vexnum; m++)
        {
            for (int n = 0; n< vexnum; n++)
            {
            	if(shunxu[m]==shunxu[n])
            		
            }
        }*/
            
        
        this.m_bnGraph.K2Score = this.m_bnGraph.calcTotalK2Score(this.score);
//        this.m_bnGraph.setScore(this.score.calcGraphScore(this.m_bnGraph));
//        System.out.println("������Ϣ����");
//        SingleAntB.outArray(this.m_heuristicInfo);
//        System.out.println("��Ϣ�ؾ���");
//        SingleAntB.outArray(this.SingleACOB.PheromoneMatrix);
        SingleACOB.addToSolutionSet(this.m_bnGraph,k);
        //SingleACOB.addToSolutionSet(this.m_bnGraph,k);
    }
    
    
    private void findMax(final double[][] temp)
    {
        double max = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < temp.length; i++)
        {
            for (int j = 0; j < temp.length; j++)
            {
                if (temp[i][j] > max)
                {
                    m_i = i;
                    m_j = j;
                    max = temp[i][j];
                }
            }
        }
//        System.out.println(m_i+" "+m_j);
    }

    /**
     * choose_ij()
     * ACSѡ·����
     */
    private void choose_ij()
    {
    	 shunxu = new int[num];//���������˳��
    	 int k=0;
    	 
    	 
        double q = RANDOM.nextDouble();
        double sumvalue = 0.0;
        double value = 0.0;
        double probability[][];
        if (q <= m_q0)
        {
            probability = new double[vexnum][vexnum];
            for (int i = 0; i < vexnum; i++)
            {
                for (int j = 0; j < vexnum; j++)
                {
                    if (i != j && m_heuristicInfo[i][j] > 0)
                    {
                        probability[i][j] = Math.pow(m_heuristicInfo[i][j], m_beta)
                                            * SingleACOB.GlobalPheromoneMatrix[i][j];
                        
                    }
                    else
                    {
                        probability[i][j] = Double.NEGATIVE_INFINITY;
                    }
                    
                    if(shunxu[j]!=m_i&&shunxu[i]!=m_i)
                   	shunxu[k]=m_i;
                    else
                    	shunxu[k]=m_j;
                    	
                }
            }
            this.findMax(probability);
        }
        else
        { //exploration
            probability = new double[vexnum][vexnum];
            for (int i = 0; i < vexnum; i++)
            {
                for (int j = 0; j < vexnum; j++)
                {
                    if (i != j && m_heuristicInfo[i][j] > 0)
                    {
                        probability[i][j] = Math.pow(m_heuristicInfo[i][j],m_beta) *SingleACOB.GlobalPheromoneMatrix[i][j];
                        sumvalue += probability[i][j]; //���
                        
                       
                    }
                    else
                    {
                        probability[i][j] = 0.0;
                    }
                    
                    if(shunxu[j]!=m_i&&shunxu[i]!=m_i)
                    	shunxu[k]=m_i;
                    else
                    	shunxu[k]=m_j;
                }
            }
            for (int i = 0; i < vexnum; i++)
                for (int j = 0; j < vexnum; j++)
                    probability[i][j] /= sumvalue; //���Ժ�
            q = RANDOM.nextDouble();
            while (q <= 0.0)
                q = RANDOM.nextDouble();
            loop1:
              for (int i = 0; i < vexnum; i++)
                for (int j = 0; j < vexnum; j++)
                {
                    value += probability[i][j]; //�ۼ�ֱ������q
                    if (value >= q)
                    {
                        m_i = i;
                        m_j = j;
                        
                        break loop1;
                    }
                    
                    if(shunxu[j]!=m_i&&shunxu[i]!=m_i)
                        	shunxu[k]=m_i;
                    else
                    	shunxu[k]=m_j;
                    	
                    
                }
        }
        
     //   System.out.print(shunxu[k]);//k[1]��ʼΪ��һ�����
        k++;
   // System.out.format("���ѡ��i��j[%d %d]\n", m_i, m_j);
    }
    /**
     * ���ѡ����һ����
     */
    /**
     * ���ߺ������ڳ�ʼ��ѡ�߲����ĵ�һ����
     * @param probability double[][]
     */
    private void initPart1(double[][] probability)
    {
        double sumvalue = 0.0;
        for (int i = 0; i < vexnum; i++)
        {
            for (int j = 0; j < vexnum; j++)
            {
                if (i != j && m_heuristicInfo[i][j] > 0)
                {
                    probability[i][j] = Math.pow(m_heuristicInfo[i][j], m_beta)* SingleACOB.GlobalPheromoneMatrix[i][j];
                    sumvalue += probability[i][j]; //���+
                }
                else
                {
                    probability[i][j] = Double.NEGATIVE_INFINITY;
                }
            }
        }

    }

   

    private void choose_ijNew()
    {
        double q = RANDOM.nextDouble();
        double sumvalue = 0.0;
        double value = 0.0;
        double[][] probability = new double[vexnum][vexnum];

        if (q <= m_q0)
        {
            this.initPart1(probability);
            this.findMax(probability);
//            System.out.format("һexploiation" + "���ѡ��i��j[%d %d]\n", m_i, m_j);
//            K2.out.format("һexploiation" + "���ѡ��i��j[%d %d]\n", m_i, m_j);
//            System.out.println("ij��ֵ"+probability[m_i][m_j]);
//            System.out.println("ji��ֵ"+probability[m_j][m_i]);
//            System.out.println("ij������Ϣֵ"+this.m_heuristicInfo[m_i][m_j]);
//            System.out.println("ji������Ϣֵ"+this.m_heuristicInfo[m_j][m_i]);

        }
        else
        { //exploration
            probability = new double[vexnum][vexnum];
            for (int i = 0; i < vexnum; i++)
            {
                for (int j = 0; j < vexnum; j++)
                {
                    if (i != j && m_heuristicInfo[i][j] > 0)
                    {
                        probability[i][j] = Math.pow(m_heuristicInfo[i][j], m_beta)
                                            * Math.pow(SingleACOB.GlobalPheromoneMatrix[i][j], m_alpha);
//                        System.out.println(m_heuristicInfo[i][j]+";"+K2.Inf[i][j]+";"+SingleACOB.PheromoneMatrix[i][j]);
                        sumvalue += probability[i][j]; //���
                    }
                    else
                    {
                        probability[i][j] = 0.0;
                    }
                }
            }
            for (int i = 0; i < vexnum; i++)
                for (int j = 0; j < vexnum; j++)
                {
                    probability[i][j] /= sumvalue; //���Ժ�
                }

            q = RANDOM.nextDouble();
            while (q <= 0.0)
                q = RANDOM.nextDouble();
            loop1:
                    for (int i = 0; i < vexnum; i++)
                for (int j = 0; j < vexnum; j++)
                {
                    value += probability[i][j]; //�ۼ�ֱ������q
                    if (value >= q)
                    {
                        m_i = i;
                        m_j = j;
                        break loop1;
                    }
                }
//            System.out.format("��exploration ���ѡ��i��j[%d %d]\n", m_i, m_j);
//            K2.out.format("��exploration ���ѡ��i��j[%d %d]\n", m_i, m_j);
//            System.out.println("ij��ֵ"+probability[m_i][m_j]);
//            System.out.println("ji��ֵ"+probability[m_j][m_i]);
        }
//        System.err.println("ij��ֵ"+m_i+" "+m_j);
    }


    
    /**
     * stopchoose
     * �ж��Ƿ�ֹͣѡ·
     * @return boolean
     */
    protected boolean stopchoose()
    {
        for (int i = 0; i < vexnum; i++)
            for (int j = 0; j < vexnum; j++)
                if (m_heuristicInfo[i][j] > 0.0)
                {
                    return false;
                }
        return true;
    }

    public void PrintPheromone()
    {
        System.out.print("��Ϣ�أ�\r\n");
        for (int i = 0; i < SingleACOB.GlobalPheromoneMatrix.length; i++)
        {
            for (int j = 0; j < SingleACOB.GlobalPheromoneMatrix[i].length; j++)
            {
                System.out.print(SingleACOB.GlobalPheromoneMatrix[i][j] + " ");
            }
            System.out.print("\r\n");
        }
        System.out.print("\r\n");
    }

    /**
     * getBNgraph
     * �������ϻ�ȡ�����ṹ
     * @return BNGraph
     */
    public BNGraph getBNgraph()
    {
        return this.m_bnGraph;
    }

    /**
     * getBNGraphScore
     * �������ṹ������
     * @return double
     */
    public double getBNGraphScore()
    {
        return this.m_bnGraph.getScore();
    }

//    /**
//     * ����
//     * @param g BNGraph
//     * @return double
//     */
    public static double calcGraph(BNGraph g)
    {
        double k2score = 0;
        double temp = 0;
        java.text.DecimalFormat myformat = new java.text.DecimalFormat("#0.000");

        ArrayList al = new ArrayList();
        for (int i = 0; i < K2.VEXNUM; i++)
        {
            al = g.GetNode(i).GetParentNodesIndex();
            temp = K2.INSTANCE.calcScore(i, al);

////            System.out.println("��ǰ�ڵ㣺" + i + "  ���׽ڵ�" + al + "  ����" + temp);
            System.out.println(myformat.format(temp));
//            System.out.println(  K2.INSTANCE.NodeInfo[i].size()   );
           k2score = k2score + temp;
        }
        System.out.println("�����������" + k2score);
        return k2score;
    }
    /*
    public static void main(String[] args)
    {
    	int k=50;
    	SingleAntB temp1 = new SingleAntB(, 1.0, 2.0, 0.15, 0.8, 25,100, 50,,);
    	temp1.runRandomSolution2(k);
    	
    	for(int i=0;i<k;i++)
    	System.out.println(temp1.shunxu[i]);
    }
    */
    public  double distance(SingleAntB a,SingleAntB b)//����������֮��ľ���
    {
    	double x=0;
    	
    	for(int i=0;i<vexnum;i++) 	
    	{
    		x=Math.abs(a.shunxu[i]-b.shunxu[i]);  	//����ڵ�����ľ���ֵ 	   	
    	    dist=dist+Math.signum(x);                //����Ϊ��x=0��+0��x<0,-1;x>0,+1
    	}
    	return dist;
    }
    
    public int samedis(SingleAntB a,SingleAntB b)//���������㼴���˳������ͬ�������
    {
        double x=0;   
        int sum=0;
    	for(int i=0;i<vexnum;i++) 
    	{
        x=Math.abs(a.shunxu[i]-b.shunxu[i]);
    	if(Math.signum(x)==0)      //��������Ϊ0����֤���ô����˳����ͬ
    	{
    		sum++;           
    	}
    	}
    	return sum;
    	
    }
    

  
}
