package bjut.ai.bn.learning.acob;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;
import java.util.TreeSet;

import bjut.ai.bn.learning.acob.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.BNNode;
import bjut.ai.bn.Neighborhood;
import bjut.ai.bn.learning.acob.CommonTools;
import bjut.ai.bn.HillClimbing;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;

public class SingleAFSA {
	private final Random RANDOM;
	public static double[][] tempH = null;
	public static int bestOccur = 0;// ���Ŵ���
	public static long[] bestOccurTime = new long[2000];// ���Ŵ�������ʱ��
	public static double[] noParVexK2Value = new double[K2.VEXNUM];
	private static int solutionCount = 0;// ��Ĵ�����������
	public static BNGraph[] bestSolutions; // ���Ž�ṹ
	public static int LogK2ScoreCount = 0;

	public static BNGraph zhui; // zhuiwei�ṹ
	public static BNGraph ju; // juqun�ṹ
	public static BNGraph mi; // juqun�ṹ
	public static BNGraph tempg;
	
	private K2.TYPE type; // k2
	private Score score = null;

	// ����
	private int vexnum;// ��Ⱥ������������
	private int try_number; // ���Դ���
	private double step; // �˹����ƶ��Ĳ���
	private int visual; // ��Ұ
	private double delta; // ӵ��������
	private int k;// ��������

	private int fishnum = 10;// ��Ⱥ��ģ

	private java.util.ArrayList<Double> BestScore; // ÿһ�������ŷ�ֵ
	private java.util.TreeSet<Integer> setOpted; // �Ѿ������Ż�������ֵ

	private int count;
    private int maxsame;//��ͬ����˳�����
    private int maxcode;//��ǰ���
	private BNGraph gk2sn;

    private int[] middle;
	private double dist;// ��֮��ľ���
	private int index; // ��ǰ����ֵ���˹�������ֵ
	private int maxnum;// �����ͬ�������
	private int BestScoreIndex; // ��ǰ������ֵ������

	private java.util.Random AnnealRandom = new Random();// �˻������
	public ArrayList<Singlefish> listfish = new ArrayList<Singlefish>(); // �洢��˳�������
	public ArrayList<Singlelinju> neifish = new ArrayList<Singlelinju>();// �洢�ھӽ��
	
	public ArrayList<Singlefish> tempzhui= new ArrayList<Singlefish>();//�洢׷β��ʱ����
	public ArrayList<Singlefish> tempju= new ArrayList<Singlefish>();//�洢��Ⱥ��ʱ����
	
	public BNGraph BestSolution; // ���Ž� ����this.BestSolution.K2Score��ʾ���Ž�����

	public SingleAFSA(BNGraph gk2sn, int try_number, double step, int visual,
			double delta, int k, int fishnum, K2.TYPE type1, Score score) {
		// ���k2sn�Ľ� ��ʽ��
		RANDOM = new Random();
		this.score = score;
		this.gk2sn = gk2sn;
		this.vexnum = gk2sn.getVexNum();
		this.BestSolution = gk2sn;
		SingleAFSA.tempH = new double[vexnum][vexnum];
		this.try_number = try_number;
		this.step = step;
		this.visual = visual;
		this.delta = delta;
		this.k = k;
		bestSolutions = new BNGraph[this.fishnum];
		this.type = type1;
		switch (type) {
		case ORI:
			System.err.println("ԭʼ");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();
			this.initheuristicInfo();
			break;
		case SA:
			System.err.println("ģ���˻��Ż�");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();
			this.initheuristicInfo();
			break;
		case CI:
			System.err.println("CI����");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();
			this.initheuristicInfo();
			break;
		}
	}

	public void setScoreMetric(Score s) {
		this.score = s;
	}

	public void initheuristicInfo() {
		BNGraph temp = new BNGraph(this.vexnum);
		ArrayList<Integer> anodelist = new ArrayList<Integer>(); // ��ʱ
		// System.out.println("��ʼ��������Ϣ����");
		long start = System.currentTimeMillis();
		for (int i = 0; i < this.vexnum; i++) {
			SingleAFSA.noParVexK2Value[i] = this.score.calcScore(i, anodelist);

			for (int j = 0; j < this.vexnum; j++) {
				if (i != j) {
					anodelist.add(j);
					SingleAFSA.tempH[i][j] = this.score.calcScore(temp.GetNode(i)
							.GetNodeId(), anodelist)
							- SingleAFSA.noParVexK2Value[i];
					anodelist.remove(0);
				} else
					SingleAFSA.tempH[i][j] = Double.NEGATIVE_INFINITY;

				// System.out.format("sz[%f]  ",this.tempH[i][j]);
			}
		}

		long end = System.currentTimeMillis();
		System.out.format("���,����[%d]����\n", end - start);

	}

	public static void addToSolutionSet(BNGraph b) {
		SingleAFSA.bestSolutions[SingleAFSA.solutionCount] = b;
	}

	public static void addToSolutionSet(BNGraph b, int k) {
		SingleAFSA.bestSolutions[k] = b;
	}

	public BNGraph getBestSolution() {
		Arrays.sort(SingleAFSA.bestSolutions);
		return SingleAFSA.bestSolutions[SingleAFSA.bestSolutions.length - 1];
	}

	static int MaxEqualStep = 50;

	public BNGraph HillClimbing(BNGraph G_k) {// ��ɽ�Ż�
		HillClimbing hill = new HillClimbing(G_k, this.score);
		if (this.type == K2.TYPE.OP) {
			G_k = hill.OptimizeBN_CI();
		} else {
			G_k = hill.OptimizeBN();
		}
		return G_k;
	}

	public void localOptimizate() {
		BNGraph temp = new BNGraph(this.vexnum);
		System.out.println("���ľֲ��Ż�");
		for (int i = 0; i < SingleAFSA.bestSolutions.length; i++) {
			SingleAFSA.bestSolutions[i] = this.HillClimbing(SingleAFSA.bestSolutions[i]);
		}
		temp = this.getBestSolution();
		if (temp.getScore() > this.BestSolution.getScore()) {
			this.BestSolution = temp;
		}

	}

	public BNGraph findBestBayesianNet(double[] lastphaseScore,
			double[] thisphaseScore, int[] trial, double bestScore) {
		long start = System.currentTimeMillis();
		BNGraph G_b;
		this.BestScore.clear();
		this.setOpted.clear();
		SingleAFSA.solutionCount = 0;
		
		 double middle=0 ;//���Ľ������
		 double zhuiwei=0;//׷β��������
		 
		System.out.format("����%dֻ��\n", fishnum);
		for (int k = 0; k < fishnum; k++) {

			System.out.format("���ɵ�[%d]ֻ��\n", count);
			count++;// countΪ����

			Singlefish temp = new Singlefish(this.vexnum, this.try_number,
					this.step, this.delta, this.visual, this.k, this.type,
					SingleAFSA.tempH, this.score);
			temp.runRandomSolution2(k);// ��ʼ����Ⱥ
			listfish.add(temp);
			
			 double currentAntScore = SingleAFSA.bestSolutions[SingleAFSA.solutionCount].K2Score;
	            thisphaseScore[k] = currentAntScore;
	            //listfish.add(k,thisphaseScore[k]).getBNGraphScore();
	            if (currentAntScore > bestScore)
	            {
	                //�õĽ�
	                bestScore = currentAntScore;   
	                this.BestScoreIndex = k;  //kΪ��ǰ�������ţ���������Ϊ��߷���
	            }
	            SingleAFSA.solutionCount++;
	        


		}
		/*
		  //Ϊÿһ�����������ھ���
		for (int i = 0; i < fishnum; i++) {
			for (int j = 0; j < fishnum; j++) {
				if (distance(listfish.get(i), listfish.get(j)) < 3 && i != j) {
					Singlelinju a1 = new Singlelinju(listfish.get(i),
							listfish.get(j), distance(listfish.get(i),
									listfish.get(j)));
					neifish.add(a1);

				}
			}

		}*/
     

		 for (int t = 0; t <k; t++)
	        {       	
	            for(int i=0;i<fishnum;i++)
	            {
	            	// System.out.println("a1");
	            	zhuiwei(listfish.get(i));//ִ��׷β����
	            	 System.out.println(zhui.getScore());
	            	juqun(listfish.get(i));//ִ�о�Ⱥ����
	            	System.out.println(ju.getScore());
	            	if(zhui.getScore()>=ju.getScore())
	            	{
	            	    tempg=zhui;
	            	    System.out.println(tempg.getScore());
	            	 

	            	}
	            	if(ju.getScore()>zhui.getScore())
	            	{
	            		 tempg=ju;
	            		  System.out.println(tempg.getScore());
	           
	            	}
	               if(tempg.getScore()>listfish.get(i).getBNGraphScore())
	               {
	            	   listfish.get(i).setBNgraph(tempg);// ��ԭ�е������
	            	  
	            	   
	            	   SingleAFSA.bestSolutions[i]=listfish.get(i).getBNgraph();
	            	   if(listfish.get(i).getBNGraphScore()>BestSolution.getScore())
	            	   {
	            		   BestSolution=listfish.get(i).getBNgraph();
	            		   bestScore=listfish.get(i).getBNGraphScore();
	            	   }
	            	 //  thisphaseScore[i]=this.bestSolutions[i].K2Score;
	            	 //  System.out.println("c");
	            	   
	               }
	               else
	               {
	            	   mishi(listfish.get(i));//ִ����ʳ����
	            	   listfish.get(i).setBNgraph(mi);//��ԭ�е������
	            	   System.out.println(listfish.get(i).getBNGraphScore());
	            	   SingleAFSA.bestSolutions[i]=listfish.get(i).getBNgraph();//�������Žṹ
	            	  // thisphaseScore[i]=this.bestSolutions[i].K2Score;
	            	 //  System.out.println("d");
	            	   if(listfish.get(i).getBNGraphScore()>BestSolution.getScore())
	            	   {
	            		   SingleAFSA.bestSolutions[i]=listfish.get(i).getBNgraph();
	            		   bestScore=listfish.get(i).getBNGraphScore();
	            	   }
	            	   
	               }
	            	 
	            }
	            //�����Ż�
	            if ( (t % step) == 0 && t != 0)
	            {
	                for (int i = 0; i < fishnum; i++){
	                     SingleAFSA.bestSolutions[i] = this.HillClimbing(SingleAFSA.bestSolutions[i]);
	                     thisphaseScore[i]=SingleAFSA.bestSolutions[i].K2Score;
	                }
	             }
	        	
	            for (int m = 0; m < fishnum; m++)
	            {            
	                if (thisphaseScore[m] > bestScore)
	                {
	                    //�õĽ�
	                    bestScore = thisphaseScore[m];
	                    this.BestScoreIndex = m;
	                }
	            }
	            System.out.println("���������" + t+" ��СΪ: "+bestScore );
	            this.BestScore.add(bestScore); //��¼��ǰantNum ���ϵ����Ž�               
	            G_b = this.getBestSolution();
	            System.out.println("G_b��������: "+ G_b.K2Score); 
	           // System.out.println("BestSolution�ķ���: "+ this.BestSolution.K2Score); 
	            long end = System.currentTimeMillis();
	            long interTime = end - start;
	            SingleAFSA.bestOccurTime[t] = interTime;
	            if(t>=1){
	            if (G_b.K2Score > this.BestSolution.K2Score)
	            {
	                this.BestSolution = G_b;
	                SingleAFSA.bestOccur = t;
	            }
	            }
	            else{
	            	this.BestSolution = G_b;
	                SingleAFSA.bestOccur = t;
	            }
	            System.err.format("\n��Ⱥ��������,���Ž������[%f]��", BestSolution.K2Score);
	            System.out.println(this.BestSolution);
	            //System.err.println("�������" + K2.count);
	        }
			

		return this.BestSolution;
	}

	public double distance(Singlefish a, Singlefish b)// ����������֮��ľ���
	{
		double x = 0;

		for (int i = 0; i < a.list.size(); i++) {
			x = a.list.get(i) - b.list.get(i); // ����ڵ�����ľ���ֵ
			// x=Math.abs(a.list.get(i)-b.list.get(i));
			dist = dist + Math.signum(x); // ����Ϊ��x=0��+0��x<0,-1;x>0,+1
			dist = Math.abs(dist);
		}
		return dist;
	}

	public int samedis(Singlefish a, Singlefish b)// ���������㼴���˳������ͬ�������
	{
		double x = 0;
		int sum = 0;
		for (int i = 0; i < a.list.size(); i++) {
			x = Math.abs(a.list.get(i) - b.list.get(i));
			if (Math.signum(x) == 0) // ��������Ϊ0����֤���ô����˳����ͬ
			{
				sum++;
			}
		}
		return sum;

	}
    
	public int diff(Singlefish a, Singlefish b)//�õ������е�һ����ͬ��λ��
	{
		int te1=0;
		for (int i = 0; i < a.list.size(); i++) {
		if(a.list.get(i)!=b.list.get(i))
		{
			te1=i;//�õ���Ų�ͬ�ĵط���λ��
			break;
		}
		}
	   return te1;
	}
	 public int findsame(Singlefish a, Singlefish b,int c)
	 {
		 int te2=0;
		for (int i = 0; i < a.list.size(); i++) {
			if(a.list.get(c)==b.list.get(i))
			{
				te2=i;//�õ���Ų�ͬ�ĵط���λ��
			}
			}
		   return te2;
	 
	 }
	 
	public BNGraph move(Singlefish a,int b,int c)
	{
		BNGraph gp=a.getBNgraph();
	    BNNode te1=gp.GetNode(b);
	    BNNode te2=gp.GetNode(c);
	    BNNode te3,te4;
		te1.GetChildNodes();
		te1.GetParentNodes();
		return a.getBNgraph();
	}
	
	
	public BNGraph zhuiwei(Singlefish a)
	{
		//tempzhui.addAll(listfish);//����Ⱥ��Ϣ���п���
		double maxsc=0.0;
		int index=0;
		int acc=0;
		for(int k=0;k<fishnum;k++)
		{/*
			if(tempzhui.get(k).getBNGraphScore()>maxsc)
			{
				maxsc=tempzhui.get(k).getBNGraphScore();//ȡ����Ⱥ�������
			    index=k;//�õ�����ı��
			}*/
			    if(listfish.get(k).getBNGraphScore()>maxsc)
			    {
			    	maxsc=listfish.get(k).getBNGraphScore();//ȡ����Ⱥ�������
				    index=k;//�õ�����ı��
			    }
		}
		if(acc==0)
		zhui= a.getBNgraph();
		if(a.getBNGraphScore()>=maxsc)
		{
			zhui= a.getBNgraph();
		//	  System.out.println("aa");
		return zhui;
		}
		else
		{
		   BNg tem=new BNg(zhui,score);
		   int tem1=diff(a,listfish.get(index));//���������������˳��ͬ��λ��
		   int tem2=findsame(a,listfish.get(index),tem1);
		   System.out.println(zhui.getScore());
		   System.out.println(tem1);
		   System.out.println(tem2);
		   
		  //��ͼ�����ƶ�����
		   if(acc!=0)
		  tem.Move(tem1, tem2);
		 //  exchange()
		   acc++;
		  //ͼ����
		   Collections.swap(a.list,tem1,tem2);
		 ///  zhui=tem.gopt;
		 //  System.out.println(tem.gopt.getScore());
		   //System.out.println(tem.gold.getScore());
		   //zhui=(BNGraph)tem.gopt.clone();
		 return zhui;
		}
			
		
	}
	
	public BNGraph juqun(Singlefish a)
	{
		int acc=0;
		
		  //��������ھ�
		for (int i = 0; i < fishnum; i++) {
			for (int j = 0; j < fishnum; j++) {
				if (distance(listfish.get(i), listfish.get(j)) < 3 && i != j) {
					Singlelinju a1 = new Singlelinju(listfish.get(i),
							listfish.get(j), distance(listfish.get(i),
									listfish.get(j)));
					
					neifish.add(a1);

				}
			}

		}
		/*
		//��ӡÿ������ھ�
		for (int i = 0; i < neifish.size(); i++)
			System.out.format("��[%d]���ھ�[%d]����Ϊ [%f]\n", neifish.get(i)
					.getFish1().code, neifish.get(i).getFish2().code, neifish
					.get(i).getDis());
					*/
					
		//Ѱ����Ⱥ����
		for (int i = 0; i < fishnum; i++) {
			for (int j = 0; j < fishnum; j++) {
				if(samedis(listfish.get(i),listfish.get(j))>maxsame)
				{
				maxsame=samedis(listfish.get(i),listfish.get(j));
				maxcode=i;
				}
			}
		}
		if(acc==0)
			ju= a.getBNgraph();
         acc++;
		for(int p=0;p<fishnum;p++)
		{
			BNg temp=new BNg(ju,score);
		 int tem1=diff(listfish.get(p),listfish.get(maxcode));
		   int tem2=findsame(listfish.get(p),listfish.get(maxcode),tem1);
		   temp.Move(tem1, tem2);
		}
	//	System.out.println("cc");
		ju=listfish.get(maxcode).getBNgraph();
		
		
	   return ju;
	}
	public BNGraph mishi(BNGraph G_k){
	    	BNg neighbor=new BNg(G_k,this.score);
	    	G_k=neighbor.BN1(); 	
	    	return G_k;
	    }
	public BNGraph mishi(Singlefish a)
	{
		mi=a.getBNgraph();
		mishi(mi);
		System.out.println("��ʳ");
		 System.out.println(mi.getScore());

		 return mi;
	}
	
	private static java.lang.StringBuilder sb;

	public static void main(String[] args) {
		sb = new java.lang.StringBuilder();
		try {
			// ���ݼ���Ϣ
			String DatasetFile = "E:\\copybnj1225\\data\\alarmacob.txt";// Asia1000.txt";
			int Vexnum = 37;// 37�����;

			int[] DatasetNum = { 6000 };// 2000
			// ��־��Ŀ¼
			String LogDirRoot = "d:\\alarm2000\\newABC-B\\";
			// ʵ������
			ArrayList<K2.TYPE> types = new ArrayList<K2.TYPE>();
			types.add(K2.TYPE.ORI);
			Iterator it = types.iterator();
			while (it.hasNext()) {
				K2.TYPE SearchType = (K2.TYPE) it.next();
				String type = SearchType.toString();// ORI3000
				for (int count = 0; count < DatasetNum.length; count++) {
					sb.append("\n" + type + DatasetNum[count]);

					AlarmReader ar = new AlarmReader(DatasetFile,
							DatasetNum[count], Vexnum);// 37
					String[][] dataset = ar.GetDataSet();
					Score k2 = new K2(dataset);

					String dir1 = LogDirRoot + "\\" + type
							+ Integer.toString(DatasetNum[count]);// C:\\ACOB\\ORI3000\\0.XLS

					PrintWriter StatisticsWriter = CommonTools.getPrintWriter(
							dir1, "Alarm.csv");
					StatisticsWriter
							.println("����,����,����,����,����,ʱ��,����,����,ʵ�ʼ���,����ʱ��");
					int fishnum = 40;

					for (int i = 0; i < 10; i++)// 10
					{
						k2.clearCache();
						// ����־
						PrintWriter SoluLogWriter = CommonTools.getPrintWriter(
								dir1, Integer.toString(i) + ".csv");

						BNGraph gk2sn = new BNGraph(Vexnum);

						double[] lastphaseScore = new double[fishnum];
						double[] thisphaseScore = new double[fishnum];

						for (int j = 0; j < fishnum; j++) {
							lastphaseScore[j] = Double.NEGATIVE_INFINITY;
							thisphaseScore[j] = Double.NEGATIVE_INFINITY;
						}
						int[] trial = new int[fishnum];
						for (int j = 0; j < fishnum; j++)
							trial[j] = 0;
						double bestScore = Double.NEGATIVE_INFINITY; // �ҳ���һ�������ŷ�

						long start = System.currentTimeMillis();
						SingleAFSA sa = new SingleAFSA(gk2sn, 100, 1, 5, 0.618,
								10, fishnum, SearchType, k2);
						sb.append("\r\n");
						gk2sn = sa.findBestBayesianNet(lastphaseScore,
								thisphaseScore, trial, bestScore);

						long end = System.currentTimeMillis();

						SoluLogWriter.println(sa.BestSolution);
						// ȡ�ñ�׼ͼ
						BNGraph stardard = BNGraph.GetGraphStandAlarm();

						SoluLogWriter.println(BNGraph.CompareGraph(stardard,
								gk2sn));
						SoluLogWriter.println(BNGraph.CompareGraph2(stardard,
								gk2sn));
						SoluLogWriter.println("��õĽⷢ����" + SingleAFSA.bestOccur
								+ "��");
						SoluLogWriter.println("��Ⱥ�ܹ�����ʱ�䣺" + (start - end)
								+ "ms");
						StatisticsWriter
								.print(BNGraph.CompareGraph2(stardard, gk2sn)
										+ ","
										+ SingleAFSA.bestOccur
										+ ","
										+ (end - start)
										+ ","
										+ K2.count
										+ ","
										+ K2.cacheCount
										+ ","
										+ K2.actualCalcCount
										+ ","
										+ SingleAFSA.bestOccurTime[SingleAFSA.bestOccur]
										+ "\r\n");
						SoluLogWriter.close();
						System.out.print("time:" + (end - start) / 1000 + "s");
					}
					PrintWriter LogscoreNew = CommonTools.getPrintWriter(dir1,
							"i_score.csv");
					LogscoreNew.print(sb);

					LogscoreNew.close();
					StatisticsWriter.close();
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}