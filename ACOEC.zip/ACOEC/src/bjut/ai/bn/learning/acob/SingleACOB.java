package bjut.ai.bn.learning.acob;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;
import java.util.TreeSet;

//import bjut.ai.bn.AlarmReader;
import bjut.ai.bn.learning.acob.AlarmReader;
import bjut.ai.bn.BNGraph;
//import bjut.ai.bn.CommonTools;
import bjut.ai.bn.learning.acob.CommonTools;
import bjut.ai.bn.HillClimbing;
//import bjut.ai.bn.converter;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;
import bjut.ai.bn.Neighborhood;

public class SingleACOB //implements Cloneable 
{
	private final Random RANDOM;
	public static double[][] tempH = null;//��Ϣ�ؾ���
	public static double[] noParVexK2Value = new double[K2.VEXNUM];
	// ȫ����Ϣ�ؾ���
	public static double GlobalPheromoneMatrix[][] = new double[K2.VEXNUM][K2.VEXNUM];
	public static int bestOccur = 0;//���Ŵ���
	public static long[] bestOccurTime = new long[2000];//���Ŵ�������ʱ��

	private static int solutionCount = 0;//��Ĵ������ǵ����Ǹ��Ĳ�����
	public static BNGraph[] bestSolutions;  //���Ž�ṹ
	//public static double[] bestSolutionsScore;
	public static int LogK2ScoreCount = 0;
    public int vexnum;       //����
    public Score score = null; //����
	public BNGraph BestSolution;  //���Ž�  ����this.BestSolution.K2Score��ʾ���Ž�����
    private int count;
    private BNGraph gk2sn;
    private int tStep;
    private int tMaxStep;
    private int antNum;
    private double alpha;
    private double beta;
    private double rou;
    private double q0;
    private double tao0; //��ʼ��Ϣ��
    private K2.TYPE type;
    
    private int maxnum;//�����ͬ�������
    
    private java.util.ArrayList<Double> BestScore; // ÿһ�������ŷ�ֵ
    private java.util.TreeSet<Integer> setOpted; //�Ѿ������Ż�������ֵ
    private int BestScoreIndex; //��ǰ������ֵ��������

    
    private int limit = 3;//#��ת���õ��Ĳ���

    private java.util.Random AnnealRandom = new Random();//�˻������

    public SingleACOB(BNGraph gk2sn, double alpha, double beta, double rou, double q0, int tStep,
                      int tMaxStep, int antNum, K2.TYPE type1, Score score)
    {
//    //���k2sn�Ľ� ��ʽ��
    	RANDOM = new Random();
    	this.score = score;
        this.gk2sn = gk2sn;
        this.vexnum = gk2sn.getVexNum();
        SingleACOB.tempH = new double[vexnum][vexnum];
        this.tao0 = 1 / (vexnum * Math.abs(this.score.calcGraphScore(this.gk2sn)));
        this.BestSolution = gk2sn;
        //��ʱ
        this.antNum = antNum;
        this.tMaxStep = tMaxStep;
        this.tStep = tStep;
        this.alpha = alpha;
        this.beta = beta;
        this.rou = rou;
        this.q0 = q0;
        bestSolutions = new BNGraph[this.antNum];
        this.type = type1;
        switch (type)
        {
            case ORI:
                System.err.println("ԭʼ");
                this.BestScore = new ArrayList<Double>();
            	this.setOpted = new TreeSet<Integer>();
                this.initheuristicInfo();
                SingleACOB.initalGlobalPheromene(this.tao0);
                break;
            case SA:
            	System.err.println("ģ���˻��Ż�");
            	this.BestScore = new ArrayList<Double>();
            	this.setOpted = new TreeSet<Integer>();
                this.initheuristicInfo();
                SingleACOB.initalGlobalPheromene(this.tao0);
                break;          	
            case CI:
			System.err.println("CI����");
        	this.BestScore = new ArrayList<Double>();
        	this.setOpted = new TreeSet<Integer>();
			this.initheuristicInfo();
			SingleACOB.initalGlobalPheromene(this.tao0);
			//SingleACOB.CIConstrain(((K2) score).getRecord());
			break;
			}
    }

    public void setScoreMetric(Score s)
    {
    	this.score = s;
    }
    public static void initalGlobalPheromene(double tao0)
    {
        for (int i = 0; i < SingleACOB.GlobalPheromoneMatrix.length; i++)
        {
            for (int j = 0; j < SingleACOB.GlobalPheromoneMatrix[i].length; j++)
            {
                if (i != j)
                {
                	SingleACOB.GlobalPheromoneMatrix[i][j] = tao0;
                }
                else
                {
                	SingleACOB.GlobalPheromoneMatrix[i][j] = Double.NEGATIVE_INFINITY;
                }

            }
        }
    }

    public void initheuristicInfo()
    {
        BNGraph temp = new BNGraph(this.vexnum);
        ArrayList<Integer> anodelist = new ArrayList<Integer> (); //��ʱ
        //System.out.println("��ʼ��������Ϣ����");
        long start = System.currentTimeMillis();
        for (int i = 0; i < this.vexnum; i++)
        {
            SingleACOB.noParVexK2Value[i] = this.score.calcScore(i,anodelist);

            for (int j = 0; j < this.vexnum; j++)
            {
                if (i != j)
                {
                    anodelist.add(j);
                    SingleACOB.tempH[i][j] = this.score.calcScore(temp.GetNode(i).
                            GetNodeId(), anodelist) - SingleACOB.noParVexK2Value[i];
                    anodelist.remove(0);
                }
                else
                    SingleACOB.tempH[i][j] = Double.NEGATIVE_INFINITY;
            }
        }

        long end = System.currentTimeMillis();
        System.out.format("���,����[%d]����\n", end - start);
//        System.out.println("24-0��ֵ" + SingleACOB.tempH[24][0]);
//        System.out.println("0-24��ֵ" + SingleACOB.tempH[0][24]);
    }

    public static void addToSolutionSet(BNGraph b)
    {
        SingleACOB.bestSolutions[SingleACOB.solutionCount] = b;
    }

    public static void addToSolutionSet(BNGraph b,int k)
    {
        SingleACOB.bestSolutions[k] = b;
    }
    
    public BNGraph getBestSolution()
    {
        Arrays.sort(SingleACOB.bestSolutions);
        return SingleACOB.bestSolutions[SingleACOB.bestSolutions.length - 1];
    }


    
    public BNGraph findBestBayesianNet(double[] lastphaseScore,double[] thisphaseScore,int[] trial,double bestScore) 
    {
        long start = System.currentTimeMillis();
        BNGraph G_b;
        this.BestScore.clear();
        this.setOpted.clear();

        
        //double badScore= Double.POSITIVE_INFINITY;  
        SingleACOB.solutionCount = 0;
        ////////////////////Initialization��ʼ��////////////////////
 
        for (int k = 0; k < antNum; k++)
        {
           
        	System.out.format("���ɵ�[%d]ֻ��\n", count);            
            count++;//countΪ����
            
            SingleAntB temp = new SingleAntB(this.alpha, this.beta,this.rou, this.q0,this.tao0, K2.VEXNUM,this.type,SingleACOB.tempH,this.score);
            temp.runRandomSolution2(k);//��ʼ����Ⱥ
           // temp.runRandomSolution2();
            double currentAntScore = SingleACOB.bestSolutions[SingleACOB.solutionCount].K2Score;
            thisphaseScore[k] = currentAntScore;
            if (currentAntScore > bestScore)
            {
                //�õĽ�
                bestScore = currentAntScore;   
                this.BestScoreIndex = k;  //kΪ��ǰ�������ţ���������Ϊ��߷���
            }
            SingleACOB.solutionCount++;
        }

        ///////////////////////Loop////////////////////////
        
        for (int t = 0; t < tMaxStep; t++)
        {       	
            for(int i=0;i<antNum;i++){
            	lastphaseScore[i]=thisphaseScore[i];//ѭ����¼�ϴ�����
            }
              /*
        	////////////Neighbor search phases of employed bees/////////
        	 for (int k = 0; k < antNum; k++){
        	   this.bestSolutions[k]=this.Neighborhood2(this.bestSolutions[k],'e');
        	    thisphaseScore[k]=this.bestSolutions[k].K2Score;
           		 
        	 }//��¼��ǰ���ֺ��ھӽ������
        	 */
            
        	 //��Ⱥ
        	 double[]middle = new double[antNum];//���Ľ������
        	 for (int k = 0; k < antNum; k++){//ѡ���󴴽��ھӽ�
        		 //��һ����Ҷ˹�������ھӽ�
        	 
          	   SingleACOB.bestSolutions[k]=this.Neighborhood2(SingleACOB.bestSolutions[k],'e');
          	    thisphaseScore[k]=SingleACOB.bestSolutions[k].K2Score; 
          	    
          	    if (thisphaseScore[k] == bestScore){
        		 middle[k]= thisphaseScore[k];
             		 
          	 }//middleΪ��������
        	 }
        	 //׷β
          	/* 
          	 for (int i = 0; i < antNum; i++){

          	  if (thisphaseScore[i] > bestScore)//maxС�ڵ�ǰ�˹���÷�
          	  {
          		bestScore = thisphaseScore[i];   
                this.BestScoreIndex = t;  
          	  }
          	if (thisphaseScore[i] < bestScore)//max���ڵ�ǰ�˹���÷�
        	  {
        		
        		thisphaseScore[i] =bestScore;//��ѡ����ߵ÷�               
        	  }
          	 }
         // 	thisphaseScore[t]?
          	 
        	
           ////////////Neighbor search phases of onlookers/////////////// 
        	
        	//���̶ķ�������ÿ�����ѡ����ʣ�
 	        double[]probability = new double[antNum];
 	        double q = RANDOM.nextDouble();
 	        double sumvalue = 0.0;
 	        double value = 0.0;
 	        for (int i = 0; i < antNum; i++){
 	        	   //thisphaseScore[i]=this.bestSolutions[i].K2Score;
 	               if (thisphaseScore[i] < 0){
 	                   probability[i]= -1/thisphaseScore[i];
 	            	   sumvalue += probability[i]; //���
 	               }
 	               else{
 	                   probability[i] = 0.0;
 	               }
 	        }
 	        for (int i = 0; i < antNum; i++){
 	             probability[i]/= sumvalue; //���Ժ�
 	        }
        	//���̶ķ�(Ϊÿһ��onlookerѡȡһ����)
        	for (int k = 0; k < antNum; k++){ 
        		q = RANDOM.nextDouble();
        	    while (q <= 0.0)
        	       q = RANDOM.nextDouble();
        	    value = 0.0;
        	     for (int i = 0; i < antNum; i++){
        	         value += probability[i]; //�ۼ�ֱ������q
        	         if (value >= q){
        	        	 //onlookerѡ���󴴽��ھӽ�
        	        	 this.bestSolutions[i]=this.Neighborhood2(this.bestSolutions[i],'e');
        	         	  thisphaseScore[i]=this.bestSolutions[i].K2Score;
        	              break ;
        	          }
        	      }
         	 }
        	
            ////////////Exploring new solutions by scouts/////////////// 
            for (int k = 0; k < antNum; k++)
            {
            	if(thisphaseScore[k]==lastphaseScore[k])
            		trial[k] = trial[k]+1; //���������ͬ���Ϊ�ھ�
            	else
            		trial[k] = 0;
                if(trial[k]>=limit){  //�����ͬ���������ڵ���3.�ھӶ���Ϊ<=2
                	SingleAntB temp1 = new SingleAntB(this.alpha, this.beta,this.rou, this.q0,this.tao0, K2.VEXNUM, this.type,this.tempH,this.score);
                	temp1.run2(k);//�����µ���
                    thisphaseScore[k] = this.bestSolutions[k].K2Score;//�õ�����
                    //System.out.println(k);
                    //System.out.println(currentAntScore);
                    //System.out.println("scout"+k+"  "+ thisphaseScore[k]);
                    trial[k] = 0;//�������
//                  System.out.println("��������⻨����" + (end - start) + "ms");
                }
            }*/
            /**/
            newneighbr(lastphaseScore,thisphaseScore,trial,bestScore);
            
            //�����Ż�
            if ( (t % tStep) == 0 && t != 0)
            {
                //System.out.println("�����Ż�"+ t);
                for (int i = 0; i < antNum; i++){
                     SingleACOB.bestSolutions[i] = this.HillClimbing(SingleACOB.bestSolutions[i]);
                     thisphaseScore[i]=SingleACOB.bestSolutions[i].K2Score;
                }
             }
        	
            for (int m = 0; m < antNum; m++)
            {            
                if (thisphaseScore[m] > bestScore)
                {
                    //�õĽ�
                    bestScore = thisphaseScore[m];
                    this.BestScoreIndex = m;
                    //this.thisphaseBestScore = thisphaseScore[k];
                }
            }
          //  System.out.println("���������" + t+" ��СΪ: "+bestScore );
            this.BestScore.add(bestScore); //��¼��ǰantNum ���ϵ����Ž�               
            G_b = this.getBestSolution();
         //   System.out.println("G_b��������: "+ G_b.K2Score); 
          //  System.out.println("BestSolution�ķ���: "+ this.BestSolution.K2Score); 
            long end = System.currentTimeMillis();
            long interTime = end - start;
            SingleACOB.bestOccurTime[t] = interTime;
            if(t>=1){
            if (G_b.K2Score > this.BestSolution.K2Score)
            {
                this.BestSolution = G_b;
                SingleACOB.bestOccur = t;
            }
            }
            else{
            	this.BestSolution = G_b;
                SingleACOB.bestOccur = t;
            }
            //System.err.format("\n������������Ⱥ��������,���Ž������[%f]����������", BestSolution.K2Score);
            //System.out.println(this.BestSolution);
            //System.err.println("�������" + K2.count);

        }
        
        return this.BestSolution;
    }
    
    static int MaxEqualStep = 50;
   
    /**
     * ��ɽ�Ż�
     * @param G_k BNGraph
     * @return BNGraph
     */
    public BNGraph HillClimbing(BNGraph G_k)
    {
        HillClimbing hill = new HillClimbing(G_k,this.score);
        if (this.type == K2.TYPE.OP)
        {
            G_k = hill.OptimizeBN_CI();
        }
        else
        {
            G_k = hill.OptimizeBN();
        }
        return G_k;
    }
    //�����ھӽ�
    public BNGraph Neighborhood2(BNGraph G_k,char c){
    	Neighborhood neighbor=new Neighborhood(G_k,this.score);
    	G_k=neighbor.NeighborEmployedBN1(); 	
    	return G_k;
    }
    /**
     * �ֲ��Ż�
     */
    public void localOptimizate()
    {
        BNGraph temp = new BNGraph(this.vexnum);
        System.out.println("���ľֲ��Ż�");
        for (int i = 0; i < SingleACOB.bestSolutions.length; i++)
        {
            SingleACOB.bestSolutions[i] = this.HillClimbing(SingleACOB.bestSolutions[i]);
        }
        temp = this.getBestSolution();
        if (temp.getScore() > this.BestSolution.getScore())
        {
            this.BestSolution = temp;
        }

    }

    private int neighbr(SingleAntB a,SingleAntB b)//�ж�2�����Ƿ�Ϊ�ھӣ����Ϊ�ھӼ�����ͬ�������
    {
    	//SingleAntB temp1 = new SingleAntB(this.alpha, this.beta,this.rou, this.q0,this.tao0, K2.VEXNUM, this.type,this.tempH,this.score);
    	//temp1.runRandomSolution2(k);
    	double dis;
    	int maxnum=0;//�����ͬ�������
    	dis=a.distance(a,b);
    	if(dis<=2)//�������С�ڵ���2��������Ŀ��ӷ�Χ�ڣ����ж�Ϊ�ھ�
    	{
    		maxnum=a.samedis(a, b);  //��������ͬ�������Ϊ��ǰ������
    	}
    	return maxnum;
    }
    
    private void newneighbr(double[] lastphaseScore,double[] thisphaseScore,int[] trial,double bestScore)
    {
    	  for (int k = 0; k < antNum; k++)
          {
          	if(thisphaseScore[k]==lastphaseScore[k])
          		trial[k] = trial[k]+1; //���������ͬ���Ϊ�ھ�
          	else
          		trial[k] = 0;
              if(trial[k]>=limit){  //�����ͬ���������ڵ���3.�ھӶ���Ϊ<=2
              	SingleAntB temp1 = new SingleAntB(this.alpha, this.beta,this.rou, this.q0,this.tao0, K2.VEXNUM, this.type,SingleACOB.tempH,this.score);
              	temp1.run2(k);//�����µ���
                  thisphaseScore[k] = SingleACOB.bestSolutions[k].K2Score;//�õ�����
                  trial[k] = 0;//�������
              }
          }
      	
    }
    
    private static java.lang.StringBuilder sb;
    public static void main(String[] args)
    {
        sb = new java.lang.StringBuilder();
        try
        {
            //���ݼ���Ϣ
			//String DatasetFile = "D:\\data\\Asia.txt";
			String DatasetFile = "E:\\copybnj1225\\data\\alarmacob.txt";//Asia1000.txt";
//            String DatasetFile = "alarm-bnpc-10000.txt";
        	//String DatasetFile = "D:\\data\\Insurance_s10000.txt";
        	//String DatasetFile = "D:\\data\\child_10000.txt";
           int Vexnum = 37;//37;
          // int Vexnum = 27;
			 //int Vexnum = 8;
            int[] DatasetNum ={6000};//2000
            //��־��Ŀ¼
            String LogDirRoot = "d:\\alarm2000\\newABC-B\\";
            //String LogDirRoot = "d:\\alarm2000\\abcchild_10000\\";
            //ʵ������
            ArrayList<K2.TYPE> types = new ArrayList<K2.TYPE> ();
            types.add(K2.TYPE.ORI);
            Iterator it = types.iterator();
            while (it.hasNext())
            {
                K2.TYPE SearchType = (K2.TYPE)it.next();
                String type =  SearchType.toString();//ORI3000
                for (int count = 0; count < DatasetNum.length; count++)
                {
                    sb.append("\n"+type+DatasetNum[count]);
                    
                    // AlarmReader ar = new AlarmReader(DatasetFile,DatasetNum[count],37);
                   AlarmReader ar = new AlarmReader(DatasetFile,DatasetNum[count],Vexnum);//37);
					// String[][] dataset = ar
					// .readGeNIeDataToBjutDatanum(DatasetFile);
                    
					String[][] dataset = ar.GetDataSet();
//					 String[][] dataset_num = converter.tranStringDataToNumData(dataset);

					Score k2 = new K2(dataset);
                    
                    String dir1 = LogDirRoot +"\\"+ type +Integer.toString(DatasetNum[count]);//C:\\ACOB\\ORI3000\\0.XLS
                   // System.out.println(dir1);
                    PrintWriter StatisticsWriter = CommonTools.getPrintWriter(dir1, "Alarm.csv");
                    StatisticsWriter.println("����,����,����,����,����,ʱ��,����,����,ʵ�ʼ���,����ʱ��");
                    int antNum=40;
                    //BNGraph stardard = BNGraph.GetGraphStandAlarm();
                    for (int i = 0; i < 10; i++)//10
                    {
						 k2.clearCache();
                        //����־
                        PrintWriter SoluLogWriter = CommonTools.getPrintWriter(dir1,Integer.toString(i)+".csv");

                        BNGraph gk2sn = new BNGraph(Vexnum);
                        
                        double[] lastphaseScore = new double [antNum];
                        double[] thisphaseScore = new double [antNum];
                        
                        for(int j=0;j<antNum;j++){
                        	lastphaseScore[j]=Double.NEGATIVE_INFINITY;
                        	thisphaseScore[j]=Double.NEGATIVE_INFINITY;
                        }
                        int[] trial = new int[antNum];
                        for(int j=0;j<antNum;j++)
                        	trial[j]=0;
                        double bestScore = Double.NEGATIVE_INFINITY; //�ҳ���һ�������ŷ�
                        
                        long start = System.currentTimeMillis();
                        //SingleACOB sa = new SingleACOB(gk2sn, 1.0, 2.0, 0.6, 0.8, 10, 100, 50,SearchType,k2);
                        SingleACOB sa = new SingleACOB(gk2sn, 1.0, 2.0, 0.15, 0.8, 25,100, antNum,SearchType,k2);//tstep 10->5 rou:0.4 q0=0.9
                        sb.append("\r\n");
                        gk2sn = sa.findBestBayesianNet(lastphaseScore,thisphaseScore,trial,bestScore) ;
                        
                        long end = System.currentTimeMillis();

//                        System.err.println("��Ⱥ�ܹ�����ʱ�䣺" + (start - end) + "ms");
//                        System.err.format("\n������������Ⱥ��������,���Ž������[%f]����������", sa.BestSolution.K2Score);
//                        System.out.println(sa.BestSolution);

                        SoluLogWriter.println(sa.BestSolution);
                        //ȡ�ñ�׼ͼ
                        // BNGraph stardard = BNGraph.GetGraphStandChild();
                      // BNGraph stardard = BNGraph.GetGraphStandInsurance();
                       BNGraph stardard = BNGraph.GetGraphStandAlarm();
                        // BNGraph stardard = BNGraph.GetGraphStandAsia();
                        // Score k12 = new K2(dataset);
                        // System.err.println("��׼ͼ"+k12.calcGraphScore(stardard));

                        SoluLogWriter.println(BNGraph.CompareGraph(stardard, gk2sn));
                        SoluLogWriter.println(BNGraph.CompareGraph2(stardard,gk2sn));
                        SoluLogWriter.println("��õĽⷢ����" + SingleACOB.bestOccur + "��");
                        SoluLogWriter.println("��Ⱥ�ܹ�����ʱ�䣺" + (start - end) + "ms");
                        StatisticsWriter.print(BNGraph.CompareGraph2(stardard, gk2sn) + ","
                                      + SingleACOB.bestOccur
                                      + "," + (end - start) + "," + K2.count
                                      + "," + K2.cacheCount + "," + K2.actualCalcCount + ","
                                      + SingleACOB.bestOccurTime[SingleACOB.bestOccur] + "\r\n");
                        SoluLogWriter.close();
                        System.out.print("time:"+ (end-start)/1000+"s");
                    }
                    PrintWriter LogscoreNew = CommonTools.getPrintWriter(dir1,"i_score.csv");
                    LogscoreNew.print(sb);
                    
                    LogscoreNew.close();
                    StatisticsWriter.close();
                }
            }

        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }

    }
}
