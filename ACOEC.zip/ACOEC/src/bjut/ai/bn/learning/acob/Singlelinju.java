package bjut.ai.bn.learning.acob;

public class Singlelinju {

	private Singlefish fish1, fish2;
	private double dis;

	public Singlelinju(Singlefish fish1, Singlefish fish2, double dis) {
		this.fish1 = fish1;
		this.fish2 = fish2;
		this.dis = dis;
	}

	public Singlefish getFish1() {
		return fish1;
	}

	public void setFish1(Singlefish fish1) {
		this.fish1 = fish1;
	}

	public Singlefish getFish2() {
		return fish2;
	}

	public void setFish2(Singlefish fish2) {
		this.fish2 = fish2;
	}

	public double getDis() {
		return dis;
	}

	public void setDis(int dis) {
		this.dis = dis;
	}

}
