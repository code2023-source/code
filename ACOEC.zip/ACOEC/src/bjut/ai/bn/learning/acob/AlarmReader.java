//����:�����ݴ��ļ�������Ļǰ̨
package bjut.ai.bn.learning.acob;

import java.io.*;
import java.util.*;

//import bjut.ai.bn.AlarmReader;

//import bjut.ai.bn.AlarmReader;

public class AlarmReader {//implements {DataSetReader{
	  public String FileName;
	  public String[][] DataSet;
	  public int RecordNum;
	  public int AttributeNum;


	  public AlarmReader(String FileName, int RecordNum, int AttributeNum)
	  {
	    this.FileName = FileName;
	    this.RecordNum = RecordNum;
	    this.AttributeNum = AttributeNum;
	    DataSet = new String[this.RecordNum][this.AttributeNum];
	  }
	  //����c�е�ȡֵ���,����һ��������
	  public TreeSet[] getColumnValue()//c [0,36]
	  {
	    TreeSet<String>[] ts = new TreeSet[AttributeNum];
	    for(int k = 0; k < AttributeNum; k++)
	    {
	      ts[k] = new TreeSet();
	    }
	    for(int i = 0; i < RecordNum; i++)
	    {
	      for(int j = 0; j < AttributeNum; j++)
	      {
	    	  //System.out.print(DataSet[i][j]+"  ");
	    	  ts[j].add(DataSet[i][j]);
	      }
	    }
	    return ts;
	  }

	  public String[][] GetDataSet()
	  {
	    int row = 0;

	    try
	    {
	      BufferedReader br = new BufferedReader(new FileReader(FileName));
	      String line = br.readLine();
	      while(line != null && row < RecordNum)
	      {
	          line = line.trim();
	          line=line.replaceAll(","," ");
	      //  DataSet[row] = line.split("[\\s],+");//������,�ֿ�
	        
	        DataSet[row] = line.split("[\\s]+");//�����ÿո�ֿ�
	        line = br.readLine();
	        row++;
	      }
//	      System.out.println(Arrays.asList(DataSet[4999]));
	      br.close();
	    }
	    catch (Exception ex)
	    {
	      ex.printStackTrace();
	    }
	    return DataSet;
	  }

	  //for test only
	  public void outArray(String[][] s)
	  {
	      for(int i = 0; i < s.length; i++)
	      {
	          for(int j = 0; j < s[i].length; j++)
	          {
	              System.out.print(s[i][j]+"  ");
	          }
	          System.out.println();
	      }
	  }
	  public static void main(String[] args)
	  {
	   // AlarmReader ar = new AlarmReader("Insurance_s5000_v1.txt",1,27);
	  //  AlarmReader ar = new AlarmReader("data\\alarmacob.txt", 1000, 37);
	    AlarmReader ar = new AlarmReader("F:\\sim1.txt", 2000, 5);
	    ar.outArray(ar.GetDataSet());

	   // System.out.println("ssssssssssssssssssssssssssssssss");
	    
	    TreeSet[] ts = ar.getColumnValue();
	    System.out.println("");

	  }
}
