package bjut.ai.bn;

import java.util.Collections;

import bjut.ai.bn.score.Score;
public class BNNode implements Cloneable {
  //ͼ�����ʶ
  private int NodeId = 0;
  //���ڵ㼯��
  //private java.util.ArrayList<BNNode> NodeParent = null;
  private java.util.HashMap<Integer, BNNode> NodeParent = null;
  //���ӽڵ㼯��
  //private java.util.ArrayList<BNNode> NodeChild = null;
  private java.util.HashMap<Integer, BNNode> NodeChild = null;
  //�Ƿ񱻱���
  private boolean IsVisited = false;

  //���ڵ㼯�Ͻ��ɱ�
  private java.util.HashMap<Integer, BNNode> NodeFP = null;

  //K2����
  public double K2Score = 0;
  public BNNode(int id) {
    this.NodeId = id;
    this.NodeParent = new java.util.HashMap<Integer, BNNode> ();
    this.NodeChild = new java.util.HashMap<Integer, BNNode> ();
    this.NodeFP = new java.util.HashMap<Integer, BNNode> ();
  }


  @Override
public Object clone()
//    throws CloneNotSupportedException
{

    BNNode nclone =null;
    try
    {
      nclone = (BNNode)super.clone();
      nclone.NodeParent = (java.util.HashMap<Integer, BNNode>)this.NodeParent.
          clone();
      nclone.NodeChild = (java.util.HashMap<Integer, BNNode>)this.NodeChild.
          clone();
      nclone.NodeFP = (java.util.HashMap<Integer, BNNode>)this.NodeFP.clone();
    }
    catch(Exception ex)
    {}
  return nclone;
}


  /**
   * ȡ�ýڵ���
   *
   * @return int
   */
  public int GetNodeId() {
    return this.NodeId;
  }

  /**
   * ȡ�ø��ڵ㼯�ϵı��
   *
   * @return java.util.ArrayList<Integer>
   */
  public java.util.ArrayList<Integer> GetParentNodesIndex() {
    BNNode node = null;
    java.util.ArrayList<Integer> arrParentNodeIndex = new java.util.ArrayList<
        Integer> ();
    java.util.Iterator<Integer> iter = this.NodeParent.keySet().iterator();
    while (iter.hasNext()) {
      node = this.NodeParent.get(iter.next());
      arrParentNodeIndex.add(node.GetNodeId());
    }
    Collections.sort(arrParentNodeIndex);
    return arrParentNodeIndex;
  }

  /**
   * ȡ�ø��ڵ㼯��
   *
   * @return java.util.ArrayList<BNNode>
   */
  public java.util.ArrayList<BNNode> GetParentNodes() {
    BNNode node = null;
    java.util.ArrayList<BNNode> arrParentNode = new java.util.ArrayList<BNNode> ();
    java.util.Iterator<Integer> iter = this.NodeParent.keySet().iterator();
    while (iter.hasNext()) {
      node = this.NodeParent.get(iter.next());
      arrParentNode.add(node);
    }

    return arrParentNode;
  }

  /**
   * ȡ�����Ƚڵ㼯�ϵı�ţ�������ǰ�ڵ�
   *
   * @return java.util.ArrayList<Integer>
   */
  public java.util.ArrayList<Integer> GetAncestorNodesIndex() {
    BNNode node = null;
    java.util.ArrayList<Integer> arrAncestorNodeIndex = new java.util.ArrayList<
        Integer> ();

    java.util.HashMap<Integer,
        BNNode> nodeAncestor = new java.util.HashMap<Integer, BNNode> ();
    //���ȼ��뵱ǰ�ڵ�
    nodeAncestor.put(this.NodeId, this);
    //�ݹ���������ڵ�
    this.AddAncestorNodetoHashMap(this, nodeAncestor);

    java.util.Iterator<Integer> iter = nodeAncestor.keySet().iterator();
    while (iter.hasNext()) {
      node = nodeAncestor.get(iter.next());
      arrAncestorNodeIndex.add(node.GetNodeId());
    }
    //����ArrayList
    return arrAncestorNodeIndex;
  }

  private void AddAncestorNodetoHashMap(BNNode node, java.util.HashMap<Integer,
                                        BNNode> nodeAncestor) {
    java.util.ArrayList<BNNode> parent = node.GetParentNodes();
    for (int i = 0; i < parent.size(); i++) {
      BNNode parentNode = parent.get(i);
      int parentNodeId = parentNode.GetNodeId();
      if (!nodeAncestor.containsKey(parentNodeId)) {
        if (!nodeAncestor.containsKey(parentNodeId)) {
          //�����ǰ�������ýڵ� �����
          nodeAncestor.put(parentNodeId, parentNode);
        }
        AddAncestorNodetoHashMap(parentNode, nodeAncestor);
      }
    }
  }

  /**
   * ȡ�����Ƚڵ㼯��
   *
   * @return java.util.ArrayList<BNNode>
   */
//  public java.util.ArrayList<BNNode> GetAncestorNodes() {
//	  BNNode node = null;
//	  java.util.ArrayList<BNNode> arrParentNode = new java.util.ArrayList<BNNode>();
//	  //�ȴ�ʵ��
//    return arrParentNode;
//  }


  /**
   * ȡ�ø��ڵ��ַ���
   *
   * @return String
   */
  public String GetParentNodeString() {

    java.lang.StringBuilder sb = new StringBuilder();
    BNNode node;
    java.util.Iterator<Integer> iter = this.NodeParent.keySet().iterator();
    while (iter.hasNext()) {
      node = this.NodeParent.get(iter.next());
      sb.append(node.toString());
      sb.append(" ");
    }
    return sb.toString();
  }

  /**
   * ȡ�ú��ӽڵ㼯�ϵı��
   *
   * @return java.util.ArrayList<Integer>
   */
  public java.util.ArrayList<Integer> GetChildNodesIndex() {
    BNNode node = null;
    java.util.ArrayList<Integer> arrChildNodeIndex = new java.util.ArrayList<
        Integer> ();

    java.util.Iterator<Integer> iter = this.NodeChild.keySet().iterator();
    while (iter.hasNext()) {
      node = this.NodeChild.get(iter.next());
      arrChildNodeIndex.add(node.GetNodeId());
    }

    return arrChildNodeIndex;
  }

  /**
   * ȡ�ú��ӽڵ㼯��
   *
   * @return java.util.ArrayList<BNNode>
   */
  public java.util.ArrayList<BNNode> GetChildNodes() {
    BNNode node = null;
    java.util.ArrayList<BNNode> arrChildNode = new java.util.ArrayList<BNNode> ();
    java.util.Iterator<Integer> iter = this.NodeChild.keySet().iterator();
    while (iter.hasNext()) {
      node = this.NodeChild.get(iter.next());
      arrChildNode.add(node);
    }

    return arrChildNode;
  }

  /**
   * ȡ�ú���ڵ㼯�ϵı�ţ�������ǰ�ڵ�
   *
   * @return java.util.ArrayList<Integer>
   */
  public java.util.ArrayList<Integer> GetDescendantNodesIndex() {
    BNNode node = null;
    java.util.ArrayList<Integer> arrChildNodeIndex = new java.util.ArrayList<
        Integer> ();

    java.util.HashMap<Integer,
        BNNode> nodeDescendant = new java.util.HashMap<Integer, BNNode> ();
    //���ȼ��뵱ǰ�ڵ�
    nodeDescendant.put(this.NodeId, this);
    //�ݹ������
    this.AddDescendantNodetoHashMap(this, nodeDescendant);

    java.util.Iterator<Integer> iter = nodeDescendant.keySet().iterator();
    while (iter.hasNext()) {
      node = nodeDescendant.get(iter.next());
      arrChildNodeIndex.add(node.GetNodeId());
    }
    //�ȴ�ʵ��
    return arrChildNodeIndex;
  }

  private void AddDescendantNodetoHashMap(BNNode node,
                                          java.util.HashMap<Integer, BNNode>
      nodeDescendant) {
    java.util.ArrayList<BNNode> child = node.GetChildNodes();
    for (int i = 0; i < child.size(); i++) {
      BNNode childNode = child.get(i);
      int childNodeId = childNode.GetNodeId();
      if (!nodeDescendant.containsKey(childNodeId)) {
        nodeDescendant.put(childNodeId, childNode);
        AddDescendantNodetoHashMap(childNode, nodeDescendant);
      }
    }
  }

  /**
   * ȡ�ú���ڵ㼯��
   *
   * @return java.util.ArrayList<BNNode>
   */
//  public java.util.ArrayList<BNNode> GetDescendantNodes() {
//	  BNNode node = null;
//	  java.util.ArrayList<BNNode> arrChildNode = new java.util.ArrayList<BNNode>();
//	  //�ȴ�ʵ��
//
//    return arrChildNode;
//  }

  /**
   * ȡ�ú��ӽڵ��ַ���
   *
   * @return String
   */
  public String GetChildNodeString() {

    java.lang.StringBuilder sb = new StringBuilder();
    BNNode node;
    java.util.Iterator<Integer> iter = this.NodeChild.keySet().iterator();
    while (iter.hasNext()) {
      node = this.NodeChild.get(iter.next());
      sb.append(node.toString());
      sb.append(" ");
    }
    return sb.toString();
  }

  /**
   * AddParentNode
   *
   * @param p BNNode
   */
  public void AddParentNode(BNNode parent) {
    if (!this.NodeParent.containsKey(parent.GetNodeId())) {
      this.NodeParent.put(parent.GetNodeId(), parent);
      //�������˸��ڵ㣬���¼�������
      //calcK2Score();
    }
  }

  public void RemoveParentNode(BNNode parent) {
    if (this.NodeParent.containsKey(parent.NodeId)) {
      this.NodeParent.remove(parent.NodeId);
      //�������˸��ڵ㣬���¼�������
      //calcK2Score();
    }
  }

  /**
   * AddForbiddenParent
   * ��ɽ�����õ� ������̽�����ֽ��͵ĸ��ڵ���븸�ڵ���ɱ�
   *
   * @param p BNNode
   */
  public void AddForbiddenParent(BNNode node) {
    if (!this.NodeFP.containsKey(node.GetNodeId())) {
      this.NodeFP.put(node.GetNodeId(), node);
    }
  }

  public java.util.ArrayList<Integer> getForbiddenParent() {
    BNNode node = null;
    java.util.ArrayList<Integer> arrFB = new java.util.ArrayList<Integer> ();
    java.util.Iterator<Integer> iter = this.NodeFP.keySet().iterator();
    while (iter.hasNext()) {
      node = this.NodeFP.get(iter.next());
      arrFB.add(node.GetNodeId());
    }

    return arrFB;
  }

  /**
   * AddChildNode
   *
   * @param c BNNode
   */
  public void AddChildNode(BNNode child) {
    if (!this.NodeChild.containsKey(child.GetNodeId())) {
      this.NodeChild.put(child.GetNodeId(), child);
    }
  }

  public void RemoveChildNode(BNNode child) {
    if (this.NodeChild.containsKey(child.NodeId)) {
      this.NodeChild.remove(child.NodeId);
    }
  }

  @Override
public String toString() {
    return Integer.toString(this.NodeId);
  }

  public void SetVisited(boolean visited) {
    this.IsVisited = visited;
  }

  public boolean GetVisited() {
    return this.IsVisited;
  }

  public void calcK2Score(Score s) {
    //K22 k = new K22();
    //this.K2Score = k.calcK2(this.NodeId, this.GetParentNodesIndex());
    //this.K2Score = k.calcK2_temp(this.NodeId, this.GetParentNodesIndex());
    this.K2Score = s.calcScore(this.NodeId,this.GetParentNodesIndex());
  }

  public double GetK2Score() {
    return this.K2Score;
  }
}
