package bjut.ai.bn.score;
import edu.ksu.cis.bnj.bbn.BBNGraph;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import bjut.ai.bn.learning.acob.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;


public class patel {
	
	
	public String[][] Records; //����
	public double[][] data; //����
	public static double[][] theta1; 
	public static double[][] theta2;
	public static double[][] theta3;
	public static double[][] theta4;
	
	public static double [][]kappa; //��

	
	private HashMap<String, Double> hm; // �м����
	public HashMap<String, Double> cacheResult;
	
	
	public patel(String fileName, int size, int nodeNums) {
		// TODO �Զ����ɵĹ��캯�����
		 AlarmReader ar = new AlarmReader(fileName, size, nodeNums);
		 this.Records = ar.GetDataSet();
		 BICScore.NodeInfo = ar.getColumnValue();
		 this.cacheResult = new HashMap<String, Double>();

	}
	
	 
	public double min(double a)
	{
		if(a<=1)
		return a;
		
		else 
			return 1;
	}
	
	public double max(double a)
	{
		if(a>=0)
		return a;
		
		else 
			return 0;
	}
	
	public double min1(double a, double b)
	{
		if(a<=b)
		return a;
		
		else 
			return b;
	}
	
	public double max1(double a, double b)
	{
		if(a>=b)
		return a;
		
		else 
			return b;
	}
	
	
	
	//���ַ�������ת��double����
	public double[][] strtodouble(String[][] str)
	{
	    int a,b;
	    a = str.length;
	    b = str[0].length;
	    double result[][] = new double[a][b];
	    for(int i = 0 ; i < a ; ++ i)
	    {
	        for(int j = 0 ; j < b ; ++ j)
	        {
	        	
	            result[i][j] = Double.parseDouble(str[i][j]);
	        }
	    }
	    return result;
	}
	
	//���ĺ�������ȡ�������Ӿ����4��thetaֵ
	public void preprocessingdata(String[][] R, int size, int nodeNums, double thred) {
		double [] a = new double[size];//��ʱ����

		double[] gmax=new double[nodeNums];//ÿ�е�90λֵ
		double[] gmin=new double[nodeNums];//ÿ�е�10λֵ
		
		int count=0;
		double[][] t=strtodouble(R); //��ȡ������
		double[][] t1=new double[size][nodeNums]; //�������������
		double[][] t2=new double[size][nodeNums]; //����ӳ������ݣ�Դ��
    
	    theta1=new double[nodeNums][nodeNums];
		theta2=new double[nodeNums][nodeNums];
		theta3=new double[nodeNums][nodeNums];
		theta4=new double[nodeNums][nodeNums];
		
		kappa=new double[nodeNums][nodeNums];
		
		//��ԭʼ���� ÿ�зֱ��������
		do{
			for (int i=0;i<size;i++)
			{		
				a[i]=t[i][count];
				
			 }
		    Arrays.sort(a); 
		    
			for (int i=0;i<size;i++)
			{		
				t1[i][count]=a[i];
			 }
			
	          count++;
		}while(count<nodeNums);
		
		//ѡȡÿ�е�10��90�ٷ�λ��
		for (int i=0;i<nodeNums;i++)
		{	
			int max=(int)(size*0.9);
			int min=(int)(size*0.1);
		    gmax[i]=t1[max][i];
		    gmin[i]=t1[min][i];
		 //   System.out.print(" ");
		 //   System.out.print(gmax[i]);
		 //   System.out.print(" ");
		 //   System.out.print(gmin[i]);
		    
		}
		//System.out.println(" ");
		
		//��Դ����ӳ�䵽0-1������
	    count=0;//����
	    do{
			for (int i=0;i<size;i++)
			{		
				t2[i][count]=max(min((t[i][count]-gmin[count])/(gmax[count]-gmin[count])));
			  if(t2[i][count]>=thred)
				  t2[i][count]=1;
			  else t2[i][count]=0;
				//  System.out.print(t2[i][count]);
			 //  System.out.print(" ");
			 }
	          count++;
	        //  System.out.println(" ");
		}while(count<nodeNums);
	    
	    
	  //����theta
	    count=0;//����
	 
	    do{
	    	for (int j=1;j+count<nodeNums;j++)
	    	{
			for (int i=0;i<size;i++)
			{	
				 theta1[count][count+j]+=t2[i][count]*t2[i][count+j];
				 theta2[count][count+j]+=t2[i][count]*(1-t2[i][count+j]);
				 theta3[count][count+j]+=(1-t2[i][count])*t2[i][count+j];
				 theta4[count][count+j]+=(1-t2[i][count])*(1-t2[i][count+j]);
				 
				  		 
			 }
			
			theta1[count][count+j]=theta1[count][count+j]/size;
			theta2[count][count+j]=theta2[count][count+j]/size;
			theta3[count][count+j]=theta3[count][count+j]/size;
			theta4[count][count+j]=theta4[count][count+j]/size;
			//System.out.print(count+" "+(count+j)+" "+theta1[count][count+j]+" "+ theta2[count][count+j]+" "+ theta3[count][count+j]+" "+ theta4[count][count+j]);
			// System.out.println(" ");
	    	}
			
	          count++;
	        
		}while(count+1<nodeNums);
	    
	    
	    //����kappa
	    double[][] eee=new double[nodeNums][nodeNums];
	    double[][] max_theta1=new double[nodeNums][nodeNums];
	    double[][] min_theta1=new double[nodeNums][nodeNums];
	    double[][] kappa1=new double[nodeNums][nodeNums];
	    count=0;//����
	    do{
			for (int i=0;i<nodeNums;i++)
			{		
				
				eee[count][i]=(theta1[count][i]+theta2[count][i])*(theta1[count][i]+theta3[count][i]);
				max_theta1[count][i]=min1(theta1[count][i]+theta2[count][i],theta1[count][i]+theta3[count][i]);
				min_theta1[count][i]=max1(0, 2*theta1[count][i]+theta2[count][i]+theta3[count][i]-1);
				kappa1[count][i]=(theta1[count][i]-eee[count][i])/(theta1[count][i]*(max_theta1[count][i]-eee[count][i]) + (1-theta1[count][i])*(eee[count][i]-min_theta1[count][i]));  
			  // System.out.print(kappa1[count][i]);
			 //  System.out.print(" ");
			 }
		
	          count++;
	         // System.out.println(" ");
		}while(count<nodeNums);
	    
	    for (int j=0;j<nodeNums;j++)
	    {
	    for (int i=0;i<nodeNums;i++)
			{		
				
				if(kappa1[i][j]>0)
				{
					kappa[i][j]=kappa1[i][j];
				}
				else 
					kappa[i][j]=kappa1[j][i];
			
				if(theta1[i][j]>0)
				{
					theta1[i][j]=theta1[i][j];
				}
				else 
					theta1[i][j]=theta1[j][i];
				
				if(theta2[i][j]>0)
				{
					theta2[i][j]=theta2[i][j];
				}
				else 
					theta2[i][j]=theta2[j][i];
				if(theta3[i][j]>0)
				{
					theta3[i][j]=theta3[i][j];
				}
				else 
					theta3[i][j]=theta3[j][i];
				if(theta4[i][j]>0)
				{
					theta4[i][j]=theta4[i][j];
				}
				else 
					theta4[i][j]=theta4[j][i];
				
				//System.out.print(kappa[i][j]);
				//   System.out.print(" ");
			}
	   // System.out.println(" ");
	    }
	    
    //  return kappa;
      
		}
	
	public double[][] get1()
	{
		return theta1;
	}
	
	public double[][] get2()
	{
		return theta1;
	}
	public double[][] get3()
	{
		return theta1;
	}
	public double[][] get4()
	{
		return theta1;
	}
	
	
	public static void main(String[] args) {
		try {

			BNGraph g = BNGraph.GetGraphStandAlarm();
			patel pa = new patel("F:\\sim1.txt", 10000, 5);
			
			//AlarmReader ar = new AlarmReader("F:\\linshi.txt", 5, 5);
			AlarmReader ar = new AlarmReader("F:\\sim1.txt", 10000, 5);
			pa.data=pa.strtodouble(ar.GetDataSet());

			pa.preprocessingdata(ar.GetDataSet(), 10000, 5, 0.5);
			
			for (int i=0;i<10;i++)
			   {
				for (int j=0;j<5;j++)
				{
				System.out.print(pa.data[i][j]);	
				System.out.print(" ");
				 }
				System.out.println(" ");
				   }
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	
	

}
