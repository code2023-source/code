package bjut.ai.bn.score;

import java.util.ArrayList;

import bjut.ai.bn.BNGraph;

public class MDLScore extends Score {

	@Override
	public double calcScore(int index, ArrayList<Integer> parent) {
		return Double.NaN;
	}

	@Override
	public void clearCache() {}

	@Override
	public double calcGraphScore(BNGraph g) {
		return Double.NaN;
	}

}
