//package bjut.ai.sem;
//
//import java.util.*;
//
//import bjut.ai.acob.*;
//import java.io.*;
///**
// * <p>Title: </p>
// *
// * <p>Description: </p>
// *
// * <p>Copyright: Copyright (c) 2008</p>
// *
// * <p>Company: </p>
// *
// * @author not attributable
// * @version 1.0
// */
//public class InferBN {
//
//	/**
//	 *�����㷨
//	 * @param g BNGraph ��Ҷ˹��
//	 * @param E String ֤�ݱ���
//	 * @param EValue int ֤�ݱ�����ȡֵ
//	 * @param Q String ��ѯ����
//	 * @param order ArrayList ��Ԫ˳��
//	 * @return Function
//	 */
//	public static Function VE(BNGraph g, ArrayList<String> E,
//			ArrayList<Integer> Evalue, String Q, ArrayList<String> order) {
//		Function f = null;
//		EM em = new EM();
//		Map Theta = em.genThetaSK(g);
//		//����BN g�ĺ�������flist
//		ArrayList<Function> flist = new ArrayList<Function>();
//		for (int ix = 0; ix < Theta.size(); ix++) {
//			//��ǰ�ڵ�ix�Ĳ�����
//			HashMap<String, Integer> thetaNode = (HashMap<String, Integer>) Theta.get(ix);
//			String key = InferBN
//					.genKey(ix, g.GetNode(ix).GetParentNodesIndex());
//			flist.add(new Function(key, thetaNode));
//		}
//		InferBN.setEvidence(flist, E, Evalue);
//		PrintWriter pw = CommonTools.getPrintWriter("c:\\", "VElog.txt");
//		while (!order.isEmpty()) {
//			String ElimValue = order.remove(0);
////			for(int i = 0; i < flist.size(); i++)
////			{
////				pw.print(flist.get(i).getID()+"; ");
////			}
////			pw.append("\n");
//			flist = Elim(flist, ElimValue);
//			pw.println("��Ԫ������"+ElimValue);
//			
//		}
//		pw.close();
//		f = InferBN.mergeFunction(flist, Q);
//		return f;
//	}
//	
//	/**
//	 *���������㷨
//	 * @param g BNGraph ��Ҷ˹��
//	 * @param E String ֤�ݱ���
//	 * @param EValue int ֤�ݱ�����ȡֵ
//	 * @param Q String ��ѯ����
//	 * @param order ArrayList ��Ԫ˳��
//	 * @return Function
//	 */
//	public static Function VEasia(BNGraph g, 
//			ArrayList<String> E,
//			ArrayList<Integer> Evalue, 
//			String Q, 
//			ArrayList<String> order,
//			Map<String, Map<String, Double>> theta) {
//		Function f = null;
//		Function f1 = null;
//		Function f2 = null;
//		Function f3 = null;
//		Function f4 = null;
//		Function f5 = null;
//		Function f6 = null;
//		Function f7 = null;
//
//
//		Map Theta = theta;
//		
//		
//		HashMap<String, Double> t = new HashMap<String, Double>();
//		HashMap<String, Double> t1 = new HashMap<String, Double>();
//		HashMap<String, Double> t2 = new HashMap<String, Double>();
//		HashMap<String, Double> t3 = new HashMap<String, Double>();
//		HashMap<String, Double> t4 = new HashMap<String, Double>();
//		HashMap<String, Double> t5 = new HashMap<String, Double>();
//		HashMap<String, Double> t6 = new HashMap<String, Double>();
//		HashMap<String, Double> t7= new HashMap<String, Double>();
//
//		t.put("1", 0.01);
//		t.put("0", 0.99);
//		
//		t1.put("1", 0.5);
//		t1.put("0", 0.5);
//		
//		t2.put("11", 0.05);
//		t2.put("10", 0.01);
//		t2.put("01", 0.95);
//		t2.put("00", 0.99);
//		
//		t3.put("11", 0.1);
//		t3.put("10", 0.01);
//		t3.put("01", 0.9);
//		t3.put("00", 0.99);
//		
//		t4.put("11", 0.6);
//		t4.put("10", 0.3);
//		t4.put("01", 0.4);
//		t4.put("00", 0.7);
//		
//		t5.put("111", 1.0);
//		t5.put("101", 1.0);
//		t5.put("110", 1.0);
//		t5.put("100", 0.0);
//		t5.put("011", 0.0);
//		t5.put("001", 0.0);
//		t5.put("010", 0.0);
//		t5.put("000", 1.0);
//		
//		t6.put("01", 0.98);
//		t6.put("00", 0.5);
//		t6.put("11", 0.02);
//		t6.put("10", 0.95);
//		
//		t7.put("111", 0.9);
//		t7.put("101", 0.7);
//		t7.put("110", 0.8);
//		t7.put("100", 0.1);
//		t7.put("011", 0.1);
//		t7.put("001", 0.3);
//		t7.put("010", 0.2);
//		t7.put("000", 0.9);
//		
//		f = new Function("0", t);
//		f1 = new Function("1", t1);
//		f2 = new Function("2,0,", t2);
//		f3 = new Function("3,1,", t3);
//		f4 = new Function("4,1,", t4);
//		f5 = new Function("5,2,3,", t5);
//		f6 = new Function("6,5", t6);
//		f7 = new Function("7,4,5,", t7);
//		
//		ArrayList<Function> flist = new ArrayList<Function>();
//		flist.add(f);
//		flist.add(f1);
//		flist.add(f2);
//		flist.add(f3);
//		flist.add(f4);
//		flist.add(f5);
//		flist.add(f6);
//		flist.add(f7);
//		
//		InferBN.setEvidence(flist, E, Evalue);
//		PrintWriter pw = CommonTools.getPrintWriter("c:\\", "VElog.txt");
//		while (!order.isEmpty()) {
//			String ElimValue = order.remove(0);
////			for(int i = 0; i < flist.size(); i++)
////			{
////				pw.print(flist.get(i).getID()+"; ");
////			}
////			pw.append("\n");
//			flist = Elim(flist, ElimValue);
//			pw.println("��Ԫ������"+ElimValue);
//			
//		}
//		pw.close();
//		f = InferBN.mergeFunction(flist, Q);
//		return f;
//	}
//
//	/**
//	 * ��Ԫ
//	 * ������������flist����ȥElimValue
//	 * @param flist ArrayList
//	 * @param ElimValue String
//	 * @return ArrayList
//	 */
//	public static ArrayList<Function> Elim(ArrayList<Function> flist,
//			String ElimValue) {
//		//���ɴ���Ԫ�ĺ�������al
//		Collections.sort(flist);
//		ArrayList<Function> al = new ArrayList<Function>();
//		Function f = null;
//		Iterator it = flist.iterator();
//		while (it.hasNext()) {
//			f = (Function) it.next();
//			if (f.IDContains(ElimValue)) {
//				al.add(f);
//				it.remove();
//			}
//		}
//		//����ElimValue
//		if (al.size() >= 2) {
//			f = InferBN.multiply(al.remove(0), al.remove(0), ElimValue);
//			for (int ix = 0; ix < al.size(); ix++) {
//				f = InferBN.multiply(f, al.remove(0), ElimValue);
//			}
//			flist.add(f);
//		} else {// al��ֻ����һ���������д���
//			if (!al.isEmpty()) {
//				f = al.remove(0);
//				if (!f.FIDEquals(ElimValue)) {
//					InferBN.ElimFuncValue(f, ElimValue);
//					flist.add(f);
//				} else {
//					// �����������
//				}
//			}
//			
//		}
//		System.out.println("��ȥ��"+ElimValue+"; "+flist.get(flist.size()-1));
//		return flist;
//	}
//
//	/**
//	 * ����������ˣ�ͬʱ��ȥElimValue,��Ϊ֤�ݱ���
//	 * @param f1 Function
//	 * @param f2 Function
//	 * @param ElimValue String
//	 * @return Function
//	 */
//
//	public static Function multiply(Function f1, Function f2, String ElimValue) {
//		String key = f1.getID() + f2.getID();
//		Set<String> set1 = f1.getTheta().keySet();
//		Set<String> set2 = f2.getTheta().keySet();
//		ArrayList<Integer> indexF1 = InferBN.indexsOfValue(f1.getID(), ElimValue);
//		ArrayList<Integer> indexF2 = InferBN.indexsOfValue(f2.getID(), ElimValue);
//		//��������ĳ˻���
//		Iterator<String> it = set1.iterator();
//		HashMap<String, Double> map = new HashMap<String, Double>();
//		while (it.hasNext()) {
//			String key1 = (String) it.next();
//			Iterator<String> it2 = set2.iterator();
//			while (it2.hasNext()) {
//				String key2 = (String) it2.next();
//				if (InferBN.equalsAtIndexs(key1, indexF1, key2, indexF2)) {
//					double value = f1.getValue(key1) * f2.getValue(key2);
//					String key0 = key1 + key2;
//					map.put(key0, value);
//				}
//			}
//		}
//		//        System.out.println("map:" + map);
//
//		//�ϲ�,��ȥ
//		indexF1 = InferBN.indexsOfValue(key, ElimValue);
//		HashMap<String, Double> map2 = new HashMap<String, Double>();
//		Set map_set = map.entrySet();
//		Iterator it_map_set = map_set.iterator();
//		while (it_map_set.hasNext()) {
//			Map.Entry me = (Map.Entry) it_map_set.next();
//			String key_me = (String) me.getKey();
//			double value_me = (Double) me.getValue();
//
//			String key_me1 = InferBN.filteKey(key, ElimValue, key_me);
//			double temp = value_me;
//			if (map2.containsKey(key_me1)) {
//				temp = (Double) map2.get(key_me1);
//				temp = temp + value_me;
//			}
//			map2.put(key_me1, temp);
//		}
//		key = InferBN.filteFunID(key, ElimValue);
//		Function f = new Function(key, map2, f1.getEvidence(), f1.getEvalue());
//		return f;
//	}
//	
//	
//	/**
//	 * �ϲ�����
//	 * @param flist
//	 * @param QueryValue
//	 * @return
//	 */
//	public static Function mergeFunction(ArrayList<Function> flist,
//			String QueryValue) {
//		Function f = null;
//		if (flist.size() == 1) {
//			f = flist.get(0);
//		} else {
//			HashMap<String, Double> Theta = new HashMap<String, Double>();
//			int Value = 3;
//			for (int i = 1; i < Value; i++) {
//				String curKeyValue = String.valueOf(i);
//				double curPro = 1.0;
//				for (int ix = 0; ix < flist.size(); ix++) {
//					f = flist.get(ix);
//					ArrayList<Integer> index = InferBN.indexsOfValue(f.getID(),
//							QueryValue);
//					HashMap<String, Double> tempTheta = f.getTheta();
//					Set<String> tempKeySet = tempTheta.keySet();
//					Iterator<String> iter = tempKeySet.iterator();
//					while (iter.hasNext()) {
//						String tempKey = (String) iter.next();
//						boolean tag = true;
//						for (int iy = 0; iy < index.size(); iy++) {
//							if (!tempKey.substring(index.get(iy),
//									index.get(iy) + 1).equals(curKeyValue))
//								tag = false;
//						}
//						if (tag) {
//							curPro *= (Double) tempTheta.get(tempKey);
//						}
//					}
//				}
//				Theta.put(curKeyValue, curPro);
//			}
//			f = new Function(QueryValue + ",", Theta, flist.get(0)
//					.getEvidence(), flist.get(0).getEvalue());
//		}
//		return f;
//	}
//
//	/**
//	 * ����֤�ݱ���
//	 * @param flist ArrayList
//	 * @param e String
//	 */
//	public static void setEvidence(ArrayList<Function> flist,
//			ArrayList<String> E, ArrayList<Integer> Evalue) {
//		for (int ix = 0; ix < flist.size(); ix++) {
//			Function f = flist.get(ix);
//			for (int iy = 0; iy < E.size(); iy++) {
//				if(f.evidenced(E.get(iy)))
//				f.setEvidence(E.get(iy), Evalue.get(iy));
//			}
//		}
//	}
//
//	/**
//	 * ����key
//	 *
//	 * @param nodenum int
//	 * @param parent ArrayList
//	 * @return String
//	 */
//	public static String genKey(int nodenum, ArrayList<Integer> parent) {
//		StringBuilder sb = new StringBuilder();
//		sb.append(nodenum);
//		sb.append(",");
//		Collections.sort(parent);
//		for (int ix = 0; ix < parent.size(); ix++) {
//			sb.append(parent.get(ix));
//			sb.append(",");
//		}
//		return sb.toString();
//	}
//
//	/**
//	 * ��ȥs�е�v,���theta�е�key
//	 * FID="2,1,1" v = "1", sΪtheta�е�ֵ"011"
//	 * �������"0"
//	 * @param s String
//	 * @param v String
//	 * @return String
//	 */
//	public static String filteKey(String FunctionID, String v, String s) {
//		StringBuilder sb = new StringBuilder();
//		String[] chars = FunctionID.split(",");
//		char[] chars2 = s.toCharArray();
//		for (int ix = 0; ix < chars.length; ix++) {
//			if (!chars[ix].equals(v)) {
//				sb.append(chars2[ix]);
//			}
//		}
//		return sb.toString();
//	}
//
//	/**
//	 * �����µ�FID
//	 * FunID = "0,24," v = "0"
//	 * ����"24,"
//	 * @param FunID String
//	 * @param v String
//	 * @return String
//	 */
//	public static String filteFunID(String FunID, String v) {
//		StringBuilder sb = new StringBuilder();
//		String[] ss = FunID.split(",");
//		for (int ix = 0; ix < ss.length; ix++) {
//			if (!ss[ix].equals(v)) {
//				sb.append(ss[ix]);
//				sb.append(",");
//			}
//		}
//		return sb.toString();
//	}
//
//	/**
//	 * ����f��ID��ֵ����value��indexs,
//	 * FID=X2,X1,X1,value = X1 ���� 12
//	 * @param f Function
//	 * @param value String
//	 * @return ArrayList
//	 */
//	public static ArrayList<Integer> indexsOfValue(String str, String value) {
//		ArrayList<Integer> al = new ArrayList<Integer>();
//		String[] s = str.split(",");
//		for (int ix = 0; ix < s.length; ix++) {
//			if (s[ix].equals(value))
//				al.add(ix);
//		}
//		return al;
//	}
//
//	/**
//	 * s1��index1�ϵ�ֵ��s2��index2�ϵ�ֵ���*
//	 * @param s1 String
//	 * @param s2 String
//	 * @param indexs ArrayList
//	 * @return boolean
//	 */
//	public static boolean equalsAtIndexs(String s1, ArrayList<Integer> index1,
//			String s2, ArrayList<Integer> index2) {
//		boolean tag = false;
//		if (index1.size() == index2.size()
//				&& (s1.charAt(index1.get(0)) == s2.charAt(index2.get(0)))) {
//			tag = true;
//		}
//		return tag;
//	}
//
//	/**
//	 * ת��һ������ͼ�ľ���Ϊ����ͼ�ľ���
//	 * @param OriArrayԭʼ����
//	 * @param DesArrayĿ�����
//	 */
//	public static void tranArcArray(int[][] OriArray, int[][] DesArray) {
//		for (int i = 0; i < OriArray.length; i++)
//			for (int j = 0; j < OriArray[1].length; j++) {
//				if (OriArray[i][j] == 1) {
//					DesArray[i][j] = DesArray[j][i] = 1;
//				}
//			}
//	}
//
//	/**
//	 * ���������ͼ�ڵ��ȱ����
//	 * @param graph
//	 * @param nodenum
//	 * @return
//	 */
//	public static int calcDegreeOfNode(int[][] graph, int nodenum) {
//		int degree = 0;
//		ArrayList<Integer> al = new ArrayList<Integer>();
//		for (int i = 0; i < graph[nodenum].length; i++) {
//			if (graph[nodenum][i] == 1)
//				al.add(i);
//		}
//		for (int ix = 0; ix < al.size(); ix++) {
//			int curnode = al.get(ix);
//			for (int iy = ix + 1; iy < al.size(); iy++) {
//				if (graph[curnode][al.get(iy)] != 1) {
//					degree++;
//				}
//			}
//		}
//		return degree;
//	}
//
//	/**
//	 * ȡ����Ԫ˳��
//	 * @param g
//	 * @return
//	 */
//	public static ArrayList<String> getElimOrder(BNGraph g) {
//		final int NODENUM = g.getVexNum();
//		ArrayList<Integer> order = new ArrayList<Integer>();
//		ArrayList<Integer> nodesD = new ArrayList<Integer>();
//		
//		int[][] oriArray = g.GetArcArray();
//		int[][] desArray = new int[NODENUM][NODENUM];//ת���������ͼ
//		InferBN.tranArcArray(oriArray, desArray);
//
//		for (int ix = 0; ix < NODENUM; ix++) {
//			
//			//ÿ���ڵ��ȱ����,��ʼ��Ϊ���ֵ
//			for (int i = 0; i < NODENUM; i++)
//				nodesD.add(Integer.MAX_VALUE);
//			
//			//����ÿ���ڵ��ȱ��������
//			for (int i = 0; i < NODENUM; i++) {
//				if(!order.contains(i))
//				nodesD.set(i, InferBN.calcDegreeOfNode(desArray, i));
//			}
//			int minDegreeNode = Collections.min(nodesD);
//			int pos = -1;//��Сȱ�����ڵ��λ��
//			for (int i = 0; i < nodesD.size(); i++) {
//				if (nodesD.get(i) == minDegreeNode) {
//					pos = i;
//					break;
//				}
//			}
//			order.add(pos);
//			//ɾ������ڵ�
//			for (int i = 0; i < desArray.length; i++) {
//				desArray[pos][i] = 0;
//				desArray[i][pos] = 0;
//			}
//			nodesD.clear();
//		}
//		ArrayList<String> order2 = new ArrayList<String>();
//		for(int ix = 0; ix < order.size(); ix++)
//		{
//			order2.add(String.valueOf(order.get(ix)));
//		}
//		return order2;
//	}
//	/**
//	 * ��������f�е�ElimNodeֵ
//	 * ��Function f = "0,24" ElimNode = 0
//	 * �򷵻�һ��ֻ����24�ĺ�����f = "24,";
//	 * @param f
//	 * @param ElimNode
//	 */
//	public static void ElimFuncValue(Function f, String ElimNode)
//	{
//		String key = InferBN.filteFunID(f.getID(), ElimNode);
//		HashMap<String, Double> theta = new HashMap<String, Double>();
//		HashMap<String, Double> ftheta = f.getTheta();
//		
//		Set<String> fkeySet = ftheta.keySet();
//		
//		Iterator<String> iter = fkeySet.iterator();
//		while(iter.hasNext())
//		{
//			String tempfkey = iter.next();//
//			double tempfvalue = ftheta.get(tempfkey);
//			String tempkey = InferBN.filteKey(f.getID(), ElimNode, tempfkey);
//			double tempvalue = 0.0;
//			if(theta.containsKey(tempkey))
//			{
//				tempvalue = theta.get(tempkey);
//				tempvalue += tempfvalue;
//				theta.put(tempkey, tempvalue);
//			}
//			else
//			{
//				theta.put(tempkey, tempvalue);
//			}
//		}
//		f.setTheta(theta);
//		f.setID(key);
//	}
//
//	/**
//	 * s1��s2�ڳ���indexs�ϵ�ֵ���
//	 * @param s1
//	 * @param s2
//	 * @param indexs
//	 * @return
//	 */
//	public static boolean equalsExceptIndexs(String s1, String s2,
//			ArrayList<Integer> indexs) {
//		boolean tag = true;
//		for (int ix = 0; ix < s1.length(); ix++) {
//			if (!indexs.contains(ix) && (s1.charAt(ix) != s2.charAt(ix))) {
//				tag = false;
//			}
//		}
//		return tag;
//	}
///*
//	public static void main(String[] args) {
//		HashMap<String, Double> hm1 = new HashMap<String, Double>();
//		HashMap<String, Double> hm2 = new HashMap<String, Double>();
//		HashMap<String, Double> hm3 = new HashMap<String, Double>();
//
//		hm1.put("11", 2.0 / 3.0);
//		hm1.put("12", 1.0 / 3.0);
//		hm1.put("21", 1.0 / 3.0);
//		hm1.put("22", 2.0 / 3.0);
//
//		hm2.put("1", 1.0 / 2.0);
//		hm2.put("2", 1.0 / 2.0);
//
//		hm3.put("11", 2.0 / 3.0);
//		hm3.put("12", 1.0 / 3.0);
//		hm3.put("21", 1.0 / 3.0);
//		hm3.put("22", 2.0 / 3.0);
//
//		Function f1 = new Function("1,0,", hm1);
//		Function f2 = new Function("0,", hm2);
//		Function f3 = new Function("2,1,", hm3);
//		ArrayList<Function> flist = new ArrayList<Function>();
//		flist.add(f1);
//		flist.add(f2);
//		flist.add(f3);
//		//Ϊ�˲��������㷨����ʱע��g�м������ֵĺ���
//		BNGraph g = new BNGraph();
//		for (int ix = 0; ix < 3; ix++) {
//			BNNode node = new BNNode(ix);
//			g.AddNode(node);
//		}
//		g.AddArc(0, 1);
//		g.AddArc(1, 2);
//		//��Ԫ˳��
//		ArrayList<String> order = new ArrayList<String>();
//		order.add("0");
//
//		ArrayList<String> E = new ArrayList<String>();
//		E.add("0");
//		E.add("2");
//		ArrayList<Integer> Evalue = new ArrayList<Integer>();
//		Evalue.add(2);
//		Evalue.add(2);
//		Function f = InferBN.VEtest(g, flist, E, Evalue, "1", order);
//		System.out.println("��Ԫ��" + f);
//
//		int[][] array = { { 0, 1, 0 }, { 0, 0, 1 }, { 0, 0, 0 } };
//		int[][] array1 = new int[3][3];
//		InferBN.tranArcArray(array, array1);
//		CommonTools.outArray(array1);
//		System.out.println(InferBN.calcDegreeOfNode(array1, 0));
//		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
//		hm.put(0, 1);
//		hm.put(1, 2);
//		hm.put(2, 0);
//		hm.put(3, 0);
//		ArrayList<String> al = new ArrayList<String>(3);
//
//		al = InferBN.getElimOrder(g);
//		ArrayList<Integer> al2 = new ArrayList<Integer>();
//		al2.add(1);
//		al.remove(al2);
//		System.out.println("order: "+al);
//	}
//
//	*/
//}
