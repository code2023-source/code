package bjut.ai.sem;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import smile.Network;
import smile.learning.DataSet;
import bjut.ai.bn.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import edu.ksu.cis.bnj.bbn.BBNCPF;
import edu.ksu.cis.bnj.bbn.BBNDiscreteValue;
import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.BBNNode;
import edu.ksu.cis.bnj.bbn.BBNPDF;
import edu.ksu.cis.bnj.bbn.inference.InferenceResult;
import edu.ksu.cis.bnj.bbn.inference.ls.LS;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.data.Tuple;
import edu.ksu.cis.kdd.util.graph.Edge;

public class EM {
	public static PrintWriter log = CommonTools.getPrintWriter("c:\\",
			"logloss.txt");
	private BBNGraph alarm = null;// �����ṩalarm������Ϣ
	private int vexnum = 37;
	public PrintWriter pw = CommonTools.getPrintWriter("c:\\", "EM.txt");
	private Random random = null;
	public static int[] AlarmNodeDef = { 3, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 2, 4,
			4, 4, 3, 2, 2, 2, 2, 2, 3, 2, 2, 3, 3, 2, 2, 3, 2, 2, 3, 3, 4, 4,
			4, 4 };
	private static int[] AlarmOrder = { 12, 16, 17, 18, 19, 20, 21, 22, 23, 24,
			25, 26, 28, 30, 31, 37, 1, 2, 3, 4, 10, 36, 13, 35, 15, 34, 32, 33,
			11, 14, 27, 29, 6, 7, 8, 9, 5 };

	public EM() {
		this.random = new Random();
		this.alarm = BBNGraph.load("data\\alarm.xml");

	}

	public BBNGraph getStardardAlarm() {
		return this.alarm;
	}

	//
	// /**
	// * ����map��Ϊͼg�Ĳ������� ���е�map��key�ǽڵ����ţ�map��value����� �ڵ�����Ӧ��theta��
	// *
	// * @param OriginData
	// * String[][]
	// * @param g
	// * BNGraph
	// * @return Map
	// */
	// public Map<Integer, Map<Integer, Double>> genTheta(BNGraph g) {
	// Map map = new HashMap<Integer, Map<Integer, Double>>();
	// int vexnum = g.getVexNum();
	// for (int ix = 0; ix < vexnum; ix++) {
	// Map temp = this.genThetaData(g, ix);
	// map.put(ix, temp);
	// }
	// return map;
	// }
	//
	// public Map<String, Map<String, Double>> genThetaSK(BNGraph g) {
	// Map map = new HashMap<String, Map<String, Double>>();
	// int vexnum = g.getVexNum();
	// for (int ix = 0; ix < vexnum; ix++) {
	// Map temp = EM.genThetaDataSK(g, ix);
	// map.put("x" + ix, temp);
	// }
	// return map;
	// }
	//
	// /**
	// * ����ÿ���ڵ��theta�� ����map��key��0,1,2..���ո�ĸ�ڵ������� doubleֵΪ����Ϸ����ĸ���
	// *
	// * @param g
	// * BNGraph
	// * @param data
	// * String[]
	// * @return Map
	// */
	//
	// private Map<Integer, Double> genThetaData(BNGraph g, int nodenum) {
	// Map<Integer, Double> map = new HashMap<Integer, Double>();
	// // ������ѯ����
	// ArrayList<Integer> parent = g.GetNode(nodenum).GetParentNodesIndex();
	// int[] indexArray = new int[parent.size() + 1];
	// for (int i = 0; i < parent.size(); i++) {
	// indexArray[i + 1] = parent.get(i);
	// }
	// Arrays.sort(indexArray);
	// indexArray[0] = nodenum;
	// // ȡ�ò�ѯ���
	// int[] queryResult = K2.INSTANCE.getCountBrutal(K2.Records, indexArray);
	//
	// int qi = 1;
	// for (int count = 0; count < parent.size(); count++) {
	// qi = qi * K2.NodeInfo[parent.get(count)].size();
	// }
	// // ��ʼ����
	// int ri = K2.NodeInfo[nodenum].size();
	// int step = qi;
	// int[] parentArray = new int[qi];
	// for (int i = 0; i < qi; i++) {
	// int Nij = 0;
	// int Nijk = 0;
	// int point = 0;
	// for (int j = 0; j < ri; j++) {
	// Nijk = queryResult[i + point];
	// Nij = Nij + Nijk;
	// point = point + step;
	// }
	// parentArray[i] = Nij;
	// }
	// for (int i = 0; i < queryResult.length; i++) {
	// double t1 = queryResult[i];
	// double t2 = parentArray[i % qi];
	// double theta = 0.01;
	// if (t2 != 0)
	// theta = t1 / t2;
	// // if(theta == 0.0)
	// // theta = 0.01;//Ȩ��֮��
	// map.put(i, theta);
	// }
	// return map;
	// }
	//
	// public static Map<String, Double> genThetaDataSK(BNGraph g, int nodenum)
	// {
	// Map<String, Double> map = new HashMap<String, Double>();
	// // ������ѯ����
	// ArrayList<Integer> parent = g.GetNode(nodenum).GetParentNodesIndex();
	// int[] indexArray = new int[parent.size() + 1];
	// for (int i = 0; i < parent.size(); i++) {
	// indexArray[i + 1] = parent.get(i);
	// }
	// Arrays.sort(indexArray);
	// indexArray[0] = nodenum;
	// // ȡ�ò�ѯ���
	// int[] queryResult = K2.INSTANCE.getCountBrutal(K2.Records, indexArray);
	//
	// int qi = 1;
	// for (int count = 0; count < parent.size(); count++) {
	// qi = qi * K2.NodeInfo[parent.get(count)].size();
	// }
	//
	// // ��ʼ����
	// int ri = K2.NodeInfo[nodenum].size();
	// int step = qi;
	// int[] parentArray = new int[qi];
	// for (int i = 0; i < qi; i++) {
	// int Nij = 0;
	// int Nijk = 0;
	// int point = 0;
	// for (int j = 0; j < ri; j++) {
	// Nijk = queryResult[i + point];
	// Nij = Nij + Nijk;
	// point = point + step;
	// }
	// parentArray[i] = Nij;
	// }
	// for (int i = 0; i < queryResult.length; i++) {
	// double t1 = queryResult[i];
	// double t2 = parentArray[i % qi];
	// double theta = 0.0;
	// if (t2 != 0)
	// theta = t1 / t2;
	// String key = EM.convertKey(i, parent);
	// map.put(key, theta);
	// }
	// return map;
	// }
	//
	// public static String convertKey(int oriKey, ArrayList<Integer> parent) {
	// StringBuilder sb = new StringBuilder();
	// if (!parent.isEmpty()) {
	// int[] keydef = new int[parent.size()];
	// for (int i = 0; i < keydef.length; i++) {
	// keydef[i] = 1;
	// for (int j = i; j < keydef.length; j++) {
	// keydef[i] *= EM.AlarmNodeDef[parent.get(j)];
	// }
	// }
	//
	// int count = 0;
	// int modr = oriKey % keydef[count];
	// int r = oriKey / keydef[count];
	// sb.append(r);
	// while (count < keydef.length - 1) {
	// r = modr / keydef[++count];
	// modr = modr % keydef[count];
	// sb.append(r);
	// }
	// sb.append(modr);
	// } else {
	// sb.append(oriKey);
	// }
	//
	// return sb.toString();
	//
	// }
	//
	// public static int[] testconvert(ArrayList<Integer> parent) {
	// int[] keydef = new int[parent.size()];
	// for (int i = 0; i < keydef.length; i++) {
	// keydef[i] = 1;
	// for (int j = i; j < keydef.length; j++) {
	// keydef[i] *= EM.AlarmNodeDef[parent.get(j)];
	// }
	// }
	// return keydef;
	// }
	//
	// /**
	// * ����һ������data������ṹg������theta�£������ĸ��� Ŀ����������logloss����Ȩ��
	// *
	// * @param data
	// * String[] һ������
	// * @param theta
	// * Map �������
	// * @param g
	// * BNGraph ͼ�ṹ
	// * @return double ���ظ���
	// */
	// public double calcDataPro(String[] data, Map theta, BNGraph g) {
	// double pro = 1;
	// for (int ix = 0; ix < vexnum; ix++) {
	// ArrayList<Integer> al = g.GetNode(ix).GetParentNodesIndex();
	// Map tempMap = (Map) theta.get(ix);
	// // ������ѯ���飬��������ֵ��ȡ��thetaֵ
	// int index = this.calcNodeIndex(data, ix, al);
	//
	// pro *= (Double) tempMap.get(index);
	// }
	// return pro;
	// }
	//
	// /**
	// * �������ݼ���
	// *
	// * @param g
	// * BNGraph ����ṹ
	// * @param Theta
	// * Map ����
	// * @param datanum
	// * int ���ݼ�����
	// * @return String[][]
	// */
	//
	// public String[][] genDataFromNet(BNGraph g, Map Theta, int datanum) {
	// String[][] data = new String[datanum][vexnum];
	// for (int ix = 0; ix < datanum; ix++) {
	// data[ix] = this.genDataFromNetSingle(g, Theta);
	// }
	// return data;
	// }
	//
	// /**
	// * �������ݼ����������һ�������÷�����һ������
	// *
	// * @param g
	// * BNGraph
	// * @param Theta
	// * Map
	// * @param data
	// * String[][]
	// */
	//
	// public void genDataFromNet(BNGraph g, Map Theta, String[][] data) {
	// for (int ix = 0; ix < data.length; ix++) {
	// data[ix] = this.genDataFromNetSingle(g, Theta);
	//
	// }
	// }
	//
	// /**
	// * ����Theta����һ������
	// *
	// * @param g
	// * BNGraph
	// * @param Theta
	// * Map
	// * @return String[]
	// */
	// private String[] genDataFromNetSingle(BNGraph g, Map Theta) {
	// String[] data = new String[vexnum];
	// for (int ix = 0; ix < EM.AlarmOrder.length; ix++) {
	// int node = EM.AlarmOrder[ix] - 1; // �����Ľڵ�
	// Map t = (Map) Theta.get(node);
	// String value = "*";
	// int[] index = this.calcIndex(node, g, data);
	// CommonTools.outArray(index, pw);
	// value = this.genRandomValue(index, t, this.random.nextDouble());
	// data[node] = value;
	// }
	// return data;
	// }
	//
	// /**
	// * ����һ�����ݵ��������� ���磺����ĸ�ڵ�ȡֵΪ0��0ʱ����ǰ�ڵ������ȡֵ�ĸ��ʱ�����������000��100��200��������
	// * Ȼ����ݸ��������һ��ȡ����Ӧ�ķ������ʣ�Ȼ�����������ɣ���������0.1��0.1��0.8��
	// *
	// * @param nodenum
	// * int
	// * @param g
	// * BNGraph
	// * @param data
	// * String[]
	// * @return int[]
	// */
	//
	// private int[] calcIndex(int nodenum, BNGraph g, String[] data) {
	// int[] indexArray = new int[K2.NodeInfo[nodenum].size()];
	// ArrayList al = g.GetNode(nodenum).GetParentNodesIndex();
	// if (al.size() == 0) {
	// for (int i = 0; i < indexArray.length; i++) {
	// indexArray[i] = i;
	// }
	// } else {
	// Collections.sort(al);
	// int sum = 0; // ��ĸ�ڵ����
	// for (int ix = 0; ix < al.size() - 1; ix++) {
	// int tempnode = (Integer) al.get(ix);
	// String TempNodeValue = data[tempnode];
	// int temp = Integer.parseInt(TempNodeValue);
	// sum += temp * K2.NodeInfo[(Integer) al.get(ix + 1)].size();
	// }
	// // �������ϵ�һλ��λ��
	// sum += Integer.parseInt(data[(Integer) al.get(al.size() - 1)]);
	// int qi = 1;
	// for (int ix = 0; ix < al.size(); ix++) {
	// qi *= EM.AlarmNodeDef[(Integer) al.get(ix)];
	// }
	// for (int ix = 0; ix < indexArray.length; ix++) {
	// indexArray[ix] = ix * qi + sum;
	// }
	// }
	// return indexArray;
	// }
	//
	// public int calcNodeIndex(String[] data, int nodenum,
	// ArrayList<Integer> parent) {
	// Collections.sort(parent);
	// int index = 0;
	// // indexarrayΪ��ֵ���飬������Ӧnodenum����ӽṹ��������data�е�ȷ��ȡֵ��
	// int[] indexarray = new int[parent.size() + 1];
	// indexarray[0] = Integer.parseInt(data[nodenum]);
	// for (int ix = 0; ix < parent.size(); ix++) {
	// indexarray[ix + 1] = Integer.parseInt(data[parent.get(ix)]);
	// }
	// // ��������
	// for (int ix = 0; ix < indexarray.length - 1; ix++) {
	// index += indexarray[ix] * K2.NodeInfo[parent.get(ix)].size();
	// }
	// index += indexarray[indexarray.length - 1];
	// return index;
	// }
	//
	// /**
	// * û��
	// *
	// * @param ranNum
	// * double
	// * @param nodeTheta
	// * double
	// * @return String
	// */
	// private String genRandomValue(int[] index, Map theta, double randNum) {
	// String value = "0";
	// double[] proarray = new double[index.length];
	// for (int ix = 0; ix < proarray.length; ix++) {
	// proarray[ix] = (Double) theta.get(index[ix]);
	// // System.out.println("pro:" + proarray[ix] + " index:" + index[ix]
	// // +
	// // " randnum:" + randNum +" theta"+theta);
	// }
	// double sum = 0.0;
	// for (int i = 0; i < proarray.length; i++) {
	// sum += proarray[i];
	// if (sum > randNum) {
	// value = Integer.toString(i);
	// break;
	// }
	// }
	//
	// return value;
	// }
	//
	//
	//
	// /**
	// * �����ʼ��Theta0
	// *
	// * @param g
	// * BNGraph
	// * @return Map
	// */
	// public Map initTheta0(BNGraph g) {
	// Map result = new HashMap();
	// for (int i = 0; i < g.getVexNum(); i++) {
	// ArrayList al = g.GetNode(i).GetParentNodesIndex();
	// if (al.size() == 0) {
	// int nodenum = EM.AlarmNodeDef[i];
	// double[] temp = this.getRandom(nodenum);
	// result.put(i, temp);
	// } else {
	// int parentnum = 1;
	// Iterator it = al.iterator();
	// while (it.hasNext()) {
	// parentnum *= (Integer) it.next();
	// }
	// int nodenum = EM.AlarmNodeDef[i];
	// double[] resulttemp = new double[parentnum * nodenum];
	// // ��־λ�����parennum�Σ�ÿ���������nodenum��С�ĸ��ʾ��󣬿�����һ��������
	// int tag = 0;
	// for (int ix = 0; ix < parentnum; ix++) {
	// double[] temp = this.getRandom(nodenum);
	// System.arraycopy(temp, 0, resulttemp, tag, temp.length);
	// tag = tag + temp.length;
	// }
	// result.put(i, resulttemp);
	// }
	// }
	// return result;
	// }
	//
	// /**
	// * �����޲�������ݼ�
	// *
	// * @param dataset
	// * String[][]
	// * @param g
	// * BNGraph
	// * @param cpt
	// * Map
	// * @return String[][]
	// */
	// private String[][] completeData(String[][] dataset, BNGraph g, Map cpt) {
	// return new String[10][10];
	// }
	//
	// /**
	// * ת����key
	// *
	// * @param al
	// * ArrayList
	// * @return String
	// */
	// private String convertToString(ArrayList<Integer> al) {
	// StringBuilder sb = new StringBuilder();
	// for (int i = 0, size = al.size(); i < size; i++) {
	// sb.append(al.get(i));
	// sb.append(",");
	// }
	// return sb.toString();
	// }
	// /**
	// *
	// * @param size
	// * int
	// * @return double[]
	// */
	// private double[] getRandom(int size) {
	// double[] array = new double[size];
	// double foot = this.random.nextDouble() % 0.5;
	// array[0] = foot;
	// for (int ix = 1; ix < size; ix++) {
	// double base = this.random.nextDouble() % (1 - foot);
	// array[ix] = base;
	// foot += base;
	// }
	// return array;
	// }

	/**
	 * ������Ŀǰ�õĺ��������ϵĲ�����
	 */

	/**
	 * ����ȱʧ����
	 * 
	 * @param OriginData
	 *            double[][]
	 * @param MissData
	 *            double[][]
	 * @param percent
	 *            doubleȱʧ�ٷֱ�
	 * @param colMissValue
	 *            boolean[]
	 */
	public String[][] genMissDataSet(String[][] OriginData, double percent) {
		String[][] MissData = new String[OriginData.length][OriginData[0].length];
		CommonTools.arraycopy(OriginData, MissData);
		int TotalMissNum = (int) (MissData.length * MissData[0].length * percent);
		int count = 0;
		while (count < TotalMissNum) {
			int indexi = Math.abs(this.random.nextInt() % MissData.length);
			int indexj = Math.abs(this.random.nextInt() % vexnum);
			String value = MissData[indexi][indexj];
			if (!value.equals("*")) {
				MissData[indexi][indexj] = "*";
				count++;
			}
		}
		return MissData;
	}

	/*
	 * ����s�е��ظ�����
	 */
	String[][] eliminateData(String[][] s){
		int col = s[0].length;
		int row = s.length;
		String[] temp = null;
		String[] temp2 = null;
		ArrayList<String[]> list = new ArrayList<String[]>();
		for(int i =0; i < row-1; i++){
			if(s[i] !=null){
				temp = s[i];
				for(int j = i+1; j < row; j++){
					//�ж�һ���Ƿ���ͬ
					temp2 = s[j];
					if(temp2 != null && this.isSame(temp, temp2))
						s[j] = null;
				}
			}
						   
		}
		for(int i = 0; i < row; i++){
			if(s[i]!=null)
				list.add(s[i]);
		}
		System.out.println(list.size());
		String[][] result = new String[list.size()][col];
		for(int i = 0; i < result.length; i++){
			result[i] = list.remove(0);
		}
		return result;
		
	}
	
	private boolean isSame(String[] s1, String[] s2){
		for(int i = 0;i < s1.length; i++){
			if(!s1[i].equals(s2[i]))
				return false;
		}
		return true;
		
	}
	/**
	 * �������ݼ�Ӧ��MCAR
	 * 
	 * @param OriginData
	 * @param percent
	 * @return
	 */
	public String[][] genMissDataSetMCAR(String[][] OriginData, double percent) {

		String[][] MissData = new String[OriginData.length][OriginData[0].length];
		CommonTools.arraycopy(OriginData, MissData);
		for (int i = 0; i < OriginData.length; i++) {
			for (int j = 0; j < OriginData[0].length; j++) {
				if (this.random.nextDouble() < percent) {
					MissData[i][j] = "*";
				}
			}
		}
		return MissData;
	}

	public void genMissDatasetMCAR(DataSet ds, double percent) {
		Random r = new Random();

		int num = ds.getRecordCount();
		int varcount = ds.getVariableCount();
		for (int i = 0; i < num; i++) {
			for (int j = 0; j < varcount; j++) {
				if (r.nextDouble() < percent) {
					ds.setInt(j, i, -1);
				}
			}
		}
	}

	/**
	 * �洢���ݼ�
	 * 
	 * @param dataset
	 * @param filepath
	 */
	public void saveDataset(String[][] dataset, String filepath) {
		try {

			BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
			for (int i = 0; i < dataset.length; i++) {
				for (int j = 0; j < dataset[0].length; j++) {
					bw.append(dataset[i][j]);
					bw.append(" ");
				}
				bw.append("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public double log2(double value) {
		return Math.log(value) / Math.log(2);

	}

	private List getRandomList(int size) {
		List list = new LinkedList<BBNPDF>();
		double foot = this.random.nextDouble() % 0.5;
		list.add(new BBNPDF(foot));
		for (int ix = 1; ix < size; ix++) {
			double base = this.random.nextDouble() % (1 - foot);
			list.add(new BBNPDF(base));
			foot += base;
		}
		return list;
	}

	/**
	 * convert the bjut bn graph to bnj graph;
	 * 
	 * @param g
	 * @return
	 */
	public BBNGraph TranBNtoBBN(BNGraph g,
			Map<String, Map<String, Double>> theta) {
		BBNGraph bbng = new BBNGraph();
		bbng.setName("alarm(bjut->bnj)");
		// ��ʼ���ڵ�
		ArrayList<Integer> parent = new ArrayList<Integer>();
		for (int i = 0; i < theta.size(); i++) {
			StringBuilder sb = new StringBuilder("x");
			sb.append(i);
			BBNNode node = new BBNNode(bbng, sb.toString());
			bbng.addNode(node);
			BBNDiscreteValue v = new BBNDiscreteValue();
			for (int j = 0; j < EM.AlarmNodeDef[i]; j++)
				v.add(String.valueOf(j));
			node.setValues(v);
		}

		// ���ñ�
		int[][] edges = g.GetArcArray();
		for (int i = 0; i < edges.length; i++) {
			for (int j = 0; j < edges[0].length; j++) {
				if (edges[i][j] == 1) {
					bbng.addEdge(bbng.getNode("x" + i), bbng.getNode("x" + j));
				}
			}
		}

		for (int i = 0; i < theta.size(); i++) {
			StringBuilder sb = new StringBuilder("x");
			sb.append(i);
			BBNNode node = (BBNNode) bbng.getNode(sb.toString());
			Map<String, Double> t = theta.get(sb.toString());
			parent = g.GetNode(i).GetParentNodesIndex();

			// ���ýڵ��CPF��
			Hashtable<Hashtable, BBNPDF> ht = this.genBBNCPFfromTheta(sb
					.toString(), parent, t);
			node.setCPF(ht);
		}
		return bbng;
	}

	/**
	 * ��bjut BN�Ĳ���theta ת����bnj��theta��ʽ
	 * 
	 * @param curNode
	 * @param parent
	 * @param theta
	 * @return
	 */
	public Hashtable genBBNCPFfromTheta(String curNode,
			ArrayList<Integer> parent, Map<String, Double> theta) {
		Hashtable cpf = new Hashtable<Hashtable, BBNPDF>();
		Set<String> keys = theta.keySet();
		for (Iterator<String> iter = keys.iterator(); iter.hasNext();) {
			String key = iter.next();
			double value = theta.get(key);
			BBNPDF pdf = new BBNPDF(value);
			Hashtable keytable = this.genHashtableData(key, curNode, parent);
			cpf.put(keytable, pdf);
		}
		return cpf;
	}

	/**
	 * ����parent���� ����ÿһ��bjut theta�е�key��ת����bnj��hashtable��ʽ ��ǰ�ڵ�Ϊx1��001 ת���� x1 =
	 * 0, x2 = 0, x3 = 1
	 * 
	 * @param key
	 * @param nodenum
	 * @param parent
	 * @return
	 */
	public Hashtable genHashtableData(String key, String curNode,
			ArrayList<Integer> parent) {
		Hashtable cpf = new Hashtable<String, String>();
		cpf.put(curNode, key.substring(0, 1));
		for (int i = 1; i < key.length(); i++) {
			cpf.put("x" + parent.get(i - 1), key.substring(i, i + 1));
		}
		return cpf;
	}

	public String[][] genInitData(String[][] MissData) {
		String[][] DesData = new String[MissData.length][MissData[0].length];
		for (int i = 0; i < MissData.length; i++) {
			for (int j = 0; j < MissData[0].length; j++) {
				if (MissData[i][j].equals("?")) {
					String CurNodeName = AlarmReader.index2nodeName
							.get(j + 1);
					BBNNode node = (BBNNode) this.alarm.getNode(CurNodeName);
					Hashtable cpf = new Hashtable<String, Double>();
					BBNDiscreteValue values = (BBNDiscreteValue) node
							.getValues();

					int size = values.size();
					double pro = 1.0 / size;
					Iterator iter = values.iterator();
					while (iter.hasNext()) {
						String tempkey = (String) iter.next();
						cpf.put(tempkey, pro);
					}

					String tempvalue = this.genRandValueFromDistri(CurNodeName,
							cpf);
					DesData[i][j] = tempvalue;

				} else {
					DesData[i][j] = MissData[i][j];
				}
			}
		}
		return DesData;
	}

	public String[][] genInitData2(String[][] MissData) {
		String[][] dest = new String[MissData.length][MissData[0].length];
		Random r = new Random();
		for (int i = 0; i < MissData.length; i++) {
			for (int j = 0; j < MissData[0].length; j++) {
				String cur = MissData[i][j];
				if (cur.equals("*")) {
					int range = AlarmReader.AlarmNodeDef[j];
					int value = r.nextInt(range);
					dest[i][j] = Integer.toString(value);
				} else {
					dest[i][j] = cur;
				}
			}
		}
		return dest;
	}
	
	
	

	/**
	 * EM�㷨
	 * 
	 * @param g
	 * @param data
	 * @param rou
	 * @param MaxIterTimes
	 * @return
	 */
	public Hashtable goEM(BBNGraph g, String[][] data, double rou,
			int MaxIterTimes) {
		Hashtable RandTheta = this.genRandCPF(g);
		this.setThetatoGraph(g, RandTheta);
		Hashtable InitMijk = this.getAllMijk(g, data);
		double OldScore = this.calcLikeHood(g, InitMijk, RandTheta);
		double NewScore = Double.POSITIVE_INFINITY;

		System.out.println("OldScore:" + OldScore);
		EMMI.emmilog.println("OldScore:" + OldScore);
		Hashtable AllMijk = null;
		Hashtable AllTheta = null;
		int t = 0;
		while (t < MaxIterTimes) {
			AllMijk = this.getAllMijk(g, data);
			AllTheta = this.calcAllThetaijk(g, AllMijk);
			System.out.println("EM Iter:" + t + " NewScore:" + NewScore);
			EMMI.emmilog.println("EM Iter:" + t + " NewScore:" + NewScore);

			NewScore = this.calcLikeHood(g, AllMijk, AllTheta);
			if ((OldScore - NewScore) / OldScore > rou) {
				OldScore = NewScore;
				this.setThetatoGraph(g, AllTheta);
			} else {
				System.out.println("�����˳�");
				EMMI.emmilog.println("�����˳�");
				return AllTheta;
			}
			t++;
		}
		System.out.println("�������˳�");
		EMMI.emmilog.println("�������˳�");
		return AllTheta;
	}

	/**
	 * ��bjut graphת����bnj graph
	 * 
	 * @param g
	 * @return
	 */
	public BBNGraph TranBNtoBBN(BNGraph g) {
		BBNGraph bbng = new BBNGraph();
		bbng.setName("alarm(bjut->bnj)");
		// ��ʼ���ڵ�
		for (int i = 0; i < g.getVexNum(); i++) {
			String CurNodeName = AlarmReader.index2nodeName.get(i + 1);
			BBNNode node = new BBNNode();
			BBNDiscreteValue values = (BBNDiscreteValue) ((BBNNode) this.alarm
					.getNode(CurNodeName)).getValues();
			node.setValues(values);
			node.setName(CurNodeName);
			bbng.add(node);
		}
		// ���ñ�
		int[][] edges = g.GetArcArray();
		for (int i = 0; i < edges.length; i++) {
			for (int j = 0; j < edges[0].length; j++) {
				if (edges[i][j] == 1) {
					String srcName = AlarmReader.index2nodeName
							.get(i + 1);
					String desName = AlarmReader.index2nodeName
							.get(j + 1);
					BBNNode src = (BBNNode) bbng.getNode(srcName);
					BBNNode des = (BBNNode) bbng.getNode(desName);
					bbng.addEdge(src, des);
				}
			}
		}

		Set NodeNames = bbng.getNodeNames();
		Iterator iter = NodeNames.iterator();
		while (iter.hasNext()) {
			String CurNodeName = (String) iter.next();
			BBNNode CurNode = (BBNNode) bbng.getNode(CurNodeName);
			List names = new LinkedList(CurNode.getParents());
			names.add(CurNode);
			Hashtable CurCPF = new Hashtable<Hashtable, BBNCPF>();
			this.genRandCPFNode(CurCPF, names, new Hashtable<String, String>(),
					new LinkedList());
			CurNode.setCPF(CurCPF);
		}

		return bbng;
	}

	/**
	 * Multiple Imputation ��������
	 * 
	 * @param g
	 * @param oriData
	 * @param Mtimes
	 *            ÿ��ȱʧ�������ɵ�������
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String[][] MIDataset(BBNGraph g, String[][] oriData, int Mtimes) {
		ArrayList CompleteData = new ArrayList<String[]>();

		LS ls = new LS(g);
		for (int i = 0; i < oriData.length; i++) {
			String[] curData = oriData[i];
			if (this.isDataMiss(curData)) {
				Hashtable evidence = this.genEvidenceTable(curData);
				g.clearEvidenceNodes();
				g.setEvidenceNodes(evidence);
				InferenceResult result = ls.getMarginals();
				ArrayList MissValues = new ArrayList<ArrayList>();
				for (int j = 0; j < curData.length; j++) {
					if (curData[j].equals("*")) {
						ArrayList value = new ArrayList<String>();
						String curMissNodeName = AlarmReader.index2nodeName
								.get(j + 1);
						// System.out.println(j+":"+curMissNodeName);
						Hashtable dist = (Hashtable) result
								.get(curMissNodeName);
						for (int k = 0; k < Mtimes; k++) {
							value.add(this.genRandValueFromDistri(
									curMissNodeName, dist));
						}
						MissValues.add(value);
					}
				}
				for (int k = 0; k < Mtimes; k++) {
					int count = 0;
					String[] complete = new String[curData.length];
					for (int j = 0; j < curData.length; j++) {
						if (!curData[j].equals("*")) {
							complete[j] = curData[j];
						} else {
							complete[j] = (String) ((ArrayList) MissValues
									.get(count++)).remove(0);
						}
					}
					CompleteData.add(complete);
				}
			} else {
				CompleteData.add(curData);
			}
		}
		String[][] destData = new String[CompleteData.size()][37];
		for (int i = 0; i < destData.length; i++) {
			destData[i] = (String[]) CompleteData.remove(0);
		}
		return destData;
	}
	
	/**
	 * Multiple Imputation ��������
	 * 
	 * @param g
	 * @param oriData
	 * @param Mtimes
	 *            ÿ��ȱʧ�������ɵ�������
	 * @return
	 */
	public String[][] MIDataset2(BBNGraph g, String[][] oriData, int Mtimes) {
		ArrayList CompleteData = new ArrayList<String[]>();

		LS ls = new LS(g);
		for (int i = 0; i < oriData.length; i++) {
			String[] curData = oriData[i];
			if (this.isDataMiss(curData)) {
				Hashtable evidence = this.genEvidenceTable(curData);
				g.clearEvidenceNodes();
				g.setEvidenceNodes(evidence);
				InferenceResult result = ls.getMarginals();
				ArrayList MissValues = new ArrayList<ArrayList>();
				for (int j = 0; j < curData.length; j++) {
					if (curData[j].equals("*")) {
						ArrayList value = new ArrayList<String>();
						String curMissNodeName = AlarmReader.index2nodeName
								.get(j + 1);
						// System.out.println(j+":"+curMissNodeName);
						Hashtable dist = (Hashtable) result
								.get(curMissNodeName);
						for (int k = 0; k < Mtimes; k++) {
							value.add(this.genRandValueFromDistri(
									curMissNodeName, dist));
						}
						MissValues.add(value);
					}
				}
				for (int k = 0; k < Mtimes; k++) {
					int count = 0;
					String[] complete = new String[curData.length];
					for (int j = 0; j < curData.length; j++) {
						if (!curData[j].equals("*")) {
							complete[j] = curData[j];
						} else {
							complete[j] = (String) ((ArrayList) MissValues
									.get(count++)).remove(0);
						}
					}
					CompleteData.add(complete);
				}
			} else {
				CompleteData.add(curData);
			}
		}
		String[][] destData = new String[CompleteData.size()][37];
		for (int i = 0; i < destData.length; i++) {
			destData[i] = (String[]) CompleteData.remove(0);
		}
		return destData;
	}

	/**
	 * missdata ��������ʽ
	 * ��smile em�������
	 * @param net
	 * @param missdata
	 * @param num
	 * @return
	 */
	public String[][] MISmile(Network net, String[][] missdata, DataSet ds,
			int num) {
		int[] nodes = net.getAllNodes();
		HashMap<String, Integer> order = new HashMap<String, Integer>();
		for (int i = 0; i < nodes.length; i++) {
			order.put(net.getNodeName(nodes[i]), i);
		}
		HashMap<String, Integer> orderds = new HashMap<String, Integer>();
		for (int i = 0; i < nodes.length; i++) {
			String name = ds.getVariableId(i);
			orderds.put(name, i);
		}
		ArrayList complete = new ArrayList<String[]>();
		int err_evidenc_count = 0;
		for (int i = 0; i < missdata.length; i++) {
			String[] curdata = missdata[i];
			try {
				if (this.isDataMiss(curdata)) {
					// set evidence;
					net.clearAllEvidence();
					int handle = net.getFirstNode();
					String curnodename = null;
					String curvalue = null;
					int curindex = 0;
					while (handle < 37) {
						curnodename = net.getNodeName(handle);
						String[] values = ds.getStateNames(orderds
								.get(curnodename));

						curindex = AlarmReader.nodeName2index.get(curnodename) - 1;
						if (!curdata[curindex].equals("*")) {
							curvalue = values[Integer
									.parseInt(curdata[curindex])];
							if (!net.isPropagatedEvidence(curnodename)
									&& !net.isEvidence(curnodename)) {	
								net.setEvidence(curnodename, curvalue);
							}
						}
						handle = net.getNextNode(handle);
					}
					// update
					net.updateBeliefs();
					// query
					String[] temp = new String[curdata.length];
					System.arraycopy(curdata, 0, temp, 0, curdata.length);
					for (int j = 0; j < temp.length; j++) {
						if (temp[j].equals("*")) {
							int curnode = order.get(AlarmReader.index2nodeName
									.get(j + 1));
							double[] curpros = net.getNodeValue(curnode);
							int infervalue = this.getRandFromDistri(curpros);
							temp[j] = Integer.toString(infervalue);
						}
					}
					complete.add(temp);
				} else {
					System.err.println("can not be here!!!");
					complete.add(curdata);
				}
			} catch (Exception e) {
				err_evidenc_count++;
				System.err.println("ignore evidence"+err_evidenc_count);
			}
		}
		//���³�����err_evidenc_count��������䵽complete��
		if(err_evidenc_count !=0){
			System.out.println("�������");
			net.clearAllEvidence();
			net.updateBeliefs();
			for(int i = 0; i < err_evidenc_count; i++){
				String[] temp = new String[missdata[0].length];
				for (int j = 0; j < temp.length; j++) {
						int curnode = order.get(AlarmReader.index2nodeName
								.get(j + 1));
						double[] curpros = net.getNodeValue(curnode);
						int infervalue = this.getRandFromDistri(curpros);
						temp[j] = Integer.toString(infervalue);

				}
				complete.add(temp);
			}
			
		}

		String[][] destData = new String[complete.size()][37];		
		System.out.println("size:"+complete.size());
		for (int i = 0; i < destData.length; i++) {
			destData[i] = (String[]) complete.remove(0);
		}
		return destData;

	}
	
	/**
	 * ���ڸ�
	 * 
	 * @param net
	 * @param missdata
	 * @param num
	 * @return
	 */
	public String[][] MISmile2(Network net, String[][] missdata, DataSet ds,
			int num) {
		int[] nodes = net.getAllNodes();
		
		ArrayList complete = new ArrayList<String[]>();
		int err_evidenc_count = 0;
		for (int i = 0; i < missdata.length; i++) {
			String[] curdata = missdata[i];
				if (this.isDataMiss(curdata)) {
					// ֤�ݱ������óɹ������
					if (this.setEvidenceToSNet(net, curdata)) {
						String[] temp = this.sampleOne(net, curdata);
						complete.add(temp);
					} else
					err_evidenc_count++;
				} else {
					complete.add(curdata);
				}
			
		}
		// ���³�����err_evidenc_count��������䵽complete��,
		// ��ֱ���ÿ�֤�ݲ�����
		String[] evi = { "*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*",
				"*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*",
				"*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*",
				"*", "*" };
		int count2 = 0;
		while(count2 < err_evidenc_count){
			System.out.println("�������");		
				String[] curdata = this.sampleOne(net, evi);
				complete.add(curdata);
				count2++;
		}
		String[][] destData = new String[complete.size()][37];
		System.out.println("size:" + complete.size());
		for (int i = 0; i < destData.length; i++) {
			destData[i] = (String[]) complete.remove(0);
		}
		return destData;

	}
	/**
	 * evi�ǹ������ʽ��Network�еĸ��ʱ��ͽڵ�ֵ��λ����һ���ģ������ݼ���һ��һ�� ���Գɹ���ok
	 * 
	 * @param net
	 * @param evi
	 * @return
	 */
	public String[] sampleOne(Network net, String[] evi) {
		String[] temp = new String[evi.length];
		System.arraycopy(evi, 0, temp, 0, evi.length);
		for (int j = 0; j < temp.length; j++) {
			if (temp[j].equals("*")) {
				String curnodename = net.getNodeName(j);
				String[] outcomes = net.getOutcomeIds(curnodename);
				double[] curpros = net.getNodeValue(curnodename);
				int infervalue = this.getRandFromDistri(curpros);
				temp[j] = outcomes[infervalue];
			}
		}
		return temp;
	}

	/**
	 * net��smile������ʽ��evi��bjut�����ݼ���ʽ,evi���ַ�����������ϣ�ok
	 * 
	 * @param net
	 * @param evi
	 * @return
	 */
	public boolean setEvidenceToSNet(Network net, String[] evi) {
		net.clearAllEvidence();
		String curnodename = null;
		try {
			for (int i = 0; i < evi.length; i++) {
				if (!evi[i].equals("*")) {
					curnodename = AlarmReader.index2nodeName.get(i + 1);
					if (!net.isPropagatedEvidence(curnodename)
							&& !net.isEvidence(curnodename)) {
						net.setEvidence(curnodename, evi[i]);
					}
				}
			}
			net.updateBeliefs();
			return true;
		} catch (Exception e) {
			net.clearAllEvidence();
			return false;
		}
	}
	

	public void InfereceWithBayesianNetwork() {
		try {
			Network net = new Network();
			net.readFile("tutorial_a.xdsl");

			// ---- We want to compute P("Forecast" = Moderate) ----
			// Updating the network:
			net.updateBeliefs();

			// Getting the handle of the node "Forecast":
			net.getNode("Forecast");

			// Getting the index of the "Moderate" outcome:
			String[] aForecastOutcomeIds = net.getOutcomeIds("Forecast");
			int outcomeIndex;
			for (outcomeIndex = 0; outcomeIndex < aForecastOutcomeIds.length; outcomeIndex++)
				if ("Moderate".equals(aForecastOutcomeIds[outcomeIndex]))
					break;

			// Getting the value of the probability:
			double[] aValues = net.getNodeValue("Forecast");
			double P_ForecastIsModerate = aValues[outcomeIndex];

			System.out.println("P(\"Forecast\" = Moderate) = "
					+ P_ForecastIsModerate);

			// ---- We want to compute P("Success" = Failure | "Forecast" =
			// Good) ----
			// Introducing the evidence in node "Forecast":
			net.setEvidence("Forecast", "Good");

			// Updating the network:
			net.updateBeliefs();

			// Getting the handle of the node "Success":
			net.getNode("Success");

			// Getting the index of the "Failure" outcome:
			String[] aSuccessOutcomeIds = net.getOutcomeIds("Success");
			for (outcomeIndex = 0; outcomeIndex < aSuccessOutcomeIds.length; outcomeIndex++)
				if ("Failure".equals(aSuccessOutcomeIds[outcomeIndex]))
					break;

			// Getting the value of the probability:
			aValues = net.getNodeValue("Success");
			double P_SuccIsFailGivenForeIsGood = aValues[outcomeIndex];

			System.out
					.println("P(\"Success\" = Failure | \"Forecast\" = Good) = "
							+ P_SuccIsFailGivenForeIsGood);

			// ---- We want to compute P("Success" = Success | "Forecast" =
			// Poor) ----
			// Clearing the evidence in node "Forecast":
			net.clearEvidence("Forecast");

			// Introducing the evidence in node "Forecast":
			net.setEvidence("Forecast", "Good");

			// Updating the network:
			net.updateBeliefs();

			// Getting the index of the "Failure" outcome:
			aSuccessOutcomeIds = net.getOutcomeIds("Success");
			for (outcomeIndex = 0; outcomeIndex < aSuccessOutcomeIds.length; outcomeIndex++)
				if ("Failure".equals(aSuccessOutcomeIds[outcomeIndex]))
					break;

			// Getting the value of the probability:
			aValues = net.getNodeValue("Success");
			double P_SuccIsSuccGivenForeIsPoor = aValues[outcomeIndex];

			System.out
					.println("P(\"Success\" = Success | \"Forecast\" = Poor) = "
							+ P_SuccIsSuccGivenForeIsPoor);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * ��ͼ����CPF��
	 * 
	 * @param g
	 * @param Theta
	 */
	public void setThetatoGraph(BBNGraph g, Hashtable Theta) {
		Set NodeNames = g.getNodeNames();
		Iterator iter = NodeNames.iterator();
		while (iter.hasNext()) {
			String curNodeName = (String) iter.next();
			BBNNode curNode = (BBNNode) g.getNode(curNodeName);
			Hashtable theta = (Hashtable) Theta.get(curNodeName);
			curNode.setCPF(theta);
		}
	}

	/**
	 * 
	 * @param Ϊһ���������������Thetaֵ
	 * @return
	 */
	public Hashtable genRandCPF(BBNGraph g) {
		Hashtable AllTheta = new Hashtable<String, Hashtable>();
		Set Names = g.getNodeNames();
		Iterator iter = Names.iterator();
		while (iter.hasNext()) {
			String curNodeName = (String) iter.next();
			List l = g.getNode(curNodeName).getParents();
			List ll = new LinkedList<BBNNode>(l);
			ll.add(g.getNode(curNodeName));
			Hashtable cpfs = new Hashtable<Hashtable, Double>();
			this.genRandCPFNode(cpfs, ll, new Hashtable(), new LinkedList());
			AllTheta.put(curNodeName, cpfs);
		}
		return AllTheta;
	}

	/**
	 * �ݹ����ɳ�ʼ���CPF,��һ���ڵ�names
	 * 
	 * @param cpfs
	 *            ���
	 * @param names
	 *            �������ڵ�͸�ĸ�ڵ������
	 * @param cpf
	 *            �м����
	 * @param values
	 *            �м����
	 */
	private void genRandCPFNode(Hashtable cpfs, List names, Hashtable cpf,
			List values) {
		if (names.size() == 0) {
			Hashtable cpf1 = new Hashtable<String, String>(cpf);
			cpfs.put(cpf1, values.remove(0));
			return;
		} else {
			BBNNode curNode = (BBNNode) names.remove(0);
			BBNDiscreteValue curNodeValues = (BBNDiscreteValue) curNode
					.getValues();
			Iterator iter = curNodeValues.iterator();
			List values1 = this.getRandomList(curNodeValues.size());
			while (iter.hasNext()) {
				String value = (String) iter.next();
				cpf.put(curNode.getName(), value);
				List names1 = new LinkedList<BBNNode>(names);
				this.genRandCPFNode(cpfs, names1, cpf, values1);
			}
		}
	}

	/**
	 * ����EM���۲���������
	 * 
	 * @param g
	 * @param AllMijk
	 * @return
	 */
	public double calcLikeHood(BBNGraph g, Hashtable AllMijk, Hashtable AllTheta) {
		double result = 0.0;
		Set NodeNames = g.getNodeNames();
		Iterator iter = NodeNames.iterator();
		while (iter.hasNext()) {
			String curNodeName = (String) iter.next();
			Hashtable curMijk = (Hashtable) AllMijk.get(curNodeName);
			Hashtable curTheta = (Hashtable) AllTheta.get(curNodeName);

			Set keys = curMijk.keySet();
			Iterator iter_keys = keys.iterator();
			while (iter_keys.hasNext()) {
				Hashtable tempkey = (Hashtable) iter_keys.next();
				double m = (Double) curMijk.get(tempkey);
				BBNPDF theta1 = (BBNPDF) curTheta.get(tempkey);
				double theta = theta1.getValue();

				result += m * Math.log10(theta);
			}
		}
		return result;
	}

	/**
	 * ��������ͳ��Mijk��ֵ��
	 * 
	 * @param node
	 * @param data
	 * @return
	 */
	private Hashtable getMijk(BBNNode node, String[][] data) {
		Hashtable result = new Hashtable<Hashtable, Double>();
		// ��ͼ�ڵ���ȡ��Mijk��key����Ϣ��Ҫ��node���ڵ�ͼҪ��׼��
		Hashtable nodeCPF = node.getCPF().getTable();
		Set<Hashtable> keys = nodeCPF.keySet();
		Iterator iter = keys.iterator();
		BBNGraph g = (BBNGraph) node.getOwner();
		LS ls = new LS(g);

		for (int i = 0; i < data.length; i++) {
			String[] tempdata = data[i];
			Hashtable evidence = genEvidenceTable(tempdata);
			g.clearEvidenceNodes();
			g.setEvidenceNodes(evidence);
			InferenceResult inferResult = ls.getMarginals();
			iter = keys.iterator();

			while (iter.hasNext()) {
				Hashtable tempkey = (Hashtable) iter.next();
				double tempresult = inferResult.queryX(tempkey);
				if (result.containsKey(tempkey)) {
					double temp = (Double) result.get(tempkey);
					temp += tempresult;
					result.put(tempkey, temp);
				} else {
					result.put(tempkey, tempresult);
				}
			}
		}
		return result;
	}

	/**
	 * ȡ��ͼg����ȱʧ����data��Mijkͳ��ֵ�����ص�hashtable<String, Hashtable>
	 * 
	 * @param g
	 * @param data
	 * @return
	 */
	public Hashtable getAllMijk(BBNGraph g, String[][] data) {

		Hashtable AllMijk = new Hashtable<String, Hashtable>();
		Set NodeNames = g.getNodeNames();

		LS ls = new LS(g);
		for (int i = 0; i < data.length; i++) {
			String[] tempdata = data[i];
			Hashtable evidence = genEvidenceTable(tempdata);
			g.clearEvidenceNodes();
			g.setEvidenceNodes(evidence);
			InferenceResult inferResult = ls.getMarginals();
			Iterator iter_NN = NodeNames.iterator();

			while (iter_NN.hasNext()) {
				String curNodeName = (String) iter_NN.next();
				BBNNode curNode = (BBNNode) g.getNode(curNodeName);
				Hashtable nodeCPF = curNode.getCPF().getTable();

				Set<Hashtable> keys = nodeCPF.keySet();
				Iterator iter = keys.iterator();
				iter = keys.iterator();

				Hashtable result = (Hashtable) AllMijk.get(curNodeName);
				if (result == null) {
					result = new Hashtable<Hashtable, Double>();
				}
				// System.out.println("��ǰ�ڵ㣺"+curNodeName);
				while (iter.hasNext()) {
					Hashtable tempkey = (Hashtable) iter.next();
					double tempresult = inferResult.queryX(tempkey);
					// System.out.println(tempkey+":"+tempresult);
					if (result.containsKey(tempkey)) {
						double temp = (Double) result.get(tempkey);
						temp += tempresult;
						result.put(tempkey, temp);
					} else {
						result.put(tempkey, tempresult);
					}
				}
				AllMijk.put(curNodeName, result);
			}
		}
		return AllMijk;
	}

	/**
	 * ��data�����ݣ�ת����֤�ݵ���ʽ, ���⣺����ȱʧ�Ĵ�������
	 * 
	 * @param data
	 * @return
	 */
	public Hashtable genEvidenceTable(String[] data) {
		Hashtable e = new Hashtable<String, String>();
		for (int i = 0; i < data.length; i++) {
			if (!data[i].equals("*")) {
				String nodename = AlarmReader.index2nodeName
						.get(i + 1);
				String key = data[i];
				e.put(nodename, key);

			}
		}
		return e;
	}

	public String compareGraph(BBNGraph sg, BBNGraph g) {
		StringBuilder sb = new StringBuilder();
		Set add = new HashSet();
		Set del = new HashSet();
		Set rev = new HashSet();
		Set right = new HashSet();

		Set edges_g = g.getEdges();
		Iterator iter = edges_g.iterator();
		while (iter.hasNext()) {
			Edge e = (Edge) iter.next();
			BBNNode src = (BBNNode) e.getSource();
			BBNNode des = (BBNNode) e.getDestination();
			Edge reve = new Edge(des, src);

			if (sg.containsEdge(e)) {
				// ��
				right.add(e);
			} else if (sg.containsEdge(reve)) {
				rev.add(reve);
			} else {
				add.add(e);
			}
		}
		Set edges_sg = sg.getEdges();
		Iterator iter_sg = edges_sg.iterator();
		while (iter_sg.hasNext()) {
			Edge e = (Edge) iter_sg.next();
			BBNNode src = (BBNNode) e.getSource();
			BBNNode des = (BBNNode) e.getDestination();
			Edge reve = new Edge(des, src);
			if (g.containsEdge(e)) {
				right.add(e);

			} else if (g.containsEdge(reve)) {

			} else {
				del.add(e);
			}
		}
		sb.append("���:" + add.size());
		sb.append(add.toString());
		sb.append("\n");
		sb.append("�ٱ�:" + del.size());
		sb.append(del.toString());
		sb.append("\n");
		sb.append("����" + rev.size());
		sb.append(rev.toString());
		sb.append("\n");
		sb.append("��ȷ:" + right.size());
		sb.append(right.toString());
		sb.append("\n");
		return sb.toString();
	}

	/**
	 * ����Mijk�������ͼ��Thetaֵ
	 * 
	 * @param g
	 * @param AllMijk
	 * @return
	 */
	public Hashtable calcAllThetaijk(BBNGraph g, Hashtable AllMijk) {
		Hashtable AllTheta = new Hashtable<String, Hashtable>();
		Set Names = g.getNodeNames();
		Iterator iter = Names.iterator();
		while (iter.hasNext()) {
			String curNodeName = (String) iter.next();
			Hashtable mijk = (Hashtable) AllMijk.get(curNodeName);
			Hashtable theta = this.calcThetaijk((BBNNode) g
					.getNode(curNodeName), mijk);
			AllTheta.put(curNodeName, theta);
		}
		return AllTheta;
	}

	/**
	 * ����Thetaijk��ֵ,���ÿ���ڵ㡣
	 * 
	 * @param node
	 * @param Mijk
	 * @return
	 */
	public Hashtable calcThetaijk(BBNNode node, Hashtable Mijk) {
		Hashtable Theta = new Hashtable<Hashtable, BBNPDF>();
		Hashtable Mij = new Hashtable<Hashtable, Double>();
		String curNodeName = node.getName();
		Set keys_Mijk = Mijk.keySet();
		Iterator iter = keys_Mijk.iterator();
		while (iter.hasNext()) {
			Hashtable tempkey = new Hashtable<Hashtable, Double>(
					(Hashtable) iter.next());
			tempkey.remove(curNodeName);
			Mij.put(tempkey, 0.0);
		}
		Set keys_Mij = Mij.keySet();
		Iterator iter_Mij = keys_Mij.iterator();
		while (iter_Mij.hasNext()) {
			Hashtable tempkey = (Hashtable) iter_Mij.next();
			Set temp = tempkey.entrySet();
			iter = keys_Mijk.iterator();
			while (iter.hasNext()) {
				Hashtable tempkey1 = (Hashtable) iter.next();
				Set temp1 = tempkey1.entrySet();
				if (temp1.containsAll(temp)) {
					double tempv = 0.0;
					if (Mij.containsKey(tempkey)) {
						tempv = (Double) Mij.get(tempkey);
						tempv += (Double) Mijk.get(tempkey1);
						Mij.put(tempkey, tempv);
					} else {
						Mij.put(tempkey, tempv);
					}
				}
			}
		}
		iter = keys_Mijk.iterator();
		while (iter.hasNext()) {
			Hashtable tempkey = (Hashtable) iter.next();
			Set set1 = tempkey.entrySet();
			iter_Mij = keys_Mij.iterator();
			while (iter_Mij.hasNext()) {
				Hashtable tempkey2 = (Hashtable) iter_Mij.next();
				Set set2 = tempkey2.entrySet();
				if (set1.containsAll(set2)) {
					double mijk = (Double) Mijk.get(tempkey);
					double mij = (Double) Mij.get(tempkey2);
					double v = 0.0;
					if (mijk > 0.0) {
						v = mijk / mij;
					} else {
						BBNDiscreteValue value = (BBNDiscreteValue) node
								.getValues();
						v = 1.0 / value.size();
					}
					if (v > 1.0) {
						System.err.print("v:" + v + " mijk:" + mijk + " mij:"
								+ mij);
					}
					Theta.put(tempkey, new BBNPDF(v));
				}
			}
		}
		return Theta;
	}

	public void setSeed(long seed) {
		this.random.setSeed(seed);
	}

	public boolean isDataMiss(String[] data) {
		boolean tag = false;
		for (int i = 0; i < data.length; i++) {
			if (data[i].equals("*")) {
				tag = true;
				break;
			}
		}
		return tag;
	}

	/**
	 * ������ ��foward sampling�������ݣ�
	 * 
	 * @param g
	 *            ��������������
	 * @param missdata
	 *            ȱʧ�����ݼ���Ӧ����AlarmReader����GeNIle����
	 * @param num
	 *            ÿ��ȱʧ�����걸������
	 * @return
	 */
	public String[][] Sample(BBNGraph g, String[][] missdata, int num) {
		// missdata��˳��Ӧ����bjut��˳������Ҳ�ñ������˳��
		edu.ksu.cis.bnj.bbn.datagen.ForwardSampling fs = new edu.ksu.cis.bnj.bbn.datagen.ForwardSampling(
				g);
		ArrayList complete = new ArrayList<String[]>();
		for (int i = 0; i < missdata.length; i++) {
			String[] curdata = missdata[i];
			if (isDataMiss(missdata[i])) {
				Hashtable evidence = this.genEvidenceTable(curdata);
				g.clearEvidenceNodes();
				g.setEvidenceNodes(evidence);
				Table tuples = fs.generateData(num);
				LinkedList AttriNames = (LinkedList) tuples.getAttributeNames();
				LinkedList samples = (LinkedList) tuples.getTuples();
				Iterator iter_sample = samples.iterator();
				while (iter_sample.hasNext()) {
					LinkedList cur = (LinkedList) ((Tuple) iter_sample.next())
							.getValues();// sample����data

					String[] temp = new String[cur.size()];
					Iterator iter_cur = cur.iterator();
					int count = 0;
					while (iter_cur.hasNext()) {
						String curval = (String) iter_cur.next();
						if (curval == null) {
							String nullname = (String) AttriNames.get(count);
							int bjutpos = AlarmReader.nodeName2index
									.get(nullname) - 1;
							temp[bjutpos] = curdata[bjutpos];

						} else {
							String samplename = (String) AttriNames.get(count);
							int bjutpos = AlarmReader.nodeName2index
									.get(samplename) - 1;
							temp[bjutpos] = curval;
						}
						count++;
					}
					complete.add(temp);
				}
			} else
				complete.add(curdata);
		}
		String[][] dest = new String[complete.size()][missdata[0].length];
		for (int i = 0; i < dest.length; i++) {
			dest[i] = (String[]) complete.get(i);
		}
		return dest;
	}

	/**
	 * ����dist�ĸ��ʷֲ����������
	 * 
	 * @param NodeName
	 * @param dist
	 * @return
	 */
	public String genRandValueFromDistri(String NodeName, Hashtable dist) {
		String value = null;
		double v = 0.0;
		for (int i = 0; i < 1000; i++) {
			double tag = this.random.nextDouble();
			v = 0.0;
			Set Keys = dist.keySet();
			Iterator iter = Keys.iterator();
			while (iter.hasNext()) {
				String tempkey = (String) iter.next();
				double tempvalue = (Double) dist.get(tempkey);
				v += tempvalue;
				if (v > tag) {
					value = tempkey;
					break;
				}
			}
		}
		return value;
	}

	/**
	 * ����array�����ĸ��ʷֲ�������Ӧ�������
	 * 
	 * @param array
	 * @return
	 */
	public int getRandFromDistri(double[] array) {
		Random r = new Random();
		double v = 0.0;
		double tag;
		for (int i = 0; i < 1000; i++) {
			tag = r.nextDouble();
			v = 0.0;
			for (int j = 0; j < array.length; j++) {
				v += array[j];
				if (v > tag) {
					return j;
				}
			}
		}
		return -1;// ����
	}

	/**
	 * ����likehood�ķ�ʽ����
	 * 
	 * @param g
	 * @param data
	 * @return
	 */
	public double calcLoglossJi(BBNGraph g, String[][] data) {
		double result = -0.0;
		Hashtable AllMijk = this.getAllMijk(g, data);
		Hashtable AllTheta = this.calcAllThetaijk(g, AllMijk);
		result = this.calcLikeHood(g, AllMijk, AllTheta);
		System.out.println("likehood=" + result);
		result = result / data.length;

		return result;
	}

	/**
	 * 
	 * @param g
	 * @param data
	 * @return
	 */
	public double calcLogloss(BBNGraph g, String[][] data) {
		double result = 0.0;
		List order = g.topologicalSort();
		for (int i = 0; i < data.length; i++) {
			double pro = this.calcLoglossCase(g, data[i], order);
			if (pro != 0.0) {
				double logpro = this.log2(pro);
				// log.println("pro:" + pro + " log pro:" + logpro);
				result += logpro;
			}

		}
		return result / data.length;
	}

	private double calcLoglossCase(BBNGraph g, String[] data, List order) {
		double result = 1.0;
		Hashtable evidence = new Hashtable<String, String>();
		String curNodeName = ((BBNNode) order.get(0)).getName();
		String curValue = data[AlarmReader.nodeName2index.get(curNodeName) - 1];
		evidence.put(curNodeName, curValue);
		BBNNode node = (BBNNode) g.getNode(curNodeName);
		BBNCPF cpf = node.getCPF();
		double pro = cpf.get(evidence);
		result *= pro;
		for (int i = 0; i < data.length - 1; i++) {
			curNodeName = ((BBNNode) order.get(i + 1)).getName();
			curValue = data[AlarmReader.nodeName2index.get(curNodeName) - 1];
			evidence.put(curNodeName, curValue);
			node = (BBNNode) g.getNode(curNodeName);
			cpf = node.getCPF();
			pro = cpf.get(evidence);
			result *= pro;
		}
		return result;
	}

	/**
	 * ����logloss��ֱ�Ӳ�ѯ
	 * 
	 * @param g
	 * @param data
	 * @return
	 */
	public double calcLoglossD(BBNGraph g, String[][] data) {
		double result = 0.0;
		Hashtable query = new Hashtable<String, String>();
		String nodename = null;
		BBNNode node = null;
		BBNCPF cpf = null;
		double pro = 0.0;
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[0].length; j++) {
				nodename = AlarmReader.index2nodeName.get(j + 1);
				query.put(nodename, data[i][j]);
			}
			for (int j = 0; j < data[0].length; j++) {
				nodename = AlarmReader.index2nodeName.get(j + 1);
				node = (BBNNode) g.getNode(nodename);
				cpf = node.getCPF();
				pro = cpf.query(query);
				result += Math.log(pro);
			}
		}
		return result / data.length;
	}

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		// K2.INSTANCE = K2.getK2("alarm_20071019.TXT", 3000, 37);
		// BNGraph g = BNGraph.GetGraphStandAlarm();
		BBNGraph g = BBNGraph.load("data\\alarm.xml");
		EM em = new EM();
		AlarmReader ar = new AlarmReader("c:\\Alarm.txt", 1000, 37);
		String[][] Missdata = ar.GetGeNIleDataset();

		String[][] complete = em.Sample(g, Missdata, 2);
		System.out.println(complete.length);

		// CommonTools.outArray(complete);

		// Hashtable AllMijk = em.getAllMijk(g, Missdata);
		// Hashtable AllTheta = em.calcAllThetaijk(g, AllMijk);
		// em.setThetatoGraph(g, AllTheta);
		// g.save("c:\\test.xml");

		long end = System.currentTimeMillis();
		System.out.println("time(s):" + (end - start) / 1000);
	}
}
