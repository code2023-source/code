//package bjut.ai.sem;
//import java.util.*;
///**
// * <p>Title: </p>
// *
// * <p>Description: </p>
// *
// * <p>Copyright: Copyright (c) 2008</p>
// *
// * <p>Company: </p>
// *
// * @author not attributable
// * @version 1.0
// */
//public class Function implements Comparable
//{
//    private String[] ids = null;
//    private ArrayList<String> Evidence;
//    private ArrayList<Integer> Evalue;
//    private String ID = null;
//    private HashMap<String, Double> theta = null;
//
//    public Function(String ID, HashMap m)
//    {
//        this.ID = ID;
//        this.theta = new HashMap<String,Double>(m);
//        this.Evidence = new ArrayList<String>();
//        this.Evalue = new ArrayList<Integer>();
//        this.ids = this.ID.split(",");
//    }
//    public Function(String ID, HashMap m, ArrayList<String> E, ArrayList<Integer> Evalue)
//    {
//        this.ID = ID;
//       this.theta = new HashMap<String,Double>(m);
//       this.Evidence = new ArrayList<String>(E);
//       this.Evalue = new ArrayList<Integer>(Evalue);
//       this.ids = this.ID.split(",");
//    }
//    
//    public void clear()
//    {
//    	this.ID = null;
//    	this.theta = null;
//    	this.Evalue = null;
//    	this.Evidence = null;
//    	this.ids = null;
//    }
//    
//    public void setID(String id)
//    {
//    	this.ID = id;
//    	this.ids = this.ID.split(",");
//    }
//    public void setTheta(HashMap<String, Double> theta)
//    {
//    	this.theta = theta;
//    }
//    public void setEvidence(ArrayList<String> evidence)
//    {
//    	this.Evidence = evidence;
//    }
//    public void setEvalue(ArrayList<Integer> evalue)
//    {
//    	this.Evalue = evalue;
//    }
//    public HashMap<String,Double> getTheta()
//    {
//        return this.theta;
//    }
//    public int compareTo(Object o)
//    {
//        return (this.ID.length() >((Function)o).ID.length()) ? 1
//                : ((this.ID.length() == ((Function)o).ID.length())? 0 : -1);
//    }
//
//    
//    public boolean FIDEquals(String s)
//    {
//    	boolean tag = false;
//    	if(this.ids.length == 1 && this.ids[0].equals(s))
//    		tag = true;
//    	return tag;
//    }
//    /**
//     * c=0ʱ��ȡ��P��c���ĸ���
//     * @param key String
//     * @return double
//     */
//    public double getValue(String key)
//    {
//        //�ж�
////        if(key.length() != this.ID.length())
////        {
////            System.err.println("inquery is error: "+ key);
////            return -1;
////        }
//        double d = (Double)theta.get(key);
//        return d;
//    }
//
//    /**
//     * �������Function��ID��F(B,E)�򷵻�BE
//     * @return String
//     */
//    public String getID() {return this.ID;}
//
//    /**
//     * 
//     * @param s
//     * @return
//     */
//    public boolean IDContains(String s)
//    {
//    	boolean tag = false;
//    	String[] ids = this.ID.split(",");
//    	for(int i = 0; i < ids.length; i++)
//    	{
//    		if(ids[i].equals(s))
//    			tag = true;
//    	}
//    	return tag;
//    }
//    public ArrayList<String> getEvidence()
//    {
//        return this.Evidence;
//    }
//    public ArrayList<Integer> getEvalue()
//    {
//        return this.Evalue;
//    }
//
//    /**
//     * ����֤�ݱ���,������֤�ݱ�����ֵ��������
//     * @param s String
//     * @param value int
//     */
//    public void setEvidence(String E, int value)
//    {    
//      
//			this.Evidence.add(E);
//			this.Evalue.add(value);
//
//			//֤�ݱ�����λ��pos
//			int pos = -1;
//			for (int ix = 0; ix < this.ids.length; ix++) {
//				if (this.ids[ix].equals(E))
//                    pos = ix;
//            }
//            Set set = this.theta.keySet();
//            ArrayList<String> removeKey = new ArrayList<String>();
//            Iterator it = set.iterator();
//            while(it.hasNext())
//            {
//                String key = (String)it.next();
//                if(Integer.parseInt(key.substring(pos,pos+1)) != value)
//                {
//                    removeKey.add(key);
//                }
//            }
//            for(int ix = 0; ix < removeKey.size(); ix++)
//            {
//                this.theta.remove(removeKey.get(ix));
//            }
//      
//    }
//    
//   
//    
//    /**
//     * �ж���������ܷ�e���֤��������
//     * FID = "10,32" e = "32" ���� true�� e = "2" ����false
//     * @param e
//     * @return
//     */
//    public boolean evidenced(String e)
//    {
//    	return this.IDContains(e);
//    }
//
//    public static ArrayList indexsOfValue(String str, String value)
//   {
//       ArrayList<Integer> al = new ArrayList<Integer> ();
//       String[] s = str.split(",");
//       for (int ix = 0; ix < s.length; ix++)
//       {
//           if (s[ix].equals(value))
//               al.add(ix);
//       }
//       return al;
//   }
//
//
//    public String toString()
//    {
//        return "Fuction ID="+this.ID+" theta:"+this.theta.toString()+"Evidence:"+this.Evidence.toString()
//                +" Evalue:"+this.Evalue.toString();
//    }
//
//    public static void main(String[] args)
//    {
//    }
//}
//
//
//
