package bjut.ai.sem.multithreads;

import java.util.Arrays;

public class aaa {

	public static double min(double a)
	{
		if(a<=1)
		return a;
		
		else 
			return 1;
	}
	
	public static double max(double a)
	{
		if(a>=0)
		return a;
		
		else 
			return 0;
	}
	
	public static void a() {
		
		double []a ={-0.2,1.3,1.5,-1.2,-0.7};
		double []b ={0.9,2.6,-2.5,0.8,-0.4};
		int size=5;
		double thred =0.5;
		double []c=a;
		Arrays.sort(a); 
		double []d=b;
		Arrays.sort(b); 
		 
		 int maxa=(int)(size*0.9);
		 int mina=(int)(size*0.1);
			
		//  System.out.println(a[maxa]);
		//  System.out.println(a[mina]);
		 double [] aa=new double [5];
		 double [] bb=new double [5];
		 
		 for (int i=0;i<size;i++)
			{		
				aa[i]=max(min((d[i]-b[mina])/(b[maxa]-b[mina])));
			  System.out.println(aa[i]);
			 }
		     //  System.out.println(mina);
			  
		 
	}
	public aaa() {
		// TODO �Զ����ɵĹ��캯�����
	}

	
	public static void main(String[] args) {
		try {
			aaa a=new aaa();
			aaa.a();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
	
}
