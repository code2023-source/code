package bjut.ai.sem.multithreads;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import bjut.ai.bn.AlarmReader;
import bjut.ai.bn.score.K2;

public class EMMIMTtest {
	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		
		int[] datasetnum = { 2000 };
		double[] misspercent = { 0.0, 0.1, 0.2,0.3 };
		int refinenum = 1;
		int iternum = 3;
		int ThreadsNum = 2;
		K2.TYPE type = K2.TYPE.ORI;

		int curdatasetnum = 0;
		double MissPercent = 0.0;
		String loglossDatasetPath = "c:\\Alarmlogloss.txt";

		AlarmReader arlogloss = new AlarmReader(loglossDatasetPath, 10000, 37);
		String[][] loglossData = arlogloss.GetGeNIleDataset();
		ExecutorService exec = Executors.newFixedThreadPool(ThreadsNum);

		for (int i = 0; i < datasetnum.length; i++) {
			curdatasetnum = datasetnum[i];

			for (int j = 0; j < misspercent.length; j++) {
				MissPercent = misspercent[j];

				String basedir = "c:\\EMMI\\";
				String dspath = "c:\\Alarm.txt";
				basedir += (Integer.toString(curdatasetnum) + "_" + Double
						.toString(MissPercent));
				AlarmReader ar = new AlarmReader(dspath, curdatasetnum, 37);
				String[][] data = ar.GetGeNIleDataset();//��������
				EMMIer emmier = new EMMIer(data, loglossData, MissPercent,
						refinenum,
						iternum, type,
						basedir);
				exec.execute(emmier);
			}
		}
		exec.shutdown();
		long end = System.currentTimeMillis();
		System.out.println("time(S):" + (end - start) / 1000);

	}
}
