package bjut.ai.sem.multithreads;

import java.io.PrintWriter;

import smile.Network;
import smile.learning.DataSet;
import bjut.ai.bn.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.converter;
import bjut.ai.bn.learning.acob.multithreads.ACOB;
import bjut.ai.bn.score.K2;
import bjut.ai.sem.EM;
import bjut.ai.sem.EMMI;
import edu.ksu.cis.bnj.bbn.BBNGraph;

public class EMMIer implements Runnable {
	private String[][] data;
	private String[][] loglossData;
	private double misspercent;
	private int refinenum;
	private K2.TYPE acobtype;
	private String basedir;
	private int iternum;
	
	public EMMIer(String[][] data, String[][] loglossData, double missper,
			int refinenum, int iternum,
			K2.TYPE type,
			String basedir) {
		this.data = data;
		this.loglossData = loglossData;
		this.iternum = iternum;
		this.misspercent = missper;
		this.refinenum = refinenum;
		this.acobtype = type;
		this.basedir = basedir;
	}
	@Override
	public void run() {
		System.out.println(this.data.length + " " + this.misspercent);
		PrintWriter log = null;
		log = CommonTools.getPrintWriter(this.basedir, "!EMMIlog.txt");
		log.println(System.getenv("USERDOMAIN"));
		
		EM em = new EM();
		if (misspercent == 0.0) {
			String[][] datanum = converter.tranStringDataToNumData(data);
			K2 k2 = new K2(datanum);
			BBNGraph CurBN = null;
			BNGraph standard = BNGraph.GetGraphStandAlarm();
			BNGraph gk2sn = new BNGraph(K2.VEXNUM);
			log.println("data:" + data.length + " MissPercent:" + misspercent);
			log.println("ACOB type:" + acobtype + " refined num:" + refinenum);

			
			for (int k = 0; k < iternum; k++) {
				ACOB sa = new ACOB(gk2sn, 0.8, 2.0, 0.6, 0.8, 10,
						20, 10, acobtype, k2);
				gk2sn = sa.findBestBayesianNet();// ��������ṹ
				log.print("�Ƚ�ͼ��"
						+ BNGraph.CompareGraph2(standard, gk2sn));
				
				String systemp = System.getenv("TEMP");
				systemp += "\\";
				String tempfname = "missgds" + datanum.length + ".txt";
				String[][] MissDataGds = AlarmReader.tranBjutDS2GDS(datanum);
				AlarmReader.saveGDS(MissDataGds, systemp + tempfname);
				
				// �Ż�����ǰ�ṹ��Thetaֵ,EM�㷨
				Network net = converter.transBjutNetToSmileNet(gk2sn);
				
				DataSet ds = new DataSet();
				ds.readFile(systemp + tempfname);
				ds.matchNetwork(net);
				smile.learning.EM smileEm = new smile.learning.EM();
				smileEm.setRandomizeParameters(true);
				smileEm.learn(ds, net);

				CurBN = converter.tranSmilenetToBNJnet(net);
				double curlogloss = em.calcLogloss(CurBN, loglossData);
				log.append(" logloss:" + curlogloss + "\n");
				CurBN.save(basedir + "\\emalarm" + k + ".xml");
				k2.clearCache();
				// ת�������ֵģ���Ŀ�
			}
		} else {
			String[][] MissData = em.genMissDataSetMCAR(data, misspercent);
			String[][] missnum = converter.tranStringDataToNumData(data);
			AlarmReader.copymiss(MissData, missnum);

			log.println("data:" + MissData.length + " MissPercent:"
					+ misspercent);
			log.println("ACOB type:" + acobtype + " refined num:" + refinenum);
			em.saveDataset(MissData, basedir + "\\Missdata.txt");

			EMMI emmi = new EMMI();
			emmi.setIterNumer(iternum);

			BBNGraph g = emmi.goEMMISmileMT(MissData, missnum, loglossData,
					basedir, acobtype, log, refinenum);
		}
		log.close();
	}
	
}
