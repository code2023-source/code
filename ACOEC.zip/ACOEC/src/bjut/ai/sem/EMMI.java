package bjut.ai.sem;

import java.io.PrintWriter;
import java.util.Hashtable;

import smile.Network;
import smile.learning.DataSet;
import bjut.ai.bn.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.converter;
import bjut.ai.bn.learning.acob.SingleACOB;
import bjut.ai.bn.learning.acob.multithreads.ACOB;
import bjut.ai.bn.score.K2;
import edu.ksu.cis.bnj.bbn.BBNGraph;

public class EMMI {
	private EM em = null;
	private int EMMIIterNum = 10;
	private double StopPercent = -1.0;
	public static PrintWriter log = CommonTools.getPrintWriter("c:\\mytest",
			"log.txt");
	public static PrintWriter timelog = null;
	public static PrintWriter emtimelog = null;
	public static PrintWriter emmilog = null;

	public EMMI()
	{
		em = new EM();
	}
	public void setSeed(long seed)
	{
		this.em.setSeed(seed);
	}

	 public void setIterNumer(int iternum)
	 {
	 this.EMMIIterNum = iternum;
	 }

	/**
	 * ��������logloss��С�����sʱ����
	 */
	public void setStopPercent(double s) {
		this.StopPercent = s;
	}
	

	/**
	 * EM+MI, sample ����
	 * 
	 * @param MissData
	 * @param refinenum
	 * @return
	 */
	public BBNGraph goEMMI(String[][] MissData, String logdir, int refinenum,K2.TYPE type) {
		//��ʼ�����ݣ�������
		String[][] InitData = em.genInitData2(MissData);
		K2 k2 = new K2(InitData);
		BBNGraph CurBN = null;
		BNGraph standard = BNGraph.GetGraphStandAlarm();
		BNGraph gk2sn = new BNGraph(K2.VEXNUM);
		SingleACOB sa = new SingleACOB(gk2sn, 0.8, 2.0, 0.6, 0.8, 10, 100, 10,
				type,k2);
		
		int t = 0;
		try {
			while (t < this.EMMIIterNum) {
				System.out.println("EMMI����������"+t);
				EMMI.emmilog.println("EMMI����������" + t);
				
				long s1 = System.currentTimeMillis();
			//	gk2sn = sa.findBestBayesianNet();//��������ṹ
				
				long e1 = System.currentTimeMillis();
				EMMI.timelog.println("sa.findBestBayesianNet(); " + (e1 - s1));
				EMMI.emmilog.println("�Ƚ�ͼ��"
						+ BNGraph.CompareGraph2(standard, gk2sn));
				long s2 = System.currentTimeMillis();
				CurBN = em.TranBNtoBBN(gk2sn);//ת����bnjͼ
				long e2 = System.currentTimeMillis();
				EMMI.timelog.println("InitBN = em.TranBNtoBBN(gk2sn); "
						+ (e2 - s2));
				
				long s3 = System.currentTimeMillis();
				// �Ż�����ǰ�ṹ��Thetaֵ,EM�㷨
				Hashtable NewTheta = em.goEM(CurBN, MissData, 0.05, 10);
				long e3 = System.currentTimeMillis();
				EMMI.timelog.println("em.goEM" + (e3 - s3));
				long s4 = System.currentTimeMillis();
				em.setThetatoGraph(CurBN, NewTheta);
				long e4 = System.currentTimeMillis();
				EMMI.timelog.println("em.setThetatoGraph " + (e4 - s4));
				
				CurBN.save(logdir+"\\emalarm "+t+".xml");
				
				// refine
				long s5 = System.currentTimeMillis();
				String[][] refinedData = em.MIDataset(CurBN, MissData, refinenum);
				
				refinedData = em.eliminateData(refinedData);
				em.saveDataset(refinedData, logdir+"\\refineData"+t+".txt");
				long e5 = System.currentTimeMillis();
				EMMI.timelog.println("em.MIDataset " + (e5 - s5)
						+ " refinedData.length " + refinedData.length);
				
				EMMI.timelog.println();
				k2.setRecord(refinedData);
				k2.clearCache();
				System.gc();
				t++;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return CurBN;
	}
	
	/**
	 * ��Smile ��EM�㷨
	 * 
	 * @param MissData
	 * @param refinenum
	 * @return
	 */
	public BBNGraph goEMMISmile(String[][] MissData, String[][] MissNum,
			String[][] loglossData,
			String logdir, K2.TYPE type, int refinenum) {
		//��ʼ�����ݣ�������
		String[][] InitData = em.genInitData2(MissNum);
		K2 k2 = new K2(InitData);
		
		BBNGraph CurBN = null;
		BNGraph standard = BNGraph.GetGraphStandAlarm();
		BNGraph gk2sn = new BNGraph(K2.VEXNUM);
		SingleACOB sa = new SingleACOB(gk2sn, 0.8, 2.0, 0.6, 0.8, 10, 100, 10,
				type,k2);
		String systemp = System.getenv("TEMP");	
		systemp += "\\";
		String tempfname = "missgds" + MissData.length + ".txt";
		
		String[][] MissDataGds = AlarmReader.tranBjutDS2GDS(MissData);
		AlarmReader.saveGDS(MissDataGds, systemp + tempfname);
		
		int t = 0;
		double bestlogloss = Double.NEGATIVE_INFINITY;
		double curlogloss  = Double.NEGATIVE_INFINITY;
	
			do{
				System.out.println("EMMI����������"+t);
				EMMI.emmilog.println("EMMI����������" + t);
				
				long s1 = System.currentTimeMillis();
			//	gk2sn = sa.findBestBayesianNet();//��������ṹ
				long e1 = System.currentTimeMillis();
				EMMI.timelog.println("sa.findBestBayesianNet(); " + (e1 - s1));
				EMMI.emmilog.print("�Ƚ�ͼ��"
						+ BNGraph.CompareGraph2(standard, gk2sn));
				
				// �Ż�����ǰ�ṹ��Thetaֵ,EM�㷨
				Network net = converter.transBjutNetToSmileNet(gk2sn);
				// net.writeFile(logdir+"\\beforeem.xdsl");
				DataSet ds = new DataSet();
				ds.readFile(systemp + tempfname);
				ds.matchNetwork(net);
				smile.learning.EM smileEm = new smile.learning.EM();
				smileEm.setRandomizeParameters(true);
				smileEm.setEqSampleSize(500);
				smileEm.learn(ds, net);
				
				net.writeFile(logdir+"\\afterem "+t+".xdsl");
				CurBN = converter.tranSmilenetToBNJnet(net);				
				CurBN.save(logdir+"\\emalarm "+t+".xml");
				curlogloss = em.calcLogloss(CurBN, loglossData);		
				if(curlogloss > bestlogloss)
					bestlogloss = curlogloss;
				EMMI.emmilog.append(" logloss:" + curlogloss + "\n");
				
				// refine
				long s5 = System.currentTimeMillis();
				AlarmReader.saveDataset(MissData, "c:\\tempmissdata.txt");
				String[][] refinedData = em.MIDataset(CurBN, MissData, refinenum);
				
//				String[][] refinedData = em.Sample(CurBN, MissData, 1);
				
				em.saveDataset(refinedData, logdir+"\\refineData"+t+".txt");
				long e5 = System.currentTimeMillis();
				EMMI.timelog.println("em.MIDataset " + (e5 - s5)
						+ " refinedData.length " + refinedData.length);
				
				// ת�������ֵģ���Ŀ�
				String[][] datanum = converter
						.tranStringDataToNumData(refinedData);
				k2.setRecord(datanum);
				k2.clearCache();
				t++;
			} while (t<this.EMMIIterNum);			
		return CurBN;
	}

	/**
	 * ���߳���
	 * 
	 * @param MissData
	 * @param MissNum
	 * @param loglossData
	 * @param logdir
	 * @param type
	 * @param refinenum
	 * @return
	 */
	public BBNGraph goEMMISmileMT(String[][] MissData, String[][] MissNum,
			String[][] loglossData, String logdir, K2.TYPE type,
			PrintWriter log, int refinenum) {
		// ��ʼ�����ݣ�������
		String[][] InitData = em.genInitData2(MissNum);
		K2 k2 = new K2(InitData);

		BBNGraph CurBN = null;
		BNGraph standard = BNGraph.GetGraphStandAlarm();
		BNGraph gk2sn = new BNGraph(K2.VEXNUM);
		ACOB sa = new ACOB(gk2sn, 0.8, 2.0, 0.6, 0.8, 10, 20, 10,
				type, k2);
		String systemp = System.getenv("TEMP");
		systemp += "\\";
		String tempfname = "missgds" + MissData.length + ".txt";

		String[][] MissDataGds = AlarmReader.tranBjutDS2GDS(MissData);
		AlarmReader.saveGDS(MissDataGds, systemp + tempfname);

		int t = 0;
		double bestlogloss = Double.NEGATIVE_INFINITY;
		double curlogloss = Double.NEGATIVE_INFINITY;

		do {
			System.out.println("EMMI����������" + t);
			log.println("EMMI����������" + t);

			long s1 = System.currentTimeMillis();
			gk2sn = sa.findBestBayesianNet();// ��������ṹ
			long e1 = System.currentTimeMillis();
		// log.println("sa.findBestBayesianNet(); " + (e1 - s1));
			log.print("�Ƚ�ͼ��" + BNGraph.CompareGraph2(standard, gk2sn));

			// �Ż�����ǰ�ṹ��Thetaֵ,EM�㷨
			Network net = converter.transBjutNetToSmileNet(gk2sn);
			// net.writeFile(logdir+"\\beforeem.xdsl");
			DataSet ds = new DataSet();
			ds.readFile(systemp + tempfname);
			ds.matchNetwork(net);
			smile.learning.EM smileEm = new smile.learning.EM();
			smileEm.setRandomizeParameters(true);
			smileEm.learn(ds, net);

			net.writeFile(logdir + "\\afterem " + t + ".xdsl");
			CurBN = converter.tranSmilenetToBNJnet(net);
			CurBN.save(logdir + "\\emalarm " + t + ".xml");
			curlogloss = em.calcLogloss(CurBN, loglossData);
			if (curlogloss > bestlogloss)
				bestlogloss = curlogloss;
			log.append(" logloss:" + curlogloss + "\n");

			// refine
			long s5 = System.currentTimeMillis();
			AlarmReader.saveDataset(MissData, "c:\\tempmissdata.txt");
			String[][] refinedData = em.MIDataset(CurBN, MissData, refinenum);

			// String[][] refinedData = em.Sample(CurBN, MissData, 1);

			em.saveDataset(refinedData, logdir + "\\refineData" + t + ".txt");
			long e5 = System.currentTimeMillis();
		// log.println("em.MIDataset " + (e5 - s5)+ " refinedData.length " +
			// refinedData.length);

			// ת�������ֵģ���Ŀ�
			String[][] datanum = converter.tranStringDataToNumData(refinedData);
			k2.setRecord(datanum);
			k2.clearCache();
			t++;
		} while (t < this.EMMIIterNum);
		return CurBN;
	}

	
	/**
	 * ��Smile ��EM�㷨
	 * 
	 * @param MissData
	 * @param refinenum
	 * @return
	 */
	public BBNGraph goEMMISmileEM(String[][] MissData, String[][] MissNum,
			String[][] loglossData, String logdir, K2.TYPE type, int refinenum) {
		// ��ʼ�����ݣ�������
		String[][] InitData = em.genInitData2(MissNum);
		K2 k2 = new K2(InitData);

		BBNGraph CurBN = null;
		BNGraph standard = BNGraph.GetGraphStandAlarm();
		BNGraph gk2sn = new BNGraph(K2.VEXNUM);
		SingleACOB sa = new SingleACOB(gk2sn, 0.8, 2.0, 0.6, 0.8, 10, 100, 10,
				type, k2);

		String[][] MissDataGds = AlarmReader.tranBjutDS2GDS(MissData);
		AlarmReader.saveGDS(MissDataGds, "c:\\EMMI\\MissGDS.txt");

		int t = 0;
		double bestlogloss = Double.NEGATIVE_INFINITY;
		double curlogloss = Double.NEGATIVE_INFINITY;
		try {
			do {
				System.out.println("EMMI����������" + t);
				EMMI.emmilog.println("EMMI����������" + t);

				long s1 = System.currentTimeMillis();
			//	gk2sn = sa.findBestBayesianNet();// ��������ṹ
				long e1 = System.currentTimeMillis();
				EMMI.timelog.println("sa.findBestBayesianNet(); " + (e1 - s1));
				EMMI.emmilog.print("�Ƚ�ͼ��"
						+ BNGraph.CompareGraph2(standard, gk2sn));

				// �Ż�����ǰ�ṹ��Thetaֵ,EM�㷨
				Network net = converter.transBjutNetToSmileNet(gk2sn);
				// net.writeFile(logdir+"\\beforeem.xdsl");
				DataSet ds = new DataSet();
				ds.readFile("c:\\EMMI\\MissGDS.txt");
				ds.matchNetwork(net);
				smile.learning.EM smileEm = new smile.learning.EM();
				smileEm.setRandomizeParameters(true);
				smileEm.learn(ds, net);

				
				net.writeFile(logdir + "\\afterem " + t + ".xdsl");
				CurBN = converter.tranSmilenetToBNJnet(net);
				CurBN.save(logdir + "\\emalarm " + t + ".xml");
				curlogloss = em.calcLogloss(CurBN, loglossData);
				EMMI.emmilog.append(" logloss:" + curlogloss + "\n");

				// refine
				long s5 = System.currentTimeMillis();
				AlarmReader.saveDataset(MissData, "c:\\tempmissdata.txt");
				String[][] refinedData = em.MISmile(net, MissNum, ds, 1);
				
				AlarmReader.saveDataset(MissNum, logdir+"missnum.txt");
				// String[][] refinedData = em.Sample(CurBN, MissData, 1);

				em.saveDataset(refinedData, logdir + "\\refineData" + t
						+ ".txt");
				long e5 = System.currentTimeMillis();
				EMMI.timelog.println("em.MIDataset " + (e5 - s5)
						+ " refinedData.length " + refinedData.length);

				// ת�������ֵģ���Ŀ�
				String[][] datanum = converter
						.tranStringDataToNumData(refinedData);
				k2.setRecord(refinedData);
				k2.clearCache();
				t++;
			} while (t < this.EMMIIterNum);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return CurBN;
	}

	
	
	/**
	 * ����bnj��
	 * 
	 * @param missds
	 * @param logdir
	 * @param refinenum
	 * @return
	 */
	public Network goEMMISmile2(DataSet missds, String[][] missbjut, String logdir, K2.TYPE type,
			int refinenum) {
		// ��ʼ�����ݣ�������
		String[][] InitData = em.genInitData2(missbjut);
		
		K2 k2 = new K2(InitData);
		Network net = new Network();
		BNGraph standard = BNGraph.GetGraphStandAlarm();
		BNGraph gk2sn = new BNGraph(K2.VEXNUM);
		SingleACOB sa = new SingleACOB(gk2sn, 0.8, 2.0, 0.6, 0.8, 10, 100, 10,
				type, k2);

		int t = 0;
		try {
			while (t < this.EMMIIterNum) {
				System.out.println("EMMI����������" + t);
				EMMI.emmilog.println("EMMI����������" + t);

				long s1 = System.currentTimeMillis();
		//		gk2sn = sa.findBestBayesianNet();// ��������ṹ
				long e1 = System.currentTimeMillis();
				EMMI.timelog.println("sa.findBestBayesianNet(); " + (e1 - s1));
				EMMI.emmilog.println("�Ƚ�ͼ��"
						+ BNGraph.CompareGraph2(standard, gk2sn));

				// �Ż�����ǰ�ṹ��Thetaֵ,EM�㷨
				net = converter.transBjutNetToSmileNet(gk2sn);
				
				// net.writeFile(logdir+"\\beforeem.xdsl");
				missds.matchNetwork(net);
				smile.learning.EM smileEm = new smile.learning.EM();
				smileEm.setRandomizeParameters(true);
				System.out.println("Smile EM start...");
				smileEm.learn(missds, net);

				// refine
				long s5 = System.currentTimeMillis();
				System.out.println("refine start...");

				net.writeFile("c:\\temp.xdsl");
				AlarmReader.saveDataset(missbjut, "c:\\temp.txt");
				String[][] refinedData = em.MISmile2(net, missbjut, missds,
						1);

				em.saveDataset(refinedData, logdir + "\\refineData" + t
						+ ".txt");
				long e5 = System.currentTimeMillis();
				EMMI.timelog.println("em.MIDataset " + (e5 - s5)
						+ " refinedData.length " + refinedData.length);
				EMMI.timelog.println();
				
				k2.setRecord(refinedData);
				k2.clearCache();
				t++;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return net;
	}

	

	public static void main(String[] args) throws Exception
	{
		long start = System.currentTimeMillis();
		// EMMIһ��ʵ��


		int[] datasetnum = { 2000 };
		double[] misspercent = {0.1 };
		int refinenum = 2;
		K2.TYPE type = K2.TYPE.ORI;
		
		int curdatasetnum = 0;
		double MissPercent = 0.0;		
		String loglossDatasetPath = "c:\\Alarmlogloss.txt";

		AlarmReader arlogloss = new AlarmReader(loglossDatasetPath, 10000, 37);
		String[][] loglossData = arlogloss.GetGeNIleDataset();
		
		
		for (int i = 0; i < datasetnum.length; i++) {
			curdatasetnum = datasetnum[i];

			for (int j = 0; j < misspercent.length; j++) {
				MissPercent = misspercent[j];

				String basedir = "c:\\EMMI\\";
				basedir += (Integer.toString(curdatasetnum) + "_" + Double
						.toString(MissPercent));

				timelog = CommonTools.getPrintWriter(basedir, "timelog.txt");
				emtimelog = CommonTools
						.getPrintWriter(basedir, "emtimelog.txt");
				emmilog = CommonTools.getPrintWriter(basedir, "!EMMIlog.txt");
				
				long s = System.currentTimeMillis();
				EM em = new EM();
				String dspath = "c:\\Alarm.txt";
				AlarmReader ar = new AlarmReader(dspath,
						curdatasetnum, 37);
				String[][] data = ar.GetGeNIleDataset();
			
				
				if (MissPercent == 0.0) {
					EMMI.emmilog.println(System.getenv("USERDOMAIN"));
					EMMI.emmilog.println("data:" + data.length
							+ " MissPercent:" + MissPercent);
					EMMI.emmilog.println("ACOB type:"+type+" refined num:"+refinenum);
					String[][] datanum = converter
							.tranStringDataToNumData(data);
					
					K2 k2 = new K2(datanum);
					BBNGraph CurBN = null;
					BNGraph standard = BNGraph.GetGraphStandAlarm();
					BNGraph gk2sn = new BNGraph(K2.VEXNUM);
					
					
					int iternum = 10;
					for(int k = 0; k < iternum; k++){
						SingleACOB sa = new SingleACOB(gk2sn, 0.8, 2.0, 0.6, 0.8,
							10, 100, 10, type, k2);
			//			gk2sn = sa.findBestBayesianNet();// ��������ṹ
						EMMI.emmilog.println("�Ƚ�ͼ��"
								+ BNGraph.CompareGraph2(standard, gk2sn));
					
						// �Ż�����ǰ�ṹ��Thetaֵ,EM�㷨
	
						Network net = converter.transBjutNetToSmileNet(gk2sn);
						DataSet ds = new DataSet();
						ds.readFile(dspath);
						ds.matchNetwork(net);
						smile.learning.EM smileEm = new smile.learning.EM();
						smileEm.setRandomizeParameters(true);
						smileEm.learn(ds, net);
						
						CurBN = converter.tranSmilenetToBNJnet(net);	
						double curlogloss = em.calcLogloss(CurBN, loglossData);		
						EMMI.emmilog.append(" logloss:" + curlogloss + "\n");
						CurBN.save(basedir+"\\emalarm"+k+".xml");

//						k2.clearCache();

											
						// ת�������ֵģ���Ŀ�
					}
					
				} else {
					String[][] MissData = em.genMissDataSetMCAR(data,
							MissPercent);
					String[][] missnum = converter
							.tranStringDataToNumData(data);
					AlarmReader.copymiss(MissData, missnum);

					EMMI.emmilog.println(System.getenv("USERDOMAIN"));
					EMMI.emmilog.println("data:" + data.length
							+ " MissPercent:" + MissPercent);
					EMMI.emmilog.println("ACOB type:"+type+" refined num:"+refinenum);
					em.saveDataset(MissData, basedir + "\\Missdata.txt");
					
					EMMI emmi = new EMMI();
					 emmi.setIterNumer(10);
//					emmi.setStopPercent(0.5);

//					BBNGraph g = emmi.goEMMISmile(MissData, missnum,
//							loglossData, basedir,type,
//							refinenum);

					BBNGraph g = emmi.goEMMI(MissData, basedir, refinenum,type);
					
					long e = System.currentTimeMillis();

					EMMI.emmilog.println("total time:" + (e - s) / 1000);
					EMMI.emtimelog.close();
					EMMI.timelog.close();
					EMMI.emmilog.close();
				}
			}
		}
		long end = System.currentTimeMillis();
		System.out.println("time(S):" + (end - start) / 1000);

		}
	
}
