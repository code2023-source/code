package bjut.ai.sem;

import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Random;

import smile.Network;
import smile.learning.DataSet;
import bjut.ai.bn.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.converter;
import bjut.ai.bn.learning.acob.SingleACOB;
import bjut.ai.bn.score.K2;
import edu.ksu.cis.bnj.bbn.BBNGraph;

public class EMMISmile {
	 public static EMMISmile smile1 = new EMMISmile();

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		// EMMIһ��ʵ��

		int[] datasetnum = { 1000 };
		double[] misspercent = { 0.1 };
		int refinenum = 1;
		K2.TYPE type = K2.TYPE.ORI;
		
		int curdatasetnum = 0;
		double MissPercent = 0.0;		
		String loglossDatasetPath = "c:\\Alarmlogloss.txt";

		AlarmReader arlogloss = new AlarmReader(loglossDatasetPath, 10000, 37);
		String[][] loglossData = arlogloss.GetGeNIleDataset();
		
		
		for (int i = 0; i < datasetnum.length; i++) {
			curdatasetnum = datasetnum[i];

			for (int j = 0; j < misspercent.length; j++) {
				MissPercent = misspercent[j];

				String basedir = "c:\\EMMI\\";
				basedir += (Integer.toString(curdatasetnum) + "_" + Double
						.toString(MissPercent));

				EMMI.timelog = CommonTools.getPrintWriter(basedir, "timelog.txt");
				EMMI.emtimelog = CommonTools
						.getPrintWriter(basedir, "emtimelog.txt");
				EMMI.emmilog = CommonTools.getPrintWriter(basedir, "!EMMIlog.txt");
				
				long s = System.currentTimeMillis();
				EM em = new EM();
				String dspath = "c:\\Alarm.txt";
				AlarmReader ar = new AlarmReader(dspath,
						curdatasetnum, 37);
				String[][] data = ar.GetGeNIleDataset();
			
				
				if (MissPercent == 0.0) {
					EMMI.emmilog.println(System.getenv("USERDOMAIN"));
					EMMI.emmilog.println("data:" + data.length
							+ " MissPercent:" + MissPercent);
					EMMI.emmilog.println("ACOB type:"+type+" refined num:"+refinenum);
					String[][] datanum = converter
							.tranStringDataToNumData(data);
					
					K2 k2 = new K2(datanum);
					BBNGraph CurBN = null;
					BNGraph standard = BNGraph.GetGraphStandAlarm();
					BNGraph gk2sn = new BNGraph(K2.VEXNUM);
					
					
					int iternum = 10;
					for(int k = 0; k < iternum; k++){
						SingleACOB sa = new SingleACOB(gk2sn, 0.8, 2.0, 0.6, 0.8,
							10, 100, 10, type, k2);
		//				gk2sn = sa.findBestBayesianNet();// ��������ṹ
						EMMI.emmilog.println("�Ƚ�ͼ��"
								+ BNGraph.CompareGraph2(standard, gk2sn));
					
						// �Ż�����ǰ�ṹ��Thetaֵ,EM�㷨
	
						Network net = converter.transBjutNetToSmileNet(gk2sn);
						DataSet ds = new DataSet();
						ds.readFile(dspath);
						ds.matchNetwork(net);
						smile.learning.EM smileEm = new smile.learning.EM();
						smileEm.setRandomizeParameters(true);
						smileEm.learn(ds, net);
						
						CurBN = converter.tranSmilenetToBNJnet(net);	
						double curlogloss = em.calcLogloss(CurBN, loglossData);		
						EMMI.emmilog.append(" logloss:" + curlogloss + "\n");
						CurBN.save(basedir+"\\emalarm"+k+".xml");
						k2.clearCache();
											
						// ת�������ֵģ���Ŀ�
					}
					
				} else {
					String[][] MissData = em.genMissDataSetMCAR(data,
							MissPercent);
					String[][] temp = AlarmReader.tranBjutDS2GDS(MissData);
					AlarmReader.saveGDS(temp, basedir + "missgds.txt");
					DataSet missds = new DataSet();
					missds.readFile(basedir + "missgds.txt");
					
					EMMI.emmilog.println(System.getenv("USERDOMAIN"));
					EMMI.emmilog.println("data:" + data.length
							+ " MissPercent:" + MissPercent);
					EMMI.emmilog.println("ACOB type:"+type+" refined num:"+refinenum);
					em.saveDataset(MissData, basedir + "\\Missdata.txt");
					
					EMMI emmi = new EMMI();
					emmi.setIterNumer(10);
//					emmi.setStopPercent(0.5);

					Network g = emmi.goEMMISmile2(missds, MissData,basedir, type,
							refinenum);
					
					long e = System.currentTimeMillis();

					EMMI.emmilog.println("total time:" + (e - s) / 1000);
					EMMI.emtimelog.close();
					EMMI.timelog.close();
					EMMI.emmilog.close();
				}
			}
		}
		long end = System.currentTimeMillis();
		System.out.println("time(S):" + (end - start) / 1000);

		}

	public BBNGraph goEMMISmile(String OriginDatasetFname) throws Exception
	{
		//
		String basepath = "c:\\EMMISmile\\";
		String tempnet = basepath + "temp.net";
		String type = "dsl";
		

		int DATANUM = 3000;
		int VARNUM = 37;
		int MAXITER = 10;// ����������
		double MISSPER = 0.2;

		bjut.ai.sem.EM emBjut = new bjut.ai.sem.EM();
		smile.learning.EM emSmile = new smile.learning.EM();
		PrintWriter log = CommonTools.getPrintWriter(basepath, "log.txt");

		String[][] OriginDataset = AlarmReader.getGDS(OriginDatasetFname,
				DATANUM);
		String[][] bjutds = AlarmReader.tranGDS2BjutDS(OriginDataset);
		String[][] MissBjutds = AlarmReader.genMissDataSetMCAR(bjutds,
				MISSPER);
		
		String MissDataFName = basepath + "missdata" + MISSPER + ".txt";
		String[][] MissGds = AlarmReader.tranBjutDS2GDS(MissBjutds);
		
		String[][] MissBjutString = AlarmReader.getBJUTDS(
				"data\\alarmstring.txt", DATANUM);
		AlarmReader.copymiss(MissBjutds, MissBjutString);
		AlarmReader.saveGDS(MissGds, MissDataFName);

		DataSet missdata = new DataSet();// Smile EM����ѧϰʹ��
		missdata.readFile(MissDataFName);
		
		
		// �����ṹѧϰ
		
		String[][] RandInitData = emBjut.genInitData2(MissBjutds);
				         
		K2 k2 = new K2(RandInitData);
		BBNGraph CurBN = null;
		BNGraph gk2sn = new BNGraph(K2.VEXNUM);
		BNGraph standard = BNGraph.GetGraphStandAlarm();
		SingleACOB sa = new SingleACOB(gk2sn, 0.8, 2.0, 0.6, 0.8, 10, 100, 10,
				K2.TYPE.ORI, k2);
		
		// ��ʼ������ṹ
	//	gk2sn = sa.findBestBayesianNet();
		log.println(BNGraph.CompareGraph2(standard, gk2sn));
		
		//
	
		Network smilenet = new Network();
		this.transBjutNetToSmileNet(gk2sn, smilenet);
		
		for (int i = 0; i < MAXITER; i++) {
			missdata.matchNetwork(smilenet);
			emSmile.setEqSampleSize(60000);
			emSmile.learn(missdata, smilenet);
			smilenet.writeFile(tempnet);
		
			CurBN = BBNGraph.load(tempnet);
			CurBN.save(basepath + "tempbbn.dsl", type);
	
			// String[][] refinedData = emBjut.MIDataset(CurBN, MissDataNum, 1);
			String[][] refinedData = emBjut.Sample(CurBN, MissBjutString, 1);
			String[][] refinedDataNum = converter
					.tranStringDataToNumData(refinedData);
			
			AlarmReader.saveDataset(refinedDataNum, basepath + "refineddata"
					+ i + ".txt");
			k2.setRecord(refinedDataNum);
			k2.clearCache();
	//		gk2sn = sa.findBestBayesianNet();
			// log.println("��¼�ṹ" + gk2sn);
			log.println(BNGraph.CompareGraph2(standard, gk2sn));
			smilenet = new Network();
			this.transBjutNetToSmileNet(gk2sn, smilenet);
		}
		log.close();
		return CurBN;
	}

	
	
	/**
	 * ������
	 * 
	 * @param bjut
	 * @param net
	 */
	public void transBjutNetToSmileNet(BNGraph bjut, Network net) {
		Network ssmile = new Network();
		ssmile.readFile("data\\Alarm.xdsl");
		String[] names = ssmile.getAllNodeIds();
		// add node
		for (int i = 0; i < names.length; i++) {
			net.addNode(Network.NodeType.Cpt, names[i]);
		}
		// net.writeFile("c:\\tran001.xdsl");
		names = net.getAllNodeIds();
		// add each node's outcomes
		for (int i = 0; i < names.length; i++) {
			String CurNodeName = names[i];
			String[] ids = ssmile.getOutcomeIds(CurNodeName);
		
			for (int j = 0; j < ids.length; j++) {
				net.addOutcome(CurNodeName, ids[j]);
			}
		}
		
		for (int i = 0; i < names.length; i++) {
			for (int m = 0; m < 2; m++) {
				net.deleteOutcome(names[i], 0);
			}
		}
		// net.writeFile("c:\\tran002.xdsl");

		int[][] edges = bjut.GetArcArray();
		for (int i = 0; i < edges.length; i++) {
			for (int j = 0; j < edges[0].length; j++) {
				if (edges[i][j] == 1) {
					String from = AlarmReader.index2nodeName
							.get(i + 1);
					String to = AlarmReader.index2nodeName.get(j + 1);
					net.addArc(from, to);
				}
			}
		}
		// net.writeFile("c:\\tran003.xdsl");
		// cpt not set!
		
	}
	
	/**
	 * ������ �����ʼ��dataset
	 * 
	 * @param missdata
	 */
	public void randinit(String[][] missdata) {
		// bjut���ݼ���˳��
		int[] AlarmNodeDef = { 3, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 2, 4, 4, 4, 3,
				2, 2, 2, 2, 2, 3, 2, 2, 3, 3, 2, 2, 3, 2, 2, 3, 3, 4, 4, 4, 4 };
		
		int[] order = { 18, 21, 22, 23, 15, 36, 35, 34, 33, 32, 3, 16, 17, 25,
				19, 20, 30, 11, 31, 10, 26, 28, 5, 4, 24, 0, 29, 27, 13, 6, 7,
				8, 2, 14, 9, 1, 12 };

		Random r = new Random();
		for (int i = 0; i < missdata.length; i++) {
			for (int j = 0; j < missdata[0].length; j++) {
				if (missdata[i][j].equals("-1")) {
					missdata[i][j] = Integer.toString(r
							.nextInt(AlarmNodeDef[order[j]]));
				}
			}
		}
	}
	public static void testRandinit() {
		DataSet ds = new DataSet();
		ds.readFile("c:\\Alarmmiss.txt");
		String[][] dataset = converter.tranSmiledataToBjutdata(ds);
		EMMISmile.smile1.randinit(dataset);
		K2 k2 = new K2(dataset);
		double score = k2.calcGraphScore(BNGraph.GetGraphStandAlarm());
		System.out.println(score);
		

	}
	public static void testGoEMMI() {
		AlarmReader ar = new AlarmReader("c:\\Missdata.txt", 3000, 37);
		String[][] dataset = ar.GetDataSet();
		EM em = new EM();
		String[][] complete = em.genInitData(dataset);
		K2 k001 = new K2(dataset);
		K2 k002 = new K2(complete);

		double score1 = k001.calcGraphScore(BNGraph.GetGraphStandAlarm());
		double score2 = k002.calcGraphScore(BNGraph.GetGraphStandAlarm());

		System.out.println(score1);
		System.out.println(score2);

	}
	
	
	

}
