/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



/*
 * Created on Mar 20, 2003
 *
 */
package edu.ksu.cis.bnj.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;

import edu.ksu.cis.kdd.data.Attribute;
import edu.ksu.cis.kdd.data.Database;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.data.Tuple;
import edu.ksu.cis.kdd.data.converter.Converter;
import edu.ksu.cis.kdd.util.Parameter;
import edu.ksu.cis.kdd.util.ParameterTable;

/**
 * <P>Tuple converter for an <B>extremely weird</b> format for MRBN.
 * Should be avoided like plague. DON'T USE THIS UNLESS YOU KNOW WHAT
 * YOU'RE DOING!!!!
 * 
 * @author Roby Joehanes
 */
public class DataShiatsu implements Converter {

    public static final int defaultThreshold = 3000;
    public static final double increaseRatio = 2;
    public static final double decreaseRatio = 1.0/2.0;

    protected int threshold = defaultThreshold;

	/**
	 * @see edu.ksu.cis.kdd.data.converter.Converter#initialize()
	 */
	@Override
	public void initialize() {
	}

	/**
	 * @see edu.ksu.cis.kdd.data.converter.Converter#load(java.io.InputStream)
	 */
	@Override
	public Database load(InputStream stream) {
        try {
            LineNumberReader r = new LineNumberReader(new InputStreamReader(stream));
            String s;
            Hashtable attrTable = new Hashtable();
            Hashtable valueCache = new Hashtable();
            Hashtable tupleData = new Hashtable();
            do {
                s = r.readLine();
                if (s == null) break;
                StringTokenizer tok = new StringTokenizer(s);
                String attrName = tok.nextToken();
                String tupleID = tok.nextToken();
                String attrValue = tok.nextToken();

                Attribute attr = (Attribute) attrTable.get(attrName);
                Set values = (Set) valueCache.get(attrName);
                if (attr == null) {
                    attr = new Attribute(attrName);
                    attrTable.put(attrName, attr);
                } 
                if (values == null) {
                    values = new HashSet();
                    valueCache.put(attrName,values);
                }

                Integer val;
                try {
                    val = new Integer(attrValue);
                } catch (Exception ee) {
                    // So, this is where the painful biological expression data should be normalized
                    // If it still fails, too bad... 
                    double d = Double.parseDouble(attrValue);
                    if (d >= increaseRatio) {
                        val = new Integer(1);
                    } else if (d <= decreaseRatio) {
                        val = new Integer(-1); 
                    } else {
                        val = new Integer(0);
                    }
                }

                values.add(val);

                Hashtable tupleTable = (Hashtable) tupleData.get(tupleID);
                if (tupleTable == null) {
                    tupleTable = new Hashtable();
                    tupleData.put(tupleID, tupleTable);
                }
                tupleTable.put(attrName, val);
            } while (true);
            r.close();

            // Alright, now we already got 'em all
            // Weeding out
            if (threshold > 0) {
                for (Enumeration e = tupleData.keys(); e.hasMoreElements(); ) {
                    Object keys = e.nextElement();
                    Hashtable tbl = (Hashtable) tupleData.get(keys);
                    if (tbl.size() < threshold) {
                        tupleData.remove(keys);
                    }
                }
            }

            //System.out.println(tupleData.size()+" data points");

            // Extract common attribute values;
            HashSet set = null;
            for (Enumeration e = tupleData.keys(); e.hasMoreElements(); ) {
                Object keys = e.nextElement();
                Hashtable tbl = (Hashtable) tupleData.get(keys);
                if (set == null) {
                    set = new HashSet();
                    set.addAll(tbl.keySet());
                } else {
                    set.retainAll(tbl.keySet());
                    //System.out.println("Entry set is: "+set);
                    if (set.size() == 0) break;
                }
            }

            if (set.size() == 0) {
                throw new RuntimeException("Error! No common attributes between tuples!");
            }

            // Post-processing
            Table tuples = new Table();
            tuples.setName("untitled_mrbn");

            int max = set.size();
            int index = 0;
            String[] attrNames = new String[max];
            //System.out.println("Chosen attributes are:");
            for (Iterator i = set.iterator(); i.hasNext(); index++) {
                String attrName = (String) i.next();
                Attribute attr = (Attribute) attrTable.get(attrName);
                attrNames[index] = attrName;
                //System.out.println(attrName);
                Set values = (Set) valueCache.get(attrName);
                attr.addValues(values);
                tuples.addAttribute(attr);
            }
            System.out.println(index+" attributes");
            System.out.println(tupleData.size()+" data points");

            for (Enumeration e = tupleData.keys(); e.hasMoreElements(); ) {
                Object keys = e.nextElement();
                Hashtable tbl = (Hashtable) tupleData.get(keys);
                Tuple t = new Tuple();
                for (index = 0; index < max; index++) {
                    Object value = tbl.get(attrNames[index]);
                    t.addValue(value);
                }
                tuples.addTuple(t);
            }
            Database db = new Database();
            db.addTable(tuples);
            return db;

        } catch(Exception e) {
            throw new RuntimeException(e);
        }
	}

	/**
	 * @see edu.ksu.cis.kdd.data.converter.Converter#save(java.io.OutputStream, edu.ksu.cis.kdd.data.datastructure.Table)
	 */
	@Override
	public void save(OutputStream stream, Database db) {
        String ln = System.getProperty("line.separator"); // $NON-NLS-1$
        Writer w = new OutputStreamWriter(stream);
        try {
            Table t = db.pickOneTable();
            Attribute[] attrs = (Attribute[]) t.getAttributes().toArray(new Attribute[0]);
            int tupleno = 1;
            for (Iterator i = t.getTuples().iterator(); i.hasNext(); tupleno++) {
                Tuple tuple = (Tuple) i.next();
                int index = 0;
                for (Iterator j = tuple.getValues().iterator(); j.hasNext(); index++) {
                    Object val = j.next();
                    w.write(attrs[index]+"\tt"+tupleno+"\t"+attrs[index].getValueIndex(val)+"\ttuple_"+tupleno+ln); // $NON-NLS-1$ // $NON-NLS-2$
                }
            }
            w.flush();
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
	}

    public static void main(String[] args) {
        ParameterTable params = Parameter.process(args);
        String inputFile = params.getString("-i"); //$NON-NLS-1$
        String outputFormat = params.getString("-f"); //$NON-NLS-1$
        String outputFile = params.getString("-o"); //$NON-NLS-1$
        boolean quiet = params.getBool("-q"); //$NON-NLS-1$
        int threshold = params.getInt("-t", defaultThreshold); //$NON-NLS-1$

        if (inputFile == null) {
            System.out.println("Usage: edu.ksu.cis.bnj.test.DataShiatsu -i:inputfile [-o:outputfile] [-f:saveformat] [-t:datathreshold] [-q]");
            System.out.println("-f: default=arff. Acceptable values are {arff, xml, csf, dat}");
            System.out.println("-q: quiet mode");
            System.out.println("-t: data threshold (i.e. if it contains less than the specified value, it is excluded). Default: "+defaultThreshold);
            System.out.println("If outputfile is not specified, it will default to the standard output.");
            return;
        }


        OutputStream out = System.out;

        if (outputFile != null) {
            try {
                out = new FileOutputStream(outputFile);
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }

        DataShiatsu d = new DataShiatsu();
        d.threshold = threshold;
        Runtime r = Runtime.getRuntime();
        long freemem = r.freeMemory();
        Database t = null;
        try {
            t = Database.load(inputFile);
            freemem = freemem - r.freeMemory();
        } catch (Exception e) {
            try {
                t = d.load(new FileInputStream(inputFile));
            } catch (Exception ee) {
                ee.printStackTrace();
                System.exit(-1);
            }
        }

        if (!quiet) {
            System.out.println("Memory needed = "+freemem);
        }

        if (t != null)
        {
            if (outputFormat == null) outputFormat = Table.ARFF_FORMAT;
            try {
                if (outputFormat.equals("mrbn")) {
                    d.save(out, t);
                } else {
                    t.save(out, outputFormat);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
