/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */




package edu.ksu.cis.bnj.bbn.inference.ls;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.kdd.util.graph.Edge;

/**
 * @author Roby Joehanes
 */
public class CliqueTree extends BBNGraph {

    protected BBNGraph owner;

    public CliqueTree(BBNGraph g) {
        owner = g;
        Hashtable nodeCache = new Hashtable();
        edu.ksu.cis.kdd.util.graph.CliqueTree
            tree = new edu.ksu.cis.kdd.util.graph.CliqueTree(g);  // most unfortunate naming...
        Set evNodes = g.getEvidenceNodes();

        // Add the nodes
        for (Iterator i = tree.getOrderedCliques().iterator(); i.hasNext(); ) {
            edu.ksu.cis.kdd.util.graph.Clique
                clique = (edu.ksu.cis.kdd.util.graph.Clique) i.next();

            Clique clq = new Clique(clique);
            addNode(clq);
            clq.filterEvidenceNodes(evNodes);
            nodeCache.put(clique.toString(), clq);
        }

        // Add the edges
        for (Iterator i = tree.getEdges().iterator(); i.hasNext(); ) {
            Edge edge = (Edge) i.next();
            Clique src = (Clique) nodeCache.get(edge.getSource().toString());
            Clique dest = (Clique) nodeCache.get(edge.getDestination().toString());
            addEdge(src, dest);
        }

    }
}
