/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.bnj.bbn.learning.scorebased.wrappers.gawk;



import edu.ksu.cis.kdd.ga.Chromosome;
import edu.ksu.cis.kdd.util.Settings;

/**
 * GAWK = Genetic Algorithm Wrapper for K2
 * 
 * @author Roby Joehanes
 * @author William H. Hsu
 * Last updated Fri 18 Apr 2003
 */
class GAWKChrom extends Chromosome {

	/**
	 * @param size
	 */
	public GAWKChrom(int size) {
		super(size);
        object = new Object[size];

        for (int i = 0; i < size; i++)
            object[i] = new Integer(i);

        // shuffle
        Object temp;
        int max = Settings.random.nextInt(size);
        for (int i = 0; i < max; i++) {
            int pos1 = Settings.random.nextInt(size);
            int pos2 = Settings.random.nextInt(size);
            temp = object[pos1];
            object[pos1] = object[pos2];
            object[pos2] = temp;
        }
	}

	/**
	 * @param perm, size
	 * constructor that takes a specified permutation - WHH 18 Apr 2003
	 */
	public GAWKChrom(int perm[], int size) {
		super(size);
		object = new Object[size];

		for (int i = 0; i < size; i++)
			object[i] = new Integer(perm[i]);
	}

	/**
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Object clone() {
        GAWKChrom c = new GAWKChrom(size);
        c.object = new Object[size];
        System.arraycopy(object,0,c.object,0,size);
		return c;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object other) {
        if (!(other instanceof GAWKChrom)) return false;
        GAWKChrom c = (GAWKChrom) other;
        if (c.size != size) return false;
        for (int i = 0; i < size; i++) {
            if (object[i].equals(c.object[i])) return false;
        }

		return true;
	}

	/**
	 * @see edu.ksu.cis.kdd.ga.Chromosome#createObject()
	 */
	@Override
	public Chromosome createObject() {
		return new GAWKChrom(size);
	}

    @Override
	public String toString() {
        StringBuffer buf = new StringBuffer("[");
        for (int i = 0; i < size; i++) {
            buf.append(object[i]+" ");
        }
        return buf.toString().trim()+"]";
    }

}
