/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */





package edu.ksu.cis.bnj.bbn.inference.cutset;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import edu.ksu.cis.bnj.bbn.BBNDiscreteValue;
import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.BBNNode;
import edu.ksu.cis.bnj.bbn.inference.InferenceResult;
import edu.ksu.cis.bnj.bbn.inference.ls.LS;
import edu.ksu.cis.bnj.bbn.inference.pearl.Pearl;
import edu.ksu.cis.kdd.util.Parameter;
import edu.ksu.cis.kdd.util.ParameterTable;

/**
 * @author Siddarth Chandak
 */
public class PresortedCutset
{
    
	BBNGraph network;
	LinkedList cutsetNodes;
	Hashtable nodeTable;
	Hashtable cutsetTable;
	Hashtable bnTable;
	Pearl pearlObject;
	Hashtable baseInfoTable;
	List topologicalOrder;
	Hashtable oldIndexTable;
	///////////////////////////
	AISBCC bridge;
	//////////////////////////
	protected double cutoffPercentage = 0.5;
	protected int maxInstantiationIndex = 0;

	protected Object lock = new Object();
	int numSamples = 1000;
	boolean runAIS = false;			// naive
	boolean runAISJoint = false;	// joint
	
	public PresortedCutset(){}
	public PresortedCutset(BBNGraph g) 
	{
		network = g;
        
		CreateSplittingGraph graph = new CreateSplittingGraph(g);       
		cutsetNodes =  graph.go();
		nodeTable = graph.getNodetable();
		cutsetTable = graph.getCutsetTable();                   
		bnTable = new Hashtable();
		baseInfoTable = new Hashtable();
		oldIndexTable = new Hashtable(); 
		pearlObject = new Pearl();
		topologicalOrder = network.topologicalSort();
        
	}
    
	public void tempTest()
	{
		cutsetTable.clear();
		cutsetNodes.clear();
		//cutsetTable.put("TbOrCa",nodeTable.get("TbOrCa"));
		//cutsetNodes.add(nodeTable.get("TbOrCa"));
		cutsetTable.put("Cancer",nodeTable.get("Cancer"));
		cutsetTable.put("Bronchitis",nodeTable.get("Bronchitis"));      
		cutsetNodes.add(nodeTable.get("Cancer"));
		cutsetNodes.add(nodeTable.get("Bronchitis"));
		//System.out.println(cutsetTable.toString());
	}
    
/*  protected void m() {
		HashSet cutsetDescendants = new HashSet();
		HashSet allNodes = new HashSet();
		allNodes.addAll(network.getNodes());
		for (Iterator i = cutsetNodes.iterator(); i.hasNext(); ) {
			BBNNode node = (BBNNode) i.next();
			cutsetDescendants.addAll(node.getDescendants());
		}
		allNodes.removeAll(cutsetDescendants);
	}
*/
protected Set getUniqueInstantiation1(LinkedList nodes, Hashtable curInst, HashSet set,Hashtable ipd,double qval) 
	{
		BBNNode node = (BBNNode) nodes.removeFirst();
		for (Iterator i = ((BBNDiscreteValue) node.getValues()).iterator(); i.hasNext(); ) 
		{
			String value = (String) i.next();
			//////////////////////////////////
			curInst.put(node.getName(), value);
			Hashtable priorsTable = new Hashtable(1);
			priorsTable.put(node.getName(), value);
			double prior_val= node.query(priorsTable);
			prior_val *= qval; 
			if (nodes.size() == 0) {
				ipd.put(curInst.clone(),new Double(prior_val));
				//System.out.println(ipd.toString());
				set.add(curInst.clone());
			} else {
				getUniqueInstantiation1(nodes, curInst, set,ipd,prior_val);
			}
		}
		nodes.addFirst(node);
		return set;
	}

	protected Set getUniqueInstantiation(LinkedList nodes, Hashtable curInst, HashSet set) 
	{
		BBNNode node = (BBNNode) nodes.removeFirst();
		for (Iterator i = ((BBNDiscreteValue) node.getValues()).iterator(); i.hasNext(); ) 
		{
			String value = (String) i.next();
			//////////////////////////////////
			curInst.put(node.getName(), value);
			if (nodes.size() == 0) {
				set.add(curInst.clone());
			} else {
				getUniqueInstantiation(nodes, curInst, set);
			}
		}
		nodes.addFirst(node);
		return set;
	}


	/**
	 * Updates cutsetNodes, nodeTable == name->BBNNode,  nodesWithPredecessors == name->BBNNode
	 */
	public void getNodesWithoutLoopCutsetPredecessors()
	{
		Iterator cutsetIterator;
		Hashtable nodesWithPredecessors = new Hashtable();
		cutsetNodes = orderCutsetNodes();
		for(cutsetIterator = cutsetNodes.iterator();cutsetIterator.hasNext();)
		{
			BBNNode cutset = (BBNNode) cutsetIterator.next();
			List order = network.topologicalSort(cutset);
			Iterator listIterator = order.iterator();
			if(listIterator.hasNext())            /// since we dont need the current cutset nodes
				listIterator.next();               // we need only the nodes reachable from the cutset node 
			while(listIterator.hasNext())
			{
				BBNNode node = (BBNNode) listIterator.next();
				String name = node.getName();
				if(nodeTable.containsKey(name))
				{
					nodesWithPredecessors.put(name,nodeTable.get(name));
					nodeTable.remove(name);
				}
                
			}
		}
		pearlObject.initializeForCutset(network,nodeTable,nodesWithPredecessors,topologicalOrder,cutsetTable);
		baseInfoTable = pearlObject.initNodesWithoutPredecessors();
		//System.out.println(baseInfoTable.toString());
	}
    
	public LinkedList orderCutsetNodes()
	{
		LinkedList orderedCutsetNodes = new LinkedList();       
		List order = network.topologicalSort();
		Iterator listIterator = order.iterator();
		int index = 0;
		while(listIterator.hasNext())
		{
			BBNNode node = (BBNNode) listIterator.next();        
			if(cutsetTable.containsKey(node.getName()))
			{
				orderedCutsetNodes.add(node);
			}
		}               
		//System.out.println((orderedCutsetNodes.clone()).toString());
		return orderedCutsetNodes;
	}
	public Hashtable initAll()
	{
		Hashtable ipd = new Hashtable();
		Set result = getUniqueInstantiation1(cutsetNodes, new Hashtable(), new HashSet(),ipd,1.0);                       
		int cutsetNodeIndex =0;
		int index = 0;
		InferenceResult marginals = null;
		for(Iterator resultIterator = result.iterator();resultIterator.hasNext();)
		{
			Hashtable inst = (Hashtable) resultIterator.next();
            
			InferenceResult i = pearlObject.initNodesWithPredecessors(inst,cutsetNodes,baseInfoTable,index);
			//pearlObject.temp(infoTable);
			//bnTable.put(new Integer(index),infoTable);
			if (index == 0) marginals = i; else marginals.add(i);
			oldIndexTable.put(inst,new Integer(index));
			index++;
		}
		marginals.normalize();
		//System.out.println(marginals.toString());
		return ipd;  
        
	}
    
	public InferenceResult initAll1()
	{
		Hashtable ipd = new Hashtable();
		Set result = getUniqueInstantiation1(cutsetNodes, new Hashtable(), new HashSet(),ipd,1.0);
		TreeSet sortedJPD = new TreeSet();  
		double tempIndex = 0.0;
		System.out.println("size of result " + result.size());
		for(Enumeration e = ipd.keys(); e.hasMoreElements(); )
		{
			Hashtable inst = (Hashtable) e.nextElement();
			//System.out.println(inst.toString());
			double weight = ((Double) ipd.get(inst)).doubleValue();
			if(weight == 0.0)
				weight = tempIndex--;
			boolean t = sortedJPD.add(new JointProbEntry(inst, weight));
			if(t == false)
			{ 
				weight = weight * 1.0001;
				t = sortedJPD.add(new JointProbEntry(inst, weight)); 
			}
		
		}    	
                        
		int cutsetNodeIndex =0;
		int index = 0;
		int numIter = 70000;
		TreeSet sortedJPD2 =  new TreeSet();
		InferenceResult marginals = null;
		int iteration = sortedJPD.size();
		System.out.println(" " + iteration);
		while (iteration > numIter) {
			JointProbEntry e = (JointProbEntry) sortedJPD.last();
			sortedJPD2.add(e);
			sortedJPD.remove(e);
			Hashtable inst = e.key;
			InferenceResult i = pearlObject.initNodesWithPredecessors(inst,cutsetNodes,baseInfoTable,index);			
			if (index == 0) marginals = i; else marginals.add(i);
			//System.out.println(marginals.toString());
			
			oldIndexTable.put(inst,new Integer(index));			
			index++;
			iteration--;
		}
		
		
		marginals.normalize();          

		System.out.println(marginals.toString());
		//inferWithEvidenceNew(sortedJPD);
		////////////////////////////////////////////
		index = 0;
		iteration =  sortedJPD2.size()+ numIter;
		//iteration = 1;
		marginals = null;
		System.out.println("iteration" + iteration);		
		while (iteration > numIter) {			
			JointProbEntry e = (JointProbEntry) sortedJPD2.last();
			sortedJPD2.remove(e);
			Hashtable inst = e.key;
			Integer oldIndex = (Integer) oldIndexTable.get(inst);
			InferenceResult i = pearlObject.inferWithEvidence(inst,oldIndex.intValue());
			if (index == 0) marginals = i; else marginals.add(i);
			//System.out.println(jpd.toString());
			pearlObject.finishedInstantiation(inst);

			//Sort --------here to get the next instantiation;
			index++;
			iteration--;			
		}
		marginals.normalize();          
		return marginals;   

		//return sortedJPD;  
               
	}
	 
	public TreeSet sort_Table(Hashtable ipd)
	{
		TreeSet sortedJPD = new TreeSet();  
		double tempIndex = 0.0;
		for(Enumeration e = ipd.keys(); e.hasMoreElements(); )
		{
			Hashtable inst = (Hashtable) e.nextElement();
			//System.out.println(inst.toString());
			double weight = ((Double) ipd.get(inst)).doubleValue();
			if(weight == 0.0)
				weight = tempIndex--;
			boolean t = sortedJPD.add(new JointProbEntry(inst, weight));
			if(t == false)
			{ 
				weight = weight * 1.0001;
				t = sortedJPD.add(new JointProbEntry(inst, weight)); 
			}
       			
		}    	
		return sortedJPD;
	}
	public InferenceResult inferWithEvidenceNew(TreeSet sortedJPD)
	{
		
		int index = 0;
		int iteration = sortedJPD.size();
		//iteration = 1;
		InferenceResult marginals = null;
		System.out.println("iteration" + iteration);
		while (iteration > 350) {
			JointProbEntry e = (JointProbEntry) sortedJPD.last();
			sortedJPD.remove(e);
			Hashtable inst = e.key;
			Integer oldIndex = (Integer) oldIndexTable.get(inst);
			InferenceResult i = pearlObject.inferWithEvidence(inst,oldIndex.intValue());
			if (index == 0) marginals = i; else marginals.add(i);
			//System.out.println(jpd.toString());
			pearlObject.finishedInstantiation(inst);

			//Sort --------here to get the next instantiation;
			index++;
			iteration--;
		}
		marginals.normalize();          
		return marginals;   
	} 
	
	public InferenceResult inferWithEvidence()
	{
		int index = 0;
		Hashtable jpd = pearlObject.getJointProbabilityTable();
		TreeSet sortedJPD = new TreeSet();
		double tempIndex = 0.0;
		for(Enumeration e = jpd.keys(); e.hasMoreElements(); )
		{
			Hashtable inst = (Hashtable) e.nextElement();
			//System.out.println(inst.toString());
			double weight = ((Double) jpd.get(inst)).doubleValue();
			if(weight == 0.0)
				weight = tempIndex--;
			boolean t = sortedJPD.add(new JointProbEntry(inst, weight));
			if(t == false)
			{ 
				weight = weight * 1.0001;
				t = sortedJPD.add(new JointProbEntry(inst, weight)); 
			}
               
			/*System.out.println(" " + t + " " + weight);*/
		}

		int iteration = sortedJPD.size();
		//iteration = 1;
		InferenceResult marginals = null;
		while (iteration > 0) {
			JointProbEntry e = (JointProbEntry) sortedJPD.last();
			sortedJPD.remove(e);
			Hashtable inst = e.key;
			Integer oldIndex = (Integer) oldIndexTable.get(inst);
			InferenceResult i = pearlObject.inferWithEvidence(inst,oldIndex.intValue());
			if (index == 0) marginals = i; else marginals.add(i);
			//System.out.println(jpd.toString());
			pearlObject.finishedInstantiation(inst);

			//Sort --------here to get the next instantiation;
			index++;
			iteration--;
		}
		marginals.normalize();          
		return marginals;   
	} 

	public InferenceResult sortAndInferUsingAIS()
	{
		Vector cutsetNodeNames = new Vector();
		TreeSet sortedJPD = new TreeSet();
		
		for (Iterator i = cutsetNodes.iterator();i.hasNext();)
		{
			BBNNode node = (BBNNode) i.next();
			cutsetNodeNames.add(node.getName());
		}
		
		Hashtable jpd = pearlObject.getJointProbabilityTable();	
		Hashtable aisJPD = bridge.getAISresult(cutsetNodeNames,numSamples);
		double tempIndex = 0; 
		
		for(Enumeration e = jpd.keys(); e.hasMoreElements(); )
		{
			Hashtable inst = (Hashtable) e.nextElement();
			double weight = ((Double) aisJPD.get(inst)).doubleValue();
			if(weight == 0.0)
				weight = tempIndex--;
			boolean t = sortedJPD.add(new JointProbEntry(inst, weight));
			if(t == false)
			{ 
				weight = weight * 1.0001;
				t = sortedJPD.add(new JointProbEntry(inst, weight)); 
			}
			//sortedJPD.add(new JointProbEntry(inst, weight));
			//tempIndex++;
		}
	
		/*for(Enumeration e = aisJPD.keys(); e.hasMoreElements(); )
		{
			Hashtable inst = (Hashtable) e.nextElement();
			double weight = ((Double) aisJPD.get(inst)).doubleValue();
			sortedJPD.add(new JointProbEntry(inst, weight));
		}*/
		int iteration = sortedJPD.size();
		InferenceResult marginals = null;
		int index = 0;
		//System.out.println("iteration" + iteration + " " + tempIndex);
		while (iteration > 0) {
			JointProbEntry e = (JointProbEntry) sortedJPD.last();
			sortedJPD.remove(e);
			Hashtable inst = e.key;
			Integer oldIndex = (Integer) oldIndexTable.get(inst);
			InferenceResult i = pearlObject.inferWithEvidence(inst,oldIndex.intValue());
			if (index == 0) marginals = i; else marginals.add(i);
			//System.out.println(jpd.toString());
			pearlObject.finishedInstantiation(inst);

			//Sort --------here to get the next instantiation;
			index++;
			iteration--;
		}
		marginals.normalize();          
		return marginals;   
         		
	}
	
	public InferenceResult getMarginals() {
		InferenceResult result = new InferenceResult();
		Hashtable evTable = network.getEvidenceTable();
		getNodesWithoutLoopCutsetPredecessors();
		initAll();
		//TreeSet sortedJPD = initAll1();
		if (evTable.size() > 0)
		{ 
			network.setEvidenceNodes(evTable);
			//result = initAll1();  // this is only for new experiment
			//System.out.println(result.toString());
			
			if (runAIS) {
				result = sortAndInferUsingAIS();	
			}
			else {
				result = inferWithEvidence();
			}
			//System.out.println(result.toString());
		}
		return result;
	}

	public Object getLock() {
		return lock;
	}
    
	public static void main(String[] args)  {
		ParameterTable params = Parameter.process(args);
		String inputFile = params.getString("-i");
		String evidenceFile = params.getString("-e");
		String outputFile = params.getString("-o");
		boolean quiet = params.getBool("-q");
		boolean aisInput = params.getBool("-a");
		boolean aisCutset = params.getBool("-c");

		int samplesInput = 1000;
	    if (aisInput) {
			samplesInput = Integer.parseInt(params.getString("-n"));
	    }

		if (inputFile == null) {
			System.out.println("Usage: edu.ksu.cis.bnj.bbn.inference.cutset.PresortedCutset -i=inputfile [-e=evidencefile] [-o=outputfile] [-q] [-a] [-n]");
			System.out.println("-q = quiet mode");
			System.out.println("-n = number of samples for AIS (default 1000)");
			System.out.println("-a: use adaptive importance sampling");
			System.out.println("-c: use adaptive cutset importance sampling (ACIS)");
			return;
		}

		Runtime r = Runtime.getRuntime();
		long origfreemem = r.freeMemory();
		long freemem;

		BBNGraph g = BBNGraph.load(inputFile);
		if (evidenceFile != null) g.loadEvidence(evidenceFile);

		long origTime = System.currentTimeMillis();

		PresortedCutset bcs = new PresortedCutset(g);

		bcs.runAIS = aisInput;
		bcs.runAISJoint = aisCutset;
		bcs.numSamples = samplesInput;
        
		bcs.bridge = new AISBCC(g, bcs.runAIS, bcs.runAISJoint);
        
		bcs.cutoffPercentage = 0.5;
        
		if (!quiet) {
			if (!aisCutset) {
				System.out.println("Presorted Cutset Conditioning");
			}
			else {
				if (bcs.runAIS && !bcs.runAISJoint) {
					System.out.println("Adaptive Importance Sampling Bounded Cutset Conditioning");
				}
				else {
					System.out.println("Adaptive Cutset Importance Sampling");
				}
			}
		}

		InferenceResult result = bcs.getMarginals();
		
		freemem = origfreemem - r.freeMemory();
		long learnTime = System.currentTimeMillis();
		
		LS ls = new LS(g);
		InferenceResult lsResult = ls.getMarginals();

		if (outputFile != null) result.save(outputFile);

		if (!quiet) {
			if (aisCutset)
				System.out.println("Final result:");
				System.out.println(result.toString());
				System.out.println("----------------------");
				System.out.println("LS result:");
				System.out.println(lsResult.toString());
				System.out.println("----------------------");
				System.out.println("RMSE = "+lsResult.computeRMSE(result));
				System.out.println("Memory needed for Cutset Conditioning = "+freemem);
				System.out.println("Inference time = "+((learnTime - origTime) / 1000.0));
			}
			else {
				if (bcs.runAIS && !bcs.runAISJoint)
				{
					System.out.println("Final result:");
					System.out.println(result.toString());
					System.out.println("----------------------");
					System.out.println("LS result:");
					System.out.println(lsResult.toString());
					System.out.println("----------------------");
					System.out.println("RMSE = "+lsResult.computeRMSE(result));
					System.out.println("Memory needed for AIS-BCC = "+freemem);
					System.out.println("Inference time = "+((learnTime - origTime) / 1000.0));
				}
				else {
					System.out.println("Final result:");
					System.out.println(result.toString());
					System.out.println("----------------------");
					System.out.println("LS result:");
					System.out.println(lsResult.toString());
					System.out.println("----------------------");
					System.out.println("RMSE = "+lsResult.computeRMSE(result));
					System.out.println("Memory needed for ACIS = "+freemem);
					System.out.println("Inference time = "+((learnTime - origTime) / 1000.0));
				}
			}
		}
    
}
