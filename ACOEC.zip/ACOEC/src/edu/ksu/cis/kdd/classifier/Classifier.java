/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.kdd.classifier;

/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


import java.util.Hashtable;
import java.util.Iterator;

import edu.ksu.cis.kdd.classifier.estimator.Estimator;
import edu.ksu.cis.kdd.classifier.estimator.StandardEstimator;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.data.Tuple;

/**
 * @author Roby Joehanes
 *
 */
public abstract class Classifier
{
    protected Table data;
    protected Hashtable classCounter = new Hashtable();
    protected Estimator estimator = new StandardEstimator(this);

    public void tallyClassValues()
    {
        for (Iterator i = data.getTuples().iterator(); i.hasNext(); )
        {
            Tuple t = (Tuple) i.next();
            Double classValue = new Double(t.getClassValue());
            Integer _i = (Integer) classCounter.get(classValue);
            if (_i == null) _i = new Integer(0);
            classCounter.put(classValue, new Integer(_i.intValue()+1));
        }
    }

    public abstract void init();
    public abstract Object build(Table tuples);
    public abstract Object classify(Tuple tuple);

	/**
	 * Returns the estimator.
	 * @return Estimator
	 */
	public Estimator getEstimator() {
		return estimator;
	}

	/**
	 * Sets the estimator.
	 * @param estimator The estimator to set
	 */
	public void setEstimator(Estimator estimator) {
        assert estimator != null;
		this.estimator = estimator;
        estimator.setOwner(this);
	}

    public int getClassTally(Object value)
    {
        Integer i = (Integer) classCounter.get(value);
        if (i == null) return 0;
        return i.intValue();
    }

    public int getTupleSize()
    {
        assert data != null : "Need to tally the tuple first!";
        return data.size();
    }

    public int getClassSize()
    {
        return classCounter.size();
    }

	/**
	 * Returns the data.
	 * @return Table
	 */
	public Table getData() {
		return data;
	}

}
