/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



/*
 * Created on Apr 26, 2004
 * 
 * This file is part of Bayesian Networks in Java (BNJ).
 * 
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package edu.ksu.cis.kdd.ga.operators;

import edu.ksu.cis.kdd.ga.Chromosome;

/**
 * Partially Matched Crossover (PMX) (Goldberg and Lingle, 1985)
 * 
 * @author Roby Joehanes
 */
public class PMXOp extends PermutationOp {

    /**
     * Fix the permutation
     * @param c1 The chromosome to fix
     * @param c2 The other individual
     * @param xpts Array of cross-over points
     */
    protected void fix(Chromosome c1, Chromosome c2, int[] xpts) {
        int length = c1.getSize();
        int xlength = xpts.length;
        int swapidx = 0;
        Object temp;
        for (int i = 0; i < xlength; i++) {
            Object ei = c1.get(i);
            assert ei != null;
            for (int j = 0; j < length; j++) {
                if (j == xpts[i]) continue;
                Object ej = c1.get(j);
                assert ej != null;
                if (ei.equals(ej)) { // A dupe is found!
                    assert swapidx < xlength;
                    c1.set(j, c2.get(xpts[swapidx]));
                    swapidx++;
                    break;
                }
            }
        }
    }

    /**
	 * @see edu.ksu.cis.kdd.ga.GAOp#apply(edu.ksu.cis.kdd.ga.Chromosome[])
	 */
	@Override
	public Chromosome[] apply(Chromosome[] ind) {
        Chromosome[] newInd = clone(ind);
        int[] xpts = getCrossOverPoints(ind);
        swap(newInd, xpts); // May contains duplicates

        // Now fix it
        fix(newInd[0], newInd[1], xpts); // Chromosome 1
        fix(newInd[1], newInd[0], xpts); // Chromosome 2

        return newInd;
	}
}
