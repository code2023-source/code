/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.kdd.util.gui;

/*
 * This file is part of Bayesian Network for Java (BNJ).
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

/**
 * Sortable JTable
 * @author Roby Joehanes
 */
public class SortableTable extends JTable implements MouseListener {
    public static final boolean ASCENDING = true, DESCENDING = false;

    private static final int insertionTreshold = 4;
    protected static final Insets insets = new Insets(0,0,0,0);
    protected static final Color
        cLtHighlight = UIManager.getColor("controlLtHighlight"), // $NON-NLS-1$
        cDkShadow    = UIManager.getColor("controlDkShadow"), // $NON-NLS-1$
        cShadow      = UIManager.getColor("controlShadow"), // $NON-NLS-1$
        cHighlight   = UIManager.getColor("controlHighlight"), // $NON-NLS-1$
        cControl     = UIManager.getColor("control");    // $NON-NLS-1$
    protected final static Font defaultButtonFont = new Font("Arial", Font.PLAIN, 12); // $NON-NLS-1$

    protected int lastSortColumn = -1;
    protected boolean lastSortDirection = ASCENDING;

    protected JTableHeader tableHeader = null;
    protected SortButtonRenderer sortButtonRenderer = null;
    protected Vector dataVector = null;
	
    protected static Comparator ascendingComparator = new Comparator() {
        @Override
		public int compare(Object o1, Object o2) {
            return ((Comparable) o1).compareTo(o2);
        }
    };
    protected static Comparator descendingComparator = new Comparator() {
        @Override
		public int compare(Object o1, Object o2) {
            return -((Comparable) o1).compareTo(o2);
        }
    };

    public SortableTable() { this(null); }
    public SortableTable(TableModel model) {
        super();
        if (model != null) setModel(model);
          else setModel(new DefaultTableModel(30,5));
        init();
    }

    private void init() {
        sortButtonRenderer = new SortButtonRenderer();
        tableHeader = getTableHeader();
        tableHeader.addMouseListener(this); // setup mouse listener
        tableHeader.setDefaultRenderer(sortButtonRenderer);
        setColumnSelectionAllowed(false); // for self-contained sorter
    }

    @Override
	public void setModel(TableModel model) {
        if (!(model instanceof DefaultTableModel))
            throw new RuntimeException("Error: Model must be an instance of DefaultTableModel!");
        super.setModel(model);
        dataVector = ((DefaultTableModel) model).getDataVector();
        if (sortButtonRenderer != null) sortButtonRenderer.reset();
    }

    /**
     * Put the result set of SQL query into this table
     * @param resultSet
     */
    public void setResultSet(ResultSet resultSet)
    {
        try
        {
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int numColumns = resultSetMetaData.getColumnCount();
            int[] columnTypes = new int[numColumns+1]; // extra slack at index 0 so that we don't do substraction every time
            Vector columnNames = new Vector();
            for (int i = 1; i <= numColumns; i++)
            {
                String columnName = resultSetMetaData.getColumnName(i);
                columnNames.add(columnName);
                columnTypes[i] = resultSetMetaData.getColumnType(i);
            }
            Vector data = new Vector();
            while (resultSet.next())
            {
                Vector row = new Vector();
                for (int i = 1; i <= numColumns; i++)
                {
                    switch (columnTypes[i])
                    {
                        case Types.INTEGER:
                        case Types.NUMERIC:
                        case Types.DECIMAL:
                        case Types.SMALLINT:
                        case Types.TINYINT:
                            row.add(new Integer(resultSet.getInt(i)));
                            break;
                        case Types.FLOAT:
                        case Types.DOUBLE:
                        case Types.REAL:
                            row.add(new Double(resultSet.getDouble(i)));
                            break;
                        default:
                            String columnValue = resultSet.getString(i);
                            if (columnValue == null)
                                row.add("null"); // $NON-NLS-1$
                            else
                                row.add(columnValue);
                    }
                }
                data.add(row);
            }
            setModel(new DefaultTableModel(data, columnNames));
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    @Override
	public void mouseClicked(MouseEvent event) {
        Object source = event.getSource();
        if (source == tableHeader) {
            int x = event.getX();
            int viewColumn = getColumnModel().getColumnIndexAtX(x); 
            int columnNo = convertColumnIndexToModel(viewColumn); 
            if (columnNo == -1) return;
            DefaultTableModel model = (DefaultTableModel) getModel();
            sortOnColumn(columnNo);
            sortButtonRenderer.setSelectedColumn(columnNo, getLastSortDirection());
            tableHeader.repaint();
            super.tableChanged(new TableModelEvent(model));
        }
    }

    @Override
	public void mouseEntered(MouseEvent event) {}
    @Override
	public void mouseExited(MouseEvent event) {}
    @Override
	public void mousePressed(MouseEvent event) {}
    @Override
	public void mouseReleased(MouseEvent event) {}
    public boolean getLastSortDirection() { return lastSortDirection; }
    public int getLastSortColumn() { return lastSortColumn; }

    public void sortOnColumn(int columnNo) {
        if (lastSortColumn == columnNo)
            sortOnColumn(columnNo, !lastSortDirection);
        else
            sortOnColumn(columnNo, true);
    }

    public void sortOnColumn(int columnNo, boolean isAscending) {
        // if column no is invalid or is already sorted like before,
        // leave it as it is
        if (columnNo < 0 || (lastSortColumn == columnNo && lastSortDirection == isAscending))
            return;

        assert dataVector != null; // Important!

        // if the column we're sorting isn't the same as before, then
        // do the sort
        if (lastSortColumn != columnNo) {
            int numRowsMinus1 = getRowCount() - 1;
            Comparator comparator = isAscending ? ascendingComparator : descendingComparator;
            sort(columnNo, 0, numRowsMinus1, comparator);
        } else // if the user chose the same column, it's just a reversal
            Collections.reverse(dataVector);
        lastSortColumn = columnNo;
        lastSortDirection = isAscending;
    }

    protected void sort(int columnNo, int lo, int hi, Comparator comparator) {
        quickSort(columnNo, lo, hi, comparator);
        insertionSort(columnNo, lo, hi, comparator);
    }

    /**
     * Three median quick sort
     * 
     * @param columnNo   the column index of which the table is compared against
     * @param lo         left boundary of array partition
     * @param hi         right boundary of array partition
     * @param comparator the comparator
     */
    protected void quickSort(int columnNo, int lo, int hi, Comparator comparator) {
        int left, right, midpoint;

        if ((hi - lo) <= insertionTreshold) return;

        midpoint = (hi + lo)/2;
        if (compare(comparator, columnNo, lo, midpoint) > 0) swap(lo, midpoint);
        if (compare(comparator, columnNo, lo, hi) > 0) swap(lo, hi);
        if (compare(comparator, columnNo, midpoint, hi) > 0) swap(midpoint, hi);

        right = hi - 1;
        swap(midpoint, right);
        left = lo;
        Vector pivotVector = (Vector) dataVector.get(right);
        Object pivotElement = pivotVector.get(columnNo);
        for(;;) {
          while(compare(comparator, columnNo, ++left, pivotElement) < 0);
          while(compare(comparator, columnNo, --right, pivotElement) > 0);
          if (right<left) break;
          swap(left, right);
        }
        swap(left, hi-1);
        quickSort(columnNo, lo, right, comparator);
        quickSort(columnNo, left+1, hi, comparator);
    }

    /**
     * Insertion Sort
     * 
     * @param columnNo   the column index of which the table is compared against
     * @param lo         left boundary of array partition
     * @param hi         right boundary of array partition
     * @param comparator the comparator
     */
    protected void insertionSort(int columnNo, int lo, int hi, Comparator comparator) {
        Vector iVector, jVector;
        Object iElement, jElement;
        int j;
        for (int i = 1; i <= hi; i++) {
            iVector = (Vector) dataVector.get(i);
            iElement = iVector.get(columnNo);
            for (j = i-1; j >= lo; j--) {
                jVector = (Vector) dataVector.get(j);
                jElement = jVector.get(columnNo);
                if (comparator.compare(jElement, iElement) < 1) break;// if a[j] <= a[j+1]
                dataVector.set(j+1, jVector); // a[j+1] = a[j]
            }
            dataVector.set(j+1, iVector);
        }
    }

    protected void swap(int i, int j) {
        Object temp = dataVector.get(i);
        dataVector.set(i, dataVector.get(j));
        dataVector.set(j, temp);
    }

    protected int compare(Comparator comparator, int columnNo, int idx1, int idx2) {
        Vector v1 = (Vector) dataVector.get(idx1);
        Vector v2 = (Vector) dataVector.get(idx2);
        return comparator.compare(v1.get(columnNo),v2.get(columnNo));
    }

    protected int compare(Comparator comparator, int columnNo, int idx, Object o) {
        Vector v = (Vector) dataVector.get(idx);
        return comparator.compare(v.get(columnNo), o);
    }

    class SortButtonRenderer extends JButton implements TableCellRenderer {
        protected int selectedColumn;
        protected boolean direction;
        protected JButton downButton, upButton;

        SortButtonRenderer() {
            reset();
            setMargin(insets);
            setFont(defaultButtonFont);
            downButton = new SortButton(DESCENDING);
            upButton = new SortButton(ASCENDING);
        }

        void reset() {
            selectedColumn = -1;
            direction = ASCENDING;
        }

        @Override
		public Component getTableCellRendererComponent(JTable table, Object value,
                     boolean isSelected, boolean hasFocus, int row, int column) {
            JButton button = column != selectedColumn ? this: 
                direction ? upButton : downButton;
            button.setText((value == null) ? "" : value.toString());
            return button;
        }
    
        void setSelectedColumn(int col, boolean dir) {
            if (col < 0) return;
            selectedColumn = col;
            direction = dir;
        } 
    }

    class SortButton extends JButton {
        static final int DEFAULT_SIZE = 11;

        Color edge1Color = cShadow, edge2Color = cHighlight, fillColor = cControl;
        int iconSize = DEFAULT_SIZE;
        boolean direction;

        SortButton(boolean dir) {
            direction = dir;
            setMargin(insets);
            setFont(defaultButtonFont);
        }

        void setIconSize(int size) { iconSize = size; }

        @Override
		public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Rectangle bounds = g.getClipBounds();
            int x = bounds.width - iconSize - 3;
            int y = (bounds.height - iconSize) / 2;
            if (direction) drawUpArrow(g, x, y);
                else drawDownArrow(g, x, y);
        }

        /*
         * o---o 
         *  \ /        // draws the triangular shaped down arrow step by step
         *   o  
         */
        void drawDownArrow(Graphics g, int xo, int yo) {
            g.setColor(edge1Color);
            g.drawLine(xo, yo,   xo + iconSize - 1, yo);
            g.drawLine(xo, yo+1, xo + iconSize - 3, yo+ 1);
            g.setColor(edge2Color);
            g.drawLine(xo + iconSize - 2, yo + 1, xo + iconSize - 1, yo + 1);
            int x = xo+1;
            int y = yo+2;
            int dx = iconSize - 6;      
            while (y + 1 < yo + iconSize) {
                g.setColor(edge1Color);
                g.drawLine(x, y,   x+1, y);
                g.drawLine(x, y+1, x+1, y+1);
                if (0 < dx) {
                    g.setColor(fillColor);
                    g.drawLine(x+2, y,   x+1+dx, y);
                    g.drawLine(x+2, y+1, x+1+dx, y+1);
                }
                g.setColor(edge2Color);
                g.drawLine(x+dx+2, y,   x+dx+3, y);
                g.drawLine(x+dx+2, y+1, x+dx+3, y+1);
                x += 1;
                y += 2;
                dx -= 2;     
            }
            g.setColor(edge1Color);
            g.drawLine(xo +( iconSize/2), yo + iconSize -1, xo +( iconSize /2), yo + iconSize -1);
        }
    
        /*
         *   o
         *  / \     // draws the triangular shaped up arrow step by step
         * o---o
         */
         void drawUpArrow(Graphics g, int xo, int yo)  {
             g.setColor(edge1Color);
             int x = xo+( iconSize /2);
             g.drawLine(x, yo, x, yo); 
             x--;
             int y = yo+1;
             int dx = 0;
             while (y+3 < yo+ iconSize ) {
                 g.setColor(edge1Color);
                 g.drawLine(x, y,   x+1, y);
                 g.drawLine(x, y+1, x+1, y+1);
                 if (0 < dx) {
                     g.setColor(fillColor);
                     g.drawLine(x+2, y,   x+1+dx, y);
                     g.drawLine(x+2, y+1, x+1+dx, y+1);
                 }
                 g.setColor(edge2Color);
                 g.drawLine(x+dx+2, y,   x+dx+3, y);
                 g.drawLine(x+dx+2, y+1, x+dx+3, y+1);
                 x -= 1;
                 y += 2;
                 dx += 2;     
             }
             g.setColor(edge1Color);
             g.drawLine(xo, yo+ iconSize -3,   xo+1, yo+ iconSize -3);
             g.setColor(edge2Color);
             g.drawLine(xo+2, yo+ iconSize -2, xo+ iconSize -1, yo+ iconSize -2);
             g.drawLine(xo, yo+ iconSize -1, xo+ iconSize , yo+ iconSize -1);    
         }
    }
}