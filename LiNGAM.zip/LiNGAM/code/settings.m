global PSVIEWER;
PSVIEWER = 'gv';
