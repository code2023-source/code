function y = g( x )

y = tanh( x );