%Aapo's startup file for matlab

addpath /home/fs/ahyvarin/matlab/FastICA_21
