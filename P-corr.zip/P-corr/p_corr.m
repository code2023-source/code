BOLDMaxlength=10;
TR=3;
Constraint='p';
IMG = data
%[Correlation_BIC, Nh_BIC_matlab, Correlation_AIC, Nh_AIC_matlab, Correlation_STD, Correlation0, H]=pCorrelation(IMG, BOLDMaxlength, TR, Constraint);
  s=0.05
  CorrMat0=Correlation_AIC
    Nnodes=size(CorrMat0,1)
    CorrMat_s=zeros(Nnodes,Nnodes)
    [~, IX_mat]=sort(CorrMat0(:), 'descend') 
    
    truncateNum=floor(length(CorrMat0(:))*s)
    [Index_i, Index_j]=ind2sub(Nnodes,IX_mat(1:truncateNum))
    for n=1:truncateNum
        CorrMat_s(Index_i(n),Index_j(n))=CorrMat0(Index_i(n),Index_j(n))
    end
   CorrMat_s=threshold_s(CorrMat0, s)
   [m,n]=size(CorrMat_s);
   CorrMat_s1=CorrMat_s(:);
   CorrMat_s2=CorrMat_s;
  imagesc(CorrMat_s2)
 Num=sum(sum(CorrMat_s2~=0))
%�Ƚ�ÿ��������ЧӦ����ǿ�ȵĴ�С
for i=1:n
    for j=i:n
        if abs(CorrMat_s(i,j)-CorrMat_s(j,i))<0.00005
            Num=floor(randi([1 2]));
           if Num==1
               CorrMat_s(i,j)=0;
           end
           if Num==2
               CorrMat_s(j,i)=0;
           end
        end
        if  abs(CorrMat_s(i,j)-CorrMat_s(j,i))>0.00005
            if CorrMat_s(i,j)>CorrMat_s(j,i)
                CorrMat_s(j,i)=0;
            end
            if CorrMat_s(j,i)>CorrMat_s(i,j)
                CorrMat_s(i,j)=0;
            end
        end
           if CorrMat_s(i,j)>CorrMat_s(j,i)            
              CorrMat_s(j,i)=0;
            end
           if i==j
            CorrMat_s(i,j)=-1;
           end
    end
end
b = CorrMat_s;
figure(6)
imagesc(b)
[CorrMat_m,CorrMat_n]=size(b)
 [row, col] = find(b~= 0);
 hanglie=[row col]
  [m_hanglie,n_hanglie]=size(hanglie);
  zuhe1=[]
for i1=1:m_hanglie
 data=CorrMat_s2(hanglie(i1,1),hanglie(i1,2))
 zuhe1=[zuhe1;data]
end
zuhe=[hanglie zuhe1];
%ȷ��ЧӦ���ӱߵķ���
  net_average=squeeze(mean(net));
  GT=net_average-diag(diag(net_average));
  fid = fopen('E:\result\groundtruth.txt', 'wt')
  [row1, col1] = find( GT ~= 0 ); 
  A=[row1 col1]
  [m22,n22]=size(A);
  B=[]
for i2=1:m22
 data=GT(A(i2,1),A(i2,2))
 B=[B;data]
end
 C=[A B]
 [m3, n3] = size(C);
 for i4=1:1:m3
    for j4=1:1:n3
       if j4==n3
        fprintf(fid,'%g\n',C(i4,j4));
        
      else
        fprintf(fid,'%g\t',C(i4,j4));
       end
    end
end
fclose(fid)

