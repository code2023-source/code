function CorrMat_s=threshold_s(CorrMat0, s)

    Nnodes=size(CorrMat0,1);
    CorrMat_s=zeros(Nnodes,Nnodes);
    [~, IX_mat]=sort(CorrMat0(:), 'descend');    
    truncateNum=floor(length(CorrMat0(:))*s);
    [Index_i, Index_j]=ind2sub(Nnodes,IX_mat(1:truncateNum));
    for n=1:truncateNum
        CorrMat_s(Index_i(n),Index_j(n))=CorrMat0(Index_i(n),Index_j(n));
    end
        