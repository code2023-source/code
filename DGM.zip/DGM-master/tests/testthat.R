library(testthat)
test_check("DGM")
