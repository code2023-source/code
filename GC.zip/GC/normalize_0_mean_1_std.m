function [nrm]=normalize_0_mean_1_std(inp_series)

% Normalize the input series to 0 mean and unit standard deviation.
% Input : 
%   inp_series: Is an NxT matrix, where N is the number of variables
%               observed and T is the number of observations (time points)
% Output:
%   nrm: The normalized series.

% Created by Adora D'Souza 05/10/2015

mean_ts = mean(inp_series,2);
mean_ts_mtrx = mean_ts*ones(1,size(inp_series,2));
unb_data_mtrx = inp_series - mean_ts_mtrx;

p = unb_data_mtrx.^2;
s=sum(p,2);
sc=sqrt(s/size(p,2));
sc2=sc*(ones(1,size(p,2)));
nrm= unb_data_mtrx./sc2;
            
end
