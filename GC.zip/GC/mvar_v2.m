function [ARF,IN] = mvar_v2(Y, Pmax)
% % mvar_v2 is adpated for our specific purposes from:
% % 	mvar.m 5090 2008-06-05 08:12:04Z schloegl $ Copyright (C) 1996-2006 by Alois Schloegl <a.schloegl@ieee.org>	
% % 	
% %       It is part of the TSA-toolbox. See also 
% %       http://hci.tugraz.at/schloegl/matlab/tsa/
% %       http://octave.sourceforge.net/
% %       http://biosig.sourceforge.net/

% mvar_v2 estimates Multi-Variate AutoRegressive model parameters by
% minimizing the least square error in the estimate and true value.
%
% INPUT:
%  Y	 : Multivariate data series, TxN (T is number of observations, N is the number of variables) 
%  Pmax  : Model order
%
% OUTPUT:
%  AR    : Multivariate autoregressive model parameter
%  IN    : Innovations

[N,M] = size(Y);

if nargin<2, 
        Pmax=max([N,M])-1;
end;

if iscell(Y)
        Pmax = min(max(N ,M ),Pmax);
end;

ix  = Pmax+1:N;
y   = repmat(NaN,N-Pmax,M*Pmax);
for k = 1:Pmax,
    y(:,k*M+[1-M:0]) = Y(ix-k,:);
end;
ix2 = ~any(isnan([Y(ix,:),y]),2);	
ARF = Y(ix(ix2),:)'/y(ix2,:)';
IN = Y(ix,:) - y*ARF';          
