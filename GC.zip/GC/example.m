clear;
clc;

% This is an example script that uses lsGC analysis to obtain influence
% scores between time-series. 
% Please ensure that all the scripts are in the same directory, and that 
% the path to the directory has been added. 
% You can use MATLAB command: addpath('path_to_directory')

load('synthetic_model.mat');

cp=5:5:45;      % No. of Components
ARorder=2;      % Order of Process
normalize=1;    % Flag for 0 mean unit standard deviation normalization
n=size(y,1);
col=rand(3,length(cp));     % Using color for plot
figure; 
div=2000;
Aff_pos=zeros(n,n,length(cp));
hold on

for c=1:length(cp)
    cmp=cp(c);
    Aff=lsGC_analysis(y,cmp,ARorder,normalize);
    Aff_pos(:,:,c)=Aff.*(Aff>=0);
    [tpr,fpr,Area_roc]= roc_analysis1(Aff_pos(:,:,c),Adj,div);
    plot(fpr,tpr,'Color',col(:,c));
end;
    
set(gcf,'Color',[1 1 1]);
title('ROC plot');
xlabel('FPR');
ylabel('sensitivity');
legend('5PC','10PC','15PC','20PC','25PC','30PC','35PC','40PC','45PC','Location','southeast')% PC=principal components
hold off