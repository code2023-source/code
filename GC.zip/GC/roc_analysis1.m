function [sensitivity, FPR,Area_roc]=roc_analysis1(Aff,Adj,div)

% This function performs ROC analysis and outputs the sensitivity, 
% False Positive Rate (FPR) and the Area under the ROC curve (AUC).
% Inputs:
% Aff   : Affinity matrix obtained from the analysis.
% Adj   : Adj is the adjacency matrix. It is the ground truth of the existence
%         of an influence from one time-series to another. It consists of
%         0's and 1's, where '1' indicates a connection, and '0' indicates no
%         connection.
% div   : Number of threshold levels, at which the affinity matrix is
%         thresholded to obtain an ROC curve.
% Outputs:
% sensitivity and FPR of the ROC plot (both having dimension: div x 1).
% Area_roc: Area Under the ROC curve. 
%
% Created by Adora D'Souza 07/4/2015

if (nargin < 3) 
   div=2000;
end

mx=max(max(Aff));
mn=min(min(Aff));
intrvl=(mx-mn)/(div-1);
thrsh=mn:intrvl:mx;
AUC_roc = zeros(length(thrsh),2);
specificity=zeros(length(thrsh),1);
sensitivity=zeros(length(thrsh),1);
for k=1:length(thrsh)
    ck=Aff>=thrsh(k);
    xr=xor(ck,Adj);
    ad=and(ck,Adj);
    TP=sum(sum(ad));
    TN=sum(sum((not(ad)-xr)));
    xr2=xr.*2;
    fls=ck-xr2;
    FP=sum(sum(fls==-1));
    mis=sum(sum(fls==-2));
    specificity(k)= TN/(TN+FP);
    sensitivity(k)=TP/(TP+mis);
    AUC_roc(k,1) = sensitivity(k);
    AUC_roc(k,2) = 1-specificity(k);
end;

FPR=1-specificity;
Area_roc=-1*(sum((sensitivity(1:end-1)+sensitivity(2:end))/2.*(FPR(2:end)-FPR(1:end-1))));
end
