function Aff=lsGC_analysis(inp_series,cmp,ARorder,normalize)

% Inputs:
% inp_series: Time-series which is stationary and normalized to have 0 mean and unit
%             standard deviation. Should be NxT, where N is the number of
%             time-series and T is the length of the series.
% cmp       : Number of Principal Components used in the dimension reduced space
% ARorder   : Order of the VAR process used in prediction
% normalize : Flag variable used to indicate whether normalization is to be performed or not.
%             It is 1, if the sequence should be normalized to zero mean and
%             unit standard deviation and 0, if normalization should not be
%             done.
% Output:
% Aff       : The affinity matrix whose elements are the the lsGC coefficients.

% Copyright(c) Adora D'Souza. All rights revised.
% Contact: (adora.dsouza@rochester.edu)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin < 2) 
   cmp=30; ARorder=5;
end;
if (nargin <3) 
   ARorder=5;
end;
if (nargin <4) 
   normalize=1;
end;

if normalize==1
    inp_series=normalize_0_mean_1_std(inp_series);
end;

%%% Check for stationarity of the signal
num_non_stat = check_stationarity(inp_series);
if num_non_stat<0
    if num_non_stat ==1
       error(['There is ',num2str(num_non_stat),' time series that is not stationary']);
    else
 	   error(['There are ',num2str(num_non_stat),' time series that are not stationary']);     
    end
end


[coeff,pca12]=princomp(inp_series');
coeff=coeff';
pca12=pca12';

XC=pca12(1:cmp,:);
WC=coeff(1:cmp,:);

[~,noisePrcs] = mvar_v2((XC)',ARorder);
noisePrcs=(noisePrcs)';
pxch=XC(:,ARorder+1:end)-noisePrcs;
h2=pinv(WC)*(pxch);
res1=(h2)-(inp_series(:,ARorder+1:end));   

res2=zeros(size(inp_series,1),size(inp_series,2)-ARorder);
sig_d=zeros(size(inp_series,1),size(inp_series,1));
Aff=zeros(size(inp_series,1),size(inp_series,1));
for m=1:size(inp_series,1)

    yd1=inp_series(1:m-1,:);
    yd2=inp_series(m+1:end,:);
    YD=cat(1,yd1,yd2);
    wd1=WC(:,1:m-1);
    wd2=WC(:,m+1:end);
    WD =cat(2,wd1,wd2) ;
    gD=WD*YD;                 
    XD=gD;

    [~,noisePrcs2] = mvar_v2((XD)',ARorder);
    noisePrcs2=(noisePrcs2)';
    pxdh=XD(:,ARorder+1:end)-noisePrcs2;
    h3=pinv(WD)*(pxdh);
    re=(h3)-(YD(:,ARorder+1:end));     
    res2(1:m-1,:)=re(1:m-1,:);
    res2(m+1:end,:)=re(m:end,:);
    sig_d(m,:)=diag(cov(res2'));
    clear YD yd1 yd2 wd1 wd2 WD XD gD p s sc sc2 pxd AR2  noisePrcs2 pxdh h3
end;
sig=diag(cov(res1'));

for k=1:size(inp_series,1)
    for m=1:size(inp_series,1)
        deno=sig(m);
        Aff(m,k)=log(sig_d(k,m)/deno);
    end;
end;

for k=1:size(inp_series,1)
    for m=1:size(inp_series,1)
        if k==m
        Aff(k,m)=0;
        end;
    end;
end; 
end