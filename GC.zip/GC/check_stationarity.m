
function num_non_stat = check_stationarity(inp_series)

% This function tests for stationarity of the time series ensemble
% Input:
%   inp_series: is an NxT matrix, where N is the number of variables
%               observed and T is the number of observations (time points)
% Output:
%   num_non_stat: number of non-stationary signals in the ensemble of time series.

y=inp_series;
for k=1:size(y,1);
    h(k)=adftest(y(k,:));
end;
non_stat=find(h~=1);
num_non_stat=length(non_stat); 
end